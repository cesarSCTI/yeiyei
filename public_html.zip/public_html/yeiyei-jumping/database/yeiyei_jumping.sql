CREATE DATABASE IF NOT EXISTS yeiyei_jumping CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE yeiyei_jumping;

CREATE TABLE roles (id INT AUTO_INCREMENT PRIMARY KEY, nombre VARCHAR(50) NOT NULL);
INSERT INTO roles (nombre) VALUES ('Administrador'),('Cajero'),('Operativo');

CREATE TABLE usuarios (
 id INT AUTO_INCREMENT PRIMARY KEY,
 id_rol INT NOT NULL,
 nombre VARCHAR(100) NOT NULL,
 usuario VARCHAR(50) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL,
 estado TINYINT DEFAULT 1,
 fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (id_rol) REFERENCES roles(id)
);

CREATE TABLE metodos_pago (id INT AUTO_INCREMENT PRIMARY KEY, nombre VARCHAR(50) NOT NULL, estado TINYINT DEFAULT 1);
INSERT INTO metodos_pago (nombre) VALUES ('Efectivo'),('Tarjeta'),('Transferencia');

CREATE TABLE paquetes_fiesta (
 id INT AUTO_INCREMENT PRIMARY KEY,
 tipo_dia ENUM('LUNES_JUEVES','VIERNES_DOMINGO') NOT NULL,
 personas INT NOT NULL,
 precio DECIMAL(10,2) NOT NULL,
 hora_inicio TIME NOT NULL,
 hora_fin TIME NOT NULL,
 duracion_horas INT DEFAULT 5,
 incluye TEXT,
 estado TINYINT DEFAULT 1
);
INSERT INTO paquetes_fiesta (tipo_dia,personas,precio,hora_inicio,hora_fin,duracion_horas,incluye) VALUES
('LUNES_JUEVES',10,3490,'12:00:00','20:00:00',5,'Botana, Comida, Agua de Sabor, Pastel, Desechable, Invitación digital, Anfitriones'),
('LUNES_JUEVES',20,6590,'12:00:00','20:00:00',5,'Botana, Comida, Agua de Sabor, Pastel, Desechable, Invitación digital, Anfitriones'),
('LUNES_JUEVES',30,9090,'12:00:00','20:00:00',5,'Botana, Comida, Agua de Sabor, Pastel, Desechable, Invitación digital, Anfitriones'),
('LUNES_JUEVES',40,11490,'12:00:00','20:00:00',5,'Botana, Comida, Agua de Sabor, Pastel, Desechable, Invitación digital, Anfitriones'),
('LUNES_JUEVES',50,13990,'12:00:00','20:00:00',5,'Botana, Comida, Agua de Sabor, Pastel, Desechable, Invitación digital, Anfitriones'),
('VIERNES_DOMINGO',10,4690,'12:00:00','21:00:00',5,'Botana, Comida, Agua de Sabor, Pastel, Desechable, Invitación digital, Anfitriones'),
('VIERNES_DOMINGO',20,7990,'12:00:00','21:00:00',5,'Botana, Comida, Agua de Sabor, Pastel, Desechable, Invitación digital, Anfitriones'),
('VIERNES_DOMINGO',30,10890,'12:00:00','21:00:00',5,'Botana, Comida, Agua de Sabor, Pastel, Desechable, Invitación digital, Anfitriones'),
('VIERNES_DOMINGO',40,13490,'12:00:00','21:00:00',5,'Botana, Comida, Agua de Sabor, Pastel, Desechable, Invitación digital, Anfitriones'),
('VIERNES_DOMINGO',50,15490,'12:00:00','21:00:00',5,'Botana, Comida, Agua de Sabor, Pastel, Desechable, Invitación digital, Anfitriones');

CREATE TABLE reservaciones_fiesta (
 id INT AUTO_INCREMENT PRIMARY KEY,
 id_paquete INT NOT NULL,
 id_usuario INT NOT NULL,
 nombre_cliente VARCHAR(150) NOT NULL,
 telefono VARCHAR(20),
 fecha_evento DATE NOT NULL,
 hora_inicio TIME NOT NULL,
 hora_fin TIME NOT NULL,
 total DECIMAL(10,2) NOT NULL,
 anticipo DECIMAL(10,2) DEFAULT 0,
 saldo DECIMAL(10,2) DEFAULT 0,
 estado ENUM('APARTADO','PAGADO','CANCELADO') DEFAULT 'APARTADO',
 observaciones TEXT,
 fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (id_paquete) REFERENCES paquetes_fiesta(id),
 FOREIGN KEY (id_usuario) REFERENCES usuarios(id)
);

CREATE TABLE entradas (
 id INT AUTO_INCREMENT PRIMARY KEY,
 id_usuario INT NOT NULL,
 cantidad INT NOT NULL,
 precio_unitario DECIMAL(10,2) NOT NULL,
 total DECIMAL(10,2) NOT NULL,
 id_metodo_pago INT NOT NULL,
 fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP,
 estado TINYINT DEFAULT 1,
 FOREIGN KEY (id_usuario) REFERENCES usuarios(id),
 FOREIGN KEY (id_metodo_pago) REFERENCES metodos_pago(id)
);

CREATE TABLE ingresos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 id_usuario INT NOT NULL,
 tipo ENUM('ENTRADA','FIESTA','OTRO') NOT NULL,
 referencia_id INT NULL,
 concepto VARCHAR(150) NOT NULL,
 monto DECIMAL(10,2) NOT NULL,
 id_metodo_pago INT NOT NULL,
 fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP,
 estado TINYINT DEFAULT 1,
 FOREIGN KEY (id_usuario) REFERENCES usuarios(id),
 FOREIGN KEY (id_metodo_pago) REFERENCES metodos_pago(id)
);

CREATE TABLE egresos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 id_usuario INT NOT NULL,
 concepto VARCHAR(150) NOT NULL,
 monto DECIMAL(10,2) NOT NULL,
 observaciones TEXT,
 fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP,
 estado TINYINT DEFAULT 1,
 FOREIGN KEY (id_usuario) REFERENCES usuarios(id)
);

CREATE TABLE cortes_diarios (
 id INT AUTO_INCREMENT PRIMARY KEY,
 id_usuario INT NOT NULL,
 fecha DATE NOT NULL,
 total_ingresos DECIMAL(10,2) DEFAULT 0,
 total_egresos DECIMAL(10,2) DEFAULT 0,
 total_final DECIMAL(10,2) DEFAULT 0,
 observaciones TEXT,
 fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (id_usuario) REFERENCES usuarios(id)
);

INSERT INTO usuarios (id_rol,nombre,usuario,password,estado) VALUES
(1,'Administrador','admin','$2y$10$9u6eeIRcmm2LzRqRi61ZdeHEWfEiNDEnu78WPNk2yU0FKf9mrB6Ae',1);
