-- Actualización Área de Fiestas
-- Ejecutar una sola vez si vienes de una versión anterior.

CREATE TABLE IF NOT EXISTS pagos_fiesta (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_reservacion INT NOT NULL,
    id_usuario INT NOT NULL,
    id_metodo_pago INT NOT NULL,
    monto DECIMAL(10,2) NOT NULL,
    concepto VARCHAR(150) DEFAULT 'Pago de reservación',
    observaciones TEXT NULL,
    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP,
    estado TINYINT DEFAULT 1,
    INDEX idx_reservacion (id_reservacion),
    INDEX idx_usuario (id_usuario),
    INDEX idx_metodo (id_metodo_pago)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Si la tabla ya existía de una versión anterior, agrega columnas faltantes.
SET @db := DATABASE();

SET @sql := IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='pagos_fiesta' AND COLUMN_NAME='concepto')=0,
    'ALTER TABLE pagos_fiesta ADD COLUMN concepto VARCHAR(150) DEFAULT ''Pago de reservación'' AFTER monto',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='pagos_fiesta' AND COLUMN_NAME='observaciones')=0,
    'ALTER TABLE pagos_fiesta ADD COLUMN observaciones TEXT NULL AFTER concepto',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='pagos_fiesta' AND COLUMN_NAME='fecha_registro')=0,
    'ALTER TABLE pagos_fiesta ADD COLUMN fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP AFTER observaciones',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='pagos_fiesta' AND COLUMN_NAME='estado')=0,
    'ALTER TABLE pagos_fiesta ADD COLUMN estado TINYINT DEFAULT 1 AFTER fecha_registro',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='ingresos' AND COLUMN_NAME='referencia_id')=0,
    'ALTER TABLE ingresos ADD COLUMN referencia_id INT NULL AFTER tipo',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='ingresos' AND COLUMN_NAME='estado')=0,
    'ALTER TABLE ingresos ADD COLUMN estado TINYINT DEFAULT 1 AFTER fecha_registro',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
