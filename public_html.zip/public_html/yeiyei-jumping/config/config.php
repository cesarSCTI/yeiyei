<?php

define('APP_NAME', 'YeiYei Jumping');

if (!defined('BASE_URL')) {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') == 443);
    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
    $scriptDir = rtrim($scriptDir, '/');
    define('BASE_URL', $scheme . '://' . $host . $scriptDir . '/');
}

date_default_timezone_set('America/Mexico_City');

function base_url($path = '')
{
    return BASE_URL . ltrim($path, '/');
}
