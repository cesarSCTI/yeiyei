<?php

$url = $_GET['url'] ?? 'login';
$url = trim($url, '/');

if ($url === '') {
    $url = 'login';
}

$methodHttp = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

if ($url === 'login' && $methodHttp === 'POST') {
    $url = 'auth/login';
}

$routes = [
    'login' => ['AuthController', 'index'],
    'auth/login' => ['AuthController', 'login'],
    'logout' => ['AuthController', 'logout'],

    'dashboard' => ['DashboardController', 'index'],

    'entradas' => ['EntradasController', 'index'],
    'entradas/store' => ['EntradasController', 'store'],
    'entradas/store-multiple' => ['EntradasController', 'storeMultiple'],
    'entradas/list' => ['EntradasController', 'list'],
    'entradas/ticket' => ['EntradasController', 'ticket'],

    // Control de salida
    'entradas/calcular-salida' => ['EntradasController', 'calcularSalida'],
    'entradas/registrar-salida' => ['EntradasController', 'registrarSalida'],

    // Alias de seguridad por si el servidor corta la ruta
    'calcular-salida' => ['EntradasController', 'calcularSalida'],
    'registrar-salida' => ['EntradasController', 'registrarSalida'],

    'fiestas' => ['FiestasController', 'index'],
    'fiestas/store' => ['FiestasController', 'store'],
    'fiestas/update' => ['FiestasController', 'update'],
    'fiestas/abonar' => ['FiestasController', 'abonar'],
    'fiestas/cancelar' => ['FiestasController', 'cancelar'],
    'fiestas/detalle' => ['FiestasController', 'detalle'],
    'fiestas/list' => ['FiestasController', 'list'],

    'ingresos' => ['IngresosController', 'index'],
    'ingresos/list' => ['IngresosController', 'list'],

    'egresos' => ['EgresosController', 'index'],
    'egresos/store' => ['EgresosController', 'store'],
    'egresos/list' => ['EgresosController', 'list'],

    'cortes' => ['CortesController', 'index'],

    'usuarios' => ['UsuariosController', 'index'],
    'usuarios/list' => ['UsuariosController', 'list'],

    'calcetines' => ['CalcetinesController', 'index'],
    'calcetines/list' => ['CalcetinesController', 'list'],

    'calcetines/store' => ['CalcetinesController', 'store'],
    'calcetines/show' => ['CalcetinesController', 'show'],
    'calcetines/update' => ['CalcetinesController', 'update'],
    'calcetines/toggle' => ['CalcetinesController', 'toggle'],

    'calcetines/stock' => ['CalcetinesController', 'ajustarStock'],
];

if (!isset($routes[$url])) {
    http_response_code(404);
    require __DIR__ . '/../app/views/errors/404.php';
    exit;
}

[$controllerName, $method] = $routes[$url];

require_once __DIR__ . '/../app/controllers/' . $controllerName . '.php';

$controller = new $controllerName();

if (!method_exists($controller, $method)) {
    http_response_code(500);
    echo "Método no encontrado: {$controllerName}::{$method}";
    exit;
}

$controller->$method();