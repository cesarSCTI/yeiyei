$(document).ready(function () {

    $(document).on('click', '#togglePass', function () {
        const input = $('#password');
        const icon = $(this).find('i');

        if (input.attr('type') === 'password') {
            input.attr('type', 'text');
            icon.removeClass('bi-eye').addClass('bi-eye-slash');
        } else {
            input.attr('type', 'password');
            icon.removeClass('bi-eye-slash').addClass('bi-eye');
        }
    });

    $(document).on('submit', '#formLogin', function (e) {
        e.preventDefault();

        const form = this;
        const url = $(form).attr('action') || (BASE_URL + 'auth/login');
        const btn = $(form).find('button[type="submit"], .btn-login');
        const originalHtml = btn.html();

        $.ajax({
            url: url,
            type: 'POST',
            data: $(form).serialize(),
            dataType: 'json',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            },
            beforeSend: function () {
                btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Validando...');
            },
            success: function (r) {
                if (r && r.success) {
                    window.location.href = r.redirect || (BASE_URL + 'dashboard');
                    return;
                }

                Swal.fire('Aviso', (r && r.message) ? r.message : 'Usuario o contraseña incorrectos.', 'warning');
            },
            error: function (xhr) {
                console.error(xhr.responseText);

                let msg = 'No se pudo procesar la solicitud.';

                try {
                    const r = JSON.parse(xhr.responseText);
                    if (r.message) {
                        msg = r.message;
                    }
                } catch (e) {
                    if (xhr.status === 404) {
                        msg = 'No se encontró la ruta de inicio de sesión.';
                    } else if (xhr.status === 500) {
                        msg = 'Error interno al iniciar sesión.';
                    }
                }

                Swal.fire('Error', msg, 'error');
            },
            complete: function () {
                btn.prop('disabled', false).html(originalHtml);
            }
        });
    });

});
