$(function () {
    const modalUsuarioEl = document.getElementById('modalUsuario');
    const modalUsuario = new bootstrap.Modal(modalUsuarioEl);
    const modalPasswordEl = document.getElementById('modalPassword');
    const modalPassword = new bootstrap.Modal(modalPasswordEl);

    const tabla = $('#tablaUsuarios').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: BASE_URL + 'usuarios/list',
            type: 'POST',
            error: function (xhr) {
                console.log(xhr.responseText);
                Swal.fire('Error', 'No se pudo cargar el listado de usuarios.', 'error');
            }
        },
        columns: [
            { data: 'id' },
            { data: 'nombre' },
            { data: 'usuario' },
            { data: 'rol' },
            {
                data: 'estado',
                orderable: false,
                render: function (data) {
                    return Number(data) === 1
                        ? '<span class="badge text-bg-success">Activo</span>'
                        : '<span class="badge text-bg-secondary">Inactivo</span>';
                }
            },
            { data: 'fecha_registro' },
            {
                data: null,
                orderable: false,
                searchable: false,
                render: function (row) {
                    const textoEstado = Number(row.estado) === 1 ? 'Desactivar' : 'Activar';
                    const iconEstado = Number(row.estado) === 1 ? 'bi-toggle-on' : 'bi-toggle-off';
                    const colorEstado = Number(row.estado) === 1 ? 'btn-outline-danger' : 'btn-outline-success';

                    return `
                        <div class="btn-group btn-group-sm" role="group">
                            <button type="button" class="btn btn-outline-primary btnEditar" data-id="${row.id}" title="Editar">
                                <i class="bi bi-pencil-square"></i>
                            </button>
                            <button type="button" class="btn btn-outline-warning btnPassword" data-id="${row.id}" title="Cambiar contraseña">
                                <i class="bi bi-key"></i>
                            </button>
                            <button type="button" class="btn ${colorEstado} btnToggle" data-id="${row.id}" data-estado="${row.estado}" title="${textoEstado}">
                                <i class="bi ${iconEstado}"></i>
                            </button>
                        </div>
                    `;
                }
            }
        ],
        language: {
            url: 'https://cdn.datatables.net/plug-ins/2.0.8/i18n/es-MX.json'
        }
    });

    $('#btnNuevoUsuario').on('click', function () {
        $('#formUsuario')[0].reset();
        $('#usuario_id').val('');
        $('#tituloModalUsuario').text('Nuevo usuario');
        $('#boxPasswordNuevo').show();
        $('#password').prop('required', true).val('');
        $('#formUsuario').attr('action', BASE_URL + 'usuarios/store');
        modalUsuario.show();
    });

    $('#tablaUsuarios').on('click', '.btnEditar', function () {
        const id = $(this).data('id');

        $.ajax({
            url: BASE_URL + 'usuarios/show',
            type: 'POST',
            data: { id: id },
            dataType: 'json',
            success: function (resp) {
                if (!resp.success) {
                    Swal.fire('Error', resp.message, 'error');
                    return;
                }

                const u = resp.data;
                $('#formUsuario')[0].reset();
                $('#usuario_id').val(u.id);
                $('#nombre').val(u.nombre);
                $('#usuario').val(u.usuario);
                $('#id_rol').val(u.id_rol);
                $('#tituloModalUsuario').text('Editar usuario');
                $('#boxPasswordNuevo').hide();
                $('#password').prop('required', false).val('');
                $('#formUsuario').attr('action', BASE_URL + 'usuarios/update');
                modalUsuario.show();
            },
            error: function (xhr) {
                console.log(xhr.responseText);
                Swal.fire('Error', 'No se pudo obtener el usuario.', 'error');
            }
        });
    });

    $('#formUsuario').on('submit', function (e) {
        e.preventDefault();

        const form = $(this);
        const btn = $('#btnGuardarUsuario');

        $.ajax({
            url: form.attr('action'),
            type: 'POST',
            data: form.serialize(),
            dataType: 'json',
            beforeSend: function () {
                btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span> Guardando...');
            },
            success: function (resp) {
                if (resp.success) {
                    modalUsuario.hide();
                    Swal.fire({
                        icon: 'success',
                        title: 'Correcto',
                        text: resp.message,
                        timer: 1300,
                        showConfirmButton: false
                    });
                    tabla.ajax.reload(null, false);
                } else {
                    Swal.fire('Error', resp.message, 'error');
                }
            },
            error: function (xhr) {
                console.log(xhr.responseText);
                Swal.fire('Error', 'No se pudo guardar el usuario.', 'error');
            },
            complete: function () {
                btn.prop('disabled', false).text('Guardar');
            }
        });
    });

    $('#tablaUsuarios').on('click', '.btnPassword', function () {
        const id = $(this).data('id');
        $('#formPassword')[0].reset();
        $('#password_usuario_id').val(id);
        modalPassword.show();
    });

    $('#formPassword').on('submit', function (e) {
        e.preventDefault();

        const form = $(this);

        $.ajax({
            url: form.attr('action'),
            type: 'POST',
            data: form.serialize(),
            dataType: 'json',
            success: function (resp) {
                if (resp.success) {
                    modalPassword.hide();
                    Swal.fire('Correcto', resp.message, 'success');
                } else {
                    Swal.fire('Error', resp.message, 'error');
                }
            },
            error: function (xhr) {
                console.log(xhr.responseText);
                Swal.fire('Error', 'No se pudo actualizar la contraseña.', 'error');
            }
        });
    });

    $('#tablaUsuarios').on('click', '.btnToggle', function () {
        const id = $(this).data('id');
        const estado = Number($(this).data('estado'));
        const accion = estado === 1 ? 'desactivar' : 'activar';

        Swal.fire({
            icon: 'warning',
            title: 'Confirmar',
            text: `¿Deseas ${accion} este usuario?`,
            showCancelButton: true,
            confirmButtonText: 'Sí, continuar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (!result.isConfirmed) return;

            $.ajax({
                url: BASE_URL + 'usuarios/toggle',
                type: 'POST',
                data: { id: id },
                dataType: 'json',
                success: function (resp) {
                    if (resp.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Correcto',
                            text: resp.message,
                            timer: 1300,
                            showConfirmButton: false
                        });
                        tabla.ajax.reload(null, false);
                    } else {
                        Swal.fire('Error', resp.message, 'error');
                    }
                },
                error: function (xhr) {
                    console.log(xhr.responseText);
                    Swal.fire('Error', 'No se pudo cambiar el estado del usuario.', 'error');
                }
            });
        });
    });
});
