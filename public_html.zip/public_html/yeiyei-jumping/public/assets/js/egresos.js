$(document).ready(function () {

    let tablaEgresos = null;

    $(document).on('submit', '#formEgreso', function (e) {
        e.preventDefault();

        const form = this;
        const url = $(form).attr('action') || (BASE_URL + 'egresos/store');
        const btn = $(form).find('button[type="submit"]');
        const originalHtml = btn.html();

        $.ajax({
            url: url,
            type: 'POST',
            data: $(form).serialize(),
            dataType: 'json',
            beforeSend: function () {
                btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Guardando...');
            },
            success: function (r) {
                if (r.success) {
                    Swal.fire('Correcto', r.message || 'Egreso registrado.', 'success');

                    const modalEl = document.getElementById('modalEgreso');
                    const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
                    modal.hide();

                    form.reset();

                    if (tablaEgresos) {
                        tablaEgresos.ajax.reload(null, false);
                    } else {
                        location.reload();
                    }
                } else {
                    Swal.fire('Aviso', r.message || 'No se pudo registrar.', 'warning');
                }
            },
            error: function (xhr) {
                console.error(xhr.responseText);
                let msg = 'No se pudo guardar el egreso.';
                try {
                    const r = JSON.parse(xhr.responseText);
                    if (r.message) msg = r.message;
                } catch (e) {}
                Swal.fire('Error', msg, 'error');
            },
            complete: function () {
                btn.prop('disabled', false).html(originalHtml);
            }
        });
    });

    if ($('#tablaEgresos').length && $.fn.DataTable) {
        tablaEgresos = $('#tablaEgresos').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: BASE_URL + 'egresos/list',
                type: 'POST'
            },
            columns: [
                { data: 'id' },
                { data: 'concepto' },
                { data: 'monto', render: d => '$' + Number(d || 0).toFixed(2) },
                { data: 'usuario' },
                { data: 'fecha_registro' }
            ],
            language: {
                url: 'https://cdn.datatables.net/plug-ins/2.0.8/i18n/es-MX.json'
            }
        });
    }

});
