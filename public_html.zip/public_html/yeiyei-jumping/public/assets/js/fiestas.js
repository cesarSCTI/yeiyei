$(document).ready(function () {

    let tablaFiestas = null;

    function money(value) {
        return '$' + Number(value || 0).toFixed(2);
    }

    function estadoBadge(estado) {
        let clase = 'bg-warning text-dark';
        if (estado === 'PAGADO') clase = 'bg-success';
        if (estado === 'CANCELADO') clase = 'bg-danger';
        return `<span class="badge ${clase}">${estado || ''}</span>`;
    }

    function reloadTabla() {
        if (tablaFiestas) {
            tablaFiestas.ajax.reload(null, false);
        } else {
            location.reload();
        }
    }

    function postJson(url, data, okCallback) {
        $.ajax({
            url: url,
            type: 'POST',
            data: data,
            dataType: 'json',
            success: function (r) {
                if (r.success) {
                    okCallback(r);
                } else {
                    Swal.fire('Aviso', r.message || 'No se pudo procesar.', 'warning');
                }
            },
            error: function (xhr) {
                console.error(xhr.responseText);
                let msg = 'No se pudo procesar la solicitud.';
                try {
                    const r = JSON.parse(xhr.responseText);
                    if (r.message) msg = r.message;
                } catch (e) {}
                Swal.fire('Error', msg, 'error');
            }
        });
    }

    $(document).on('submit', '#formFiesta', function (e) {
        e.preventDefault();

        const form = this;
        const url = $(form).attr('action') || (BASE_URL + 'fiestas/store');
        const btn = $(form).find('button[type="submit"]');
        const originalHtml = btn.html();

        $.ajax({
            url: url,
            type: 'POST',
            data: $(form).serialize(),
            dataType: 'json',
            beforeSend: function () {
                btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Guardando...');
            },
            success: function (r) {
                if (r.success) {
                    Swal.fire('Correcto', r.message || 'Reservación registrada.', 'success');

                    const modalEl = document.getElementById('modalFiesta');
                    const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
                    modal.hide();

                    form.reset();
                    reloadTabla();
                } else {
                    Swal.fire('Aviso', r.message || 'No se pudo registrar.', 'warning');
                }
            },
            error: function (xhr) {
                console.error(xhr.responseText);
                let msg = 'No se pudo guardar la reservación.';
                try {
                    const r = JSON.parse(xhr.responseText);
                    if (r.message) msg = r.message;
                } catch (e) {}
                Swal.fire('Error', msg, 'error');
            },
            complete: function () {
                btn.prop('disabled', false).html(originalHtml);
            }
        });
    });

    if ($('#tablaFiestas').length && $.fn.DataTable) {
        tablaFiestas = $('#tablaFiestas').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: BASE_URL + 'fiestas/list',
                type: 'POST'
            },
            columns: [
                { data: 'id' },
                { data: 'nombre_cliente' },
                { data: 'telefono' },
                { data: 'fecha_evento' },
                { data: null, render: r => (r.hora_inicio || '') + ' - ' + (r.hora_fin || '') },
                { data: null, render: r => (r.personas || '') + ' personas' },
                { data: 'total', render: d => money(d) },
                { data: 'anticipo', render: d => money(d) },
                { data: 'saldo', render: d => money(d) },
                { data: 'estado', render: d => estadoBadge(d) },
                {
                    data: null,
                    orderable: false,
                    searchable: false,
                    render: function (r) {
                        const disabled = r.estado === 'CANCELADO' ? 'disabled' : '';
                        const disabledPagado = (r.estado === 'PAGADO' || Number(r.saldo || 0) <= 0 || r.estado === 'CANCELADO') ? 'disabled' : '';
                        return `
                            <div class="btn-group btn-group-sm" role="group">
                                <button type="button" class="btn btn-outline-info btn-ver-fiesta" data-id="${r.id}" title="Ver">
                                    <i class="bi bi-eye"></i>
                                </button>
                                <button type="button" class="btn btn-outline-primary btn-abonar-fiesta" data-id="${r.id}" data-cliente="${String(r.nombre_cliente || '').replace(/"/g, '&quot;')}" data-saldo="${r.saldo}" ${disabledPagado} title="Abonar">
                                    <i class="bi bi-cash-coin"></i>
                                </button>
                                <button type="button" class="btn btn-outline-success btn-liquidar-fiesta" data-id="${r.id}" data-saldo="${r.saldo}" ${disabledPagado} title="Liquidar">
                                    <i class="bi bi-check2-circle"></i>
                                </button>
                                <button type="button" class="btn btn-outline-danger btn-cancelar-fiesta" data-id="${r.id}" ${disabled} title="Cancelar">
                                    <i class="bi bi-x-circle"></i>
                                </button>
                            </div>`;
                    }
                }
            ],
            language: {
                url: 'https://cdn.datatables.net/plug-ins/2.0.8/i18n/es-MX.json'
            }
        });
    }

    $(document).on('click', '.btn-ver-fiesta', function () {
        const id = $(this).data('id');

        postJson(BASE_URL + 'fiestas/show', { id }, function (r) {
            const x = r.reserva;

            $('#detalleFiestaContenido').html(`
                <div class="row g-3">
                    <div class="col-md-6"><strong>Cliente:</strong><br>${x.nombre_cliente || ''}</div>
                    <div class="col-md-6"><strong>Teléfono:</strong><br>${x.telefono || ''}</div>
                    <div class="col-md-4"><strong>Fecha:</strong><br>${x.fecha_evento || ''}</div>
                    <div class="col-md-4"><strong>Horario:</strong><br>${x.hora_inicio || ''} - ${x.hora_fin || ''}</div>
                    <div class="col-md-4"><strong>Paquete:</strong><br>${x.personas || ''} personas</div>
                    <div class="col-md-3"><strong>Total:</strong><br>${money(x.total)}</div>
                    <div class="col-md-3"><strong>Anticipo:</strong><br>${money(x.anticipo)}</div>
                    <div class="col-md-3"><strong>Saldo:</strong><br>${money(x.saldo)}</div>
                    <div class="col-md-3"><strong>Estado:</strong><br>${estadoBadge(x.estado)}</div>
                    <div class="col-12"><strong>Observaciones:</strong><br>${x.observaciones || 'Sin observaciones'}</div>
                </div>
            `);

            let pagosHtml = '';
            if (r.pagos && r.pagos.length) {
                r.pagos.forEach(p => {
                    pagosHtml += `
                        <tr>
                            <td>${p.fecha_registro || ''}</td>
                            <td>${p.concepto || p.observaciones || ''}</td>
                            <td>${money(p.monto)}</td>
                            <td>${p.metodo_pago || ''}</td>
                            <td>${p.usuario || ''}</td>
                        </tr>`;
                });
            } else {
                pagosHtml = '<tr><td colspan="5" class="text-center text-muted">Sin pagos registrados</td></tr>';
            }
            $('#detalleFiestaPagos').html(pagosHtml);

            new bootstrap.Modal(document.getElementById('modalDetalleFiesta')).show();
        });
    });

    $(document).on('click', '.btn-abonar-fiesta', function () {
        const id = $(this).data('id');
        const cliente = $(this).data('cliente') || '';
        const saldo = Number($(this).data('saldo') || 0);

        $('#formAbonoFiesta')[0].reset();
        $('#abono_id_reservacion').val(id);
        $('#abono_monto').attr('max', saldo).val('');
        $('#abono_info_reserva').html(`<strong>${cliente}</strong><br>Saldo pendiente: <strong>${money(saldo)}</strong>`);

        new bootstrap.Modal(document.getElementById('modalAbonoFiesta')).show();
    });

    $(document).on('submit', '#formAbonoFiesta', function (e) {
        e.preventDefault();

        const form = this;
        const btn = $(form).find('button[type="submit"]');
        const originalHtml = btn.html();

        $.ajax({
            url: $(form).attr('action'),
            type: 'POST',
            data: $(form).serialize(),
            dataType: 'json',
            beforeSend: function () {
                btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Guardando...');
            },
            success: function (r) {
                if (r.success) {
                    Swal.fire('Correcto', r.message || 'Abono registrado.', 'success');
                    const modalEl = document.getElementById('modalAbonoFiesta');
                    const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
                    modal.hide();
                    reloadTabla();
                } else {
                    Swal.fire('Aviso', r.message || 'No se pudo registrar el abono.', 'warning');
                }
            },
            error: function (xhr) {
                console.error(xhr.responseText);
                Swal.fire('Error', 'No se pudo registrar el abono.', 'error');
            },
            complete: function () {
                btn.prop('disabled', false).html(originalHtml);
            }
        });
    });

    $(document).on('click', '.btn-liquidar-fiesta', function () {
        const id = $(this).data('id');
        const saldo = Number($(this).data('saldo') || 0);

        Swal.fire({
            title: 'Liquidar reservación',
            html: `Saldo pendiente: <strong>${money(saldo)}</strong><br><br>Selecciona método de pago:<br><select id="swal_metodo_pago" class="swal2-input"><option value="1">Efectivo</option><option value="2">Tarjeta</option><option value="3">Transferencia</option></select>`,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Liquidar',
            cancelButtonText: 'Cancelar',
            preConfirm: () => {
                return document.getElementById('swal_metodo_pago').value;
            }
        }).then((result) => {
            if (!result.isConfirmed) return;

            postJson(BASE_URL + 'fiestas/liquidar', { id, id_metodo_pago: result.value }, function (r) {
                Swal.fire('Correcto', r.message || 'Reservación liquidada.', 'success');
                reloadTabla();
            });
        });
    });

    $(document).on('click', '.btn-cancelar-fiesta', function () {
        const id = $(this).data('id');

        Swal.fire({
            title: 'Cancelar reservación',
            text: 'Esta acción cambiará el estado a CANCELADO.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Sí, cancelar',
            cancelButtonText: 'No'
        }).then((result) => {
            if (!result.isConfirmed) return;

            postJson(BASE_URL + 'fiestas/cancelar', { id }, function (r) {
                Swal.fire('Correcto', r.message || 'Reservación cancelada.', 'success');
                reloadTabla();
            });
        });
    });

});
