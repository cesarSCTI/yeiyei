$(function () {
    const modalCalcetinEl = document.getElementById('modalCalcetin');
    const modalCalcetin = new bootstrap.Modal(modalCalcetinEl);

    const modalStockEl = document.getElementById('modalStock');
    const modalStock = new bootstrap.Modal(modalStockEl);

    function moneda(valor) {
        return '$' + Number(valor || 0).toFixed(2);
    }

    function entero(valor) {
        return Number(valor || 0);
    }

    function badgeStock(valor) {
        const stock = entero(valor);
        const badge = stock <= 0
            ? 'bg-danger'
            : (stock <= 5 ? 'bg-warning text-dark' : 'bg-success');

        return `<span class="badge ${badge}">${stock}</span>`;
    }

    function getMensajeAjax(xhr, mensajeDefault) {
        let msg = mensajeDefault;

        try {
            const resp = JSON.parse(xhr.responseText);
            if (resp.message) msg = resp.message;
            if (resp.error) msg = resp.error;
        } catch (e) {
            if (xhr.responseText) console.log(xhr.responseText);
        }

        return msg;
    }

    const tabla = $('#tablaCalcetines').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: BASE_URL + 'calcetines/list',
            type: 'POST',
            error: function (xhr) {
                console.log(xhr.responseText);
                Swal.fire('Error', getMensajeAjax(xhr, 'No se pudo cargar el listado de calcetines.'), 'error');
            }
        },
        order: [[0, 'desc']],
        columns: [
            { data: 'id' },
            {
                data: 'precio',
                render: function (d) {
                    return moneda(d);
                }
            },
            {
                data: 'stock_inicial',
                render: function (d) {
                    return entero(d);
                }
            },
            {
                data: 'vendidos',
                render: function (d) {
                    return `<span class="badge bg-primary">${entero(d)}</span>`;
                }
            },
            {
                data: 'existencias',
                render: function (d) {
                    return badgeStock(d);
                }
            },
            {
                data: 'estado',
                orderable: false,
                render: function (data) {
                    return Number(data) === 1
                        ? '<span class="badge text-bg-success">Activo</span>'
                        : '<span class="badge text-bg-secondary">Inactivo</span>';
                }
            },
            { data: 'fecha_registro' },
            {
                data: null,
                orderable: false,
                searchable: false,
                render: function (row) {
                    const textoEstado = Number(row.estado) === 1 ? 'Desactivar' : 'Activar';
                    const iconEstado = Number(row.estado) === 1 ? 'bi-toggle-on' : 'bi-toggle-off';
                    const colorEstado = Number(row.estado) === 1 ? 'btn-outline-danger' : 'btn-outline-success';

                    return `
                        <div class="btn-group btn-group-sm" role="group">
                            <button type="button"
                                    class="btn btn-outline-primary btnEditar"
                                    data-id="${row.id}"
                                    title="Editar">
                                <i class="bi bi-pencil-square"></i>
                            </button>

                            <button type="button"
                                    class="btn btn-outline-secondary btnStock"
                                    data-id="${row.id}"
                                    title="Ajustar existencias">
                                <i class="bi bi-box-seam"></i>
                            </button>

                            <button type="button"
                                    class="btn ${colorEstado} btnToggle"
                                    data-id="${row.id}"
                                    data-estado="${row.estado}"
                                    title="${textoEstado}">
                                <i class="bi ${iconEstado}"></i>
                            </button>
                        </div>
                    `;
                }
            }
        ],
        language: {
            url: 'https://cdn.datatables.net/plug-ins/2.0.8/i18n/es-MX.json'
        }
    });

    $('#btnNuevoCalcetin').on('click', function () {
        $('#formCalcetin')[0].reset();
        $('#calcetin_id').val('');
        $('#calcetin_id_alt').val('');
        $('#vendidos_view').val('');
        $('#existencias_view').val('');
        $('#resumenEditarStock').addClass('d-none');
        $('#tituloModalCalcetin').text('Nuevo registro de calcetines');
        $('#formCalcetin').attr('action', BASE_URL + 'calcetines/store');
        modalCalcetin.show();
    });

    $('#tablaCalcetines').on('click', '.btnEditar', function () {
        const id = $(this).data('id');

        $.ajax({
            url: BASE_URL + 'calcetines/show',
            type: 'POST',
            data: { id: id },
            dataType: 'json',
            success: function (resp) {
                if (!resp.success) {
                    Swal.fire('Error', resp.message || 'No se pudo obtener el registro.', 'error');
                    return;
                }

                const p = resp.data;

                $('#formCalcetin')[0].reset();
                $('#calcetin_id').val(p.id);
                $('#calcetin_id_alt').val(p.id);
                $('#precio').val(p.precio);
                $('#stock_inicial').val(p.stock_inicial);
                $('#vendidos_view').val(entero(p.vendidos));
                $('#existencias_view').val(entero(p.existencias));

                $('#resumenEditarStock').removeClass('d-none');
                $('#tituloModalCalcetin').text('Editar calcetines');
                $('#formCalcetin').attr('action', BASE_URL + 'calcetines/update');
                modalCalcetin.show();
            },
            error: function (xhr) {
                Swal.fire('Error', getMensajeAjax(xhr, 'No se pudo obtener el registro.'), 'error');
            }
        });
    });

    $('#formCalcetin').on('submit', function (e) {
        e.preventDefault();

        const form = $(this);
        const btn = $('#btnGuardarCalcetin');

        $.ajax({
            url: form.attr('action'),
            type: 'POST',
            data: form.serialize(),
            dataType: 'json',
            beforeSend: function () {
                btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span> Guardando...');
            },
            success: function (resp) {
                if (resp.success) {
                    modalCalcetin.hide();

                    Swal.fire({
                        icon: 'success',
                        title: 'Correcto',
                        text: resp.message,
                        timer: 1300,
                        showConfirmButton: false
                    });

                    tabla.ajax.reload(null, false);
                } else {
                    Swal.fire('Error', resp.message || 'No se pudo guardar.', 'error');
                }
            },
            error: function (xhr) {
                Swal.fire('Error', getMensajeAjax(xhr, 'No se pudo guardar el registro.'), 'error');
            },
            complete: function () {
                btn.prop('disabled', false).text('Guardar');
            }
        });
    });

    $('#tablaCalcetines').on('click', '.btnStock', function () {
        const id = $(this).data('id');

        $('#formStock')[0].reset();
        $('#stock_calcetin_id').val(id);
        $('#stock_producto').val('Calcetines');
        modalStock.show();
    });

    $('#formStock').on('submit', function (e) {
        e.preventDefault();

        const form = $(this);
        const btn = $('#btnGuardarStock');

        $.ajax({
            url: form.attr('action'),
            type: 'POST',
            data: form.serialize(),
            dataType: 'json',
            beforeSend: function () {
                btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span> Aplicando...');
            },
            success: function (resp) {
                if (resp.success) {
                    modalStock.hide();

                    Swal.fire({
                        icon: 'success',
                        title: 'Correcto',
                        text: resp.message,
                        timer: 1300,
                        showConfirmButton: false
                    });

                    tabla.ajax.reload(null, false);
                } else {
                    Swal.fire('Error', resp.message || 'No se pudo ajustar la existencia.', 'error');
                }
            },
            error: function (xhr) {
                Swal.fire('Error', getMensajeAjax(xhr, 'No se pudo ajustar la existencia.'), 'error');
            },
            complete: function () {
                btn.prop('disabled', false).text('Aplicar ajuste');
            }
        });
    });

    $('#tablaCalcetines').on('click', '.btnToggle', function () {
        const id = $(this).data('id');
        const estado = Number($(this).data('estado'));
        const accion = estado === 1 ? 'desactivar' : 'activar';

        Swal.fire({
            icon: 'warning',
            title: 'Confirmar',
            text: `¿Deseas ${accion} calcetines?`,
            showCancelButton: true,
            confirmButtonText: 'Sí, continuar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (!result.isConfirmed) return;

            $.ajax({
                url: BASE_URL + 'calcetines/toggle',
                type: 'POST',
                data: { id: id },
                dataType: 'json',
                success: function (resp) {
                    if (resp.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Correcto',
                            text: resp.message,
                            timer: 1300,
                            showConfirmButton: false
                        });

                        tabla.ajax.reload(null, false);
                    } else {
                        Swal.fire('Error', resp.message || 'No se pudo cambiar el estado.', 'error');
                    }
                },
                error: function (xhr) {
                    Swal.fire('Error', getMensajeAjax(xhr, 'No se pudo cambiar el estado.'), 'error');
                }
            });
        });
    });
});
