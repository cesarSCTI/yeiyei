$(document).ready(function () {
    let tablaEntradas = null;

    const COVER_ADULTO_EXTRA = 30;

    const PRECIOS = {
        '1_HORA': 189,
        '2_HORAS': 219,
        'ILIMITADO': 319,
        'SOLO_COVER': 30,
        'SOLO_CALCETINES': 0
    };

    let catalogoCalcetines = [];

    function redondearCobro(valor) {
        return Math.round(Number(valor || 0));
    }

    function formatoMoneda(valor) {
        return '$' + redondearCobro(valor).toLocaleString('es-MX');
    }

    function nombreTipo(tipo) {
        if (tipo === '1_HORA') return '1 Hora';
        if (tipo === '2_HORAS') return '2 Horas';
        if (tipo === 'ILIMITADO') return 'Ilimitado';
        if (tipo === 'SOLO_COVER') return 'Sólo Cover';
        if (tipo === 'SOLO_CALCETINES') return 'Sólo Calcetines';
        return tipo || '';
    }

    function marcarTipoEntradaActivo(tipo) {
        $('.btnTipoEntrada')
            .removeClass('active btn-primary btn-success')
            .addClass('btn-outline-primary');

        const btn = $('.btnTipoEntrada[data-tipo="' + tipo + '"]');

        btn.addClass('active');

        if (tipo === 'SOLO_CALCETINES') {
            btn.removeClass('btn-outline-primary').addClass('btn-success');
        } else {
            btn.removeClass('btn-outline-primary').addClass('btn-primary');
        }
    }

    function aplicarModoTipoEntrada(tipo) {
        marcarTipoEntradaActivo(tipo);

        const esSoloCover = tipo === 'SOLO_COVER';
        const esSoloCalcetines = tipo === 'SOLO_CALCETINES';

        if (esSoloCover) {
            $('#boxNinos').addClass('d-none');
            $('#boxAdultos')
                .removeClass('d-none col-md-6')
                .addClass('col-md-12');

            $('#labelAdultos').text('Personas');
            $('#textoAyudaTipoEntrada').text('Sólo Cover: se cobra $30 por persona. No aplica promoción ni tiempo de salida.');

            $('#boxFestivo').addClass('d-none');
            $('#boxPromocion').addClass('d-none');
            $('#boxCover').addClass('d-none');
            $('#cobrarCover').prop('checked', false);
            $('#esDiaFestivo').prop('checked', false);

            $('#idCalcetin').prop('required', false);
            $('#cantidadCalcetin').prop('required', false);
            $('#tituloCalcetines').html('<i class="bi bi-bag"></i> Calcetines (Opcional)');
        } else if (esSoloCalcetines) {
            $('#boxNinos').addClass('d-none');
            $('#boxAdultos').addClass('d-none');

            $('#textoAyudaTipoEntrada').text('Sólo Calcetines: no registra entrada ni tiempo de salida. Selecciona calcetines y cantidad.');

            $('#boxFestivo').addClass('d-none');
            $('#boxPromocion').addClass('d-none');
            $('#boxCover').addClass('d-none');
            $('#cobrarCover').prop('checked', false);
            $('#esDiaFestivo').prop('checked', false);

            $('#idCalcetin').prop('required', true);
            $('#cantidadCalcetin').prop('required', true);
            $('#tituloCalcetines').html('<i class="bi bi-bag"></i> Calcetines (Obligatorio)');
        } else {
            $('#boxNinos').removeClass('d-none');
            $('#boxAdultos')
                .removeClass('d-none col-md-12')
                .addClass('col-md-6');

            $('#labelAdultos').text('Adultos');
            $('#textoAyudaTipoEntrada').text('Selecciona el tipo de venta. Para Sólo Cover se cobra por persona. Para Sólo Calcetines registra únicamente producto.');

            $('#boxFestivo').removeClass('d-none');
            $('#boxPromocion').removeClass('d-none');

            $('#idCalcetin').prop('required', false);
            $('#cantidadCalcetin').prop('required', false);
            $('#tituloCalcetines').html('<i class="bi bi-bag"></i> Calcetines (Opcional)');
        }
    }

    function formatoEstadoTiempo(estado) {
        if (estado === 'FINALIZADA') {
            return '<span class="badge bg-success">Finalizada</span>';
        }

        return '<span class="badge bg-warning text-dark">Activa</span>';
    }

    function getMensajeAjax(xhr, mensajeDefault) {
        let msg = mensajeDefault;

        try {
            const resp = JSON.parse(xhr.responseText);
            if (resp.message) {
                msg = resp.message;
            }
        } catch (e) {
            if (xhr.responseText) {
                console.error(xhr.responseText);
            }
        }

        return msg;
    }


    function getDebugAjax(xhr) {
        try {
            const resp = JSON.parse(xhr.responseText);
            return resp.debug || resp.error || '';
        } catch (e) {
            return xhr.responseText || '';
        }
    }

    function escaparHtml(texto) {
        return String(texto || '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#039;');
    }

    function mostrarErrorDetalle(titulo, mensaje, debug) {
        let html = '<div class="text-start">';
        html += '<div><strong>' + escaparHtml(mensaje || 'Ocurrió un error.') + '</strong></div>';

        if (debug) {
            html += '<hr class="my-2">';
            html += '<div class="small text-muted mb-1">Motivo / causa:</div>';
            html += '<pre style="white-space:pre-wrap;text-align:left;background:#f8f9fa;border:1px solid #ddd;border-radius:6px;padding:8px;max-height:220px;overflow:auto;">'
                + escaparHtml(debug)
                + '</pre>';
        }

        html += '</div>';

        Swal.fire({
            icon: 'error',
            title: titulo || 'Error',
            html: html,
            width: 650
        });
    }

    function getDiaSemana() {
        const dias = ['DOMINGO', 'LUNES', 'MARTES', 'MIERCOLES', 'JUEVES', 'VIERNES', 'SABADO'];
        return dias[new Date().getDay()];
    }

    function calcularPromocion(tipo, cantidad, precio, esFestivo) {
        const subtotal = cantidad * precio;

        let promo = '';
        let descuento = 0;
        let totalPromo = subtotal;

        const aplicaPromo = !esFestivo && (tipo === '2_HORAS' || tipo === 'ILIMITADO');

        if (!aplicaPromo) {
            return { promo, descuento, totalPromo };
        }

        const dia = getDiaSemana();

        if (dia === 'LUNES') {
            promo = 'Lunes: Agua natural gratis';
        }

        if (dia === 'MARTES') {
            descuento = subtotal * 0.10;
            totalPromo = subtotal - descuento;
            promo = 'Martes: 10% de descuento';
        }

        if (dia === 'MIERCOLES') {
            promo = 'Miércoles: Pizza individual gratis';
        }

        // Jueves: promoción exclusiva para Ilimitado.
        // No aplica para 2 Horas.
        if (dia === 'JUEVES' && tipo === 'ILIMITADO') {
            const bloques = Math.floor(cantidad / 3);
            const restantes = cantidad % 3;

            if (bloques > 0) {
                totalPromo = (bloques * 599) + (restantes * precio);
                descuento = subtotal - totalPromo;
                promo = 'Jueves: 3 personas por $599';
            }
        }

        if (dia === 'VIERNES') {
            const pagados = Math.ceil(cantidad / 2);
            totalPromo = pagados * precio;
            descuento = subtotal - totalPromo;
            promo = 'Viernes: 2x1';
        }

        return { promo, descuento, totalPromo };
    }

    function calcularEntrada() {
        const tipo = $('#tipoEntrada').val() || '1_HORA';
        aplicarModoTipoEntrada(tipo);
        const precio = PRECIOS[tipo] || 189;

        const ninos = parseInt($('#ninos').val()) || 0;
        const adultos = parseInt($('#adultos').val()) || 0;

        // Para entradas normales se cobra por niño.
        // Para Sólo Cover se cobra por adulto.
        let cantidad = ninos;

        if (tipo === 'SOLO_COVER') {
            cantidad = adultos;
        }

        if (tipo === 'SOLO_CALCETINES') {
            cantidad = 0;
        }

        const pagaCon = parseFloat($('#pagaCon').val()) || 0;
        const idCalcetin = $('#idCalcetin').val();

        const cantidadCalcetin =
            parseInt($('#cantidadCalcetin').val()) || 0;

        let totalCalcetines = 0;        
        const esFestivo = $('#esDiaFestivo').is(':checked');

        let cover = 0;

        $('#alertAdultos').addClass('d-none');

        if (tipo !== 'SOLO_COVER' && tipo !== 'SOLO_CALCETINES' && adultos > ninos) {
            const adultosExtra = adultos - ninos;

            $('#boxCover').removeClass('d-none');
            $('#txtAdultosExtra').text(adultosExtra + ' adulto(s) extra');

            if ($('#cobrarCover').is(':checked')) {
                cover = adultosExtra * COVER_ADULTO_EXTRA;
            }
        } else {
            $('#boxCover').addClass('d-none');
            $('#cobrarCover').prop('checked', false);
            $('#txtAdultosExtra').text('0 adulto(s) extra');
        }

        if (idCalcetin && cantidadCalcetin > 0) {

            const producto =
                catalogoCalcetines.find(
                    x => String(x.id) === String(idCalcetin)
                );

            if (producto) {

                totalCalcetines =
                    Number(producto.precio) *
                    cantidadCalcetin;
            }
        }

        const subtotal = cantidad * precio;
        const promo = (tipo === 'SOLO_COVER' || tipo === 'SOLO_CALCETINES')
            ? { promo: '', descuento: 0, totalPromo: subtotal }
            : calcularPromocion(tipo, cantidad, precio, esFestivo);

        const totalCalculado =
            promo.totalPromo +
            cover +
            totalCalcetines;
        const total = redondearCobro(totalCalculado);
        const cambio = redondearCobro(pagaCon) - total;

        $('#cantidad').val(cantidad);
        $('#precioUnitario').val(precio.toFixed(2));
        $('#cover').val(cover.toFixed(2));
        $('#promocionAplicada').val(promo.promo);
        $('#descuento').val(promo.descuento.toFixed(2));

        $('#precioUnitarioView').val(formatoMoneda(precio));
        $('#subtotalEntradaView').val(formatoMoneda(subtotal));
        $('#descuentoEntradaView').val(formatoMoneda(promo.descuento));
        $('#coverEntradaView').val(formatoMoneda(cover));
        $('#totalCalcetines')
            .val(formatoMoneda(totalCalcetines));        
        $('#totalEntrada').val(total);
        $('#cambioEntrada').val(cambio >= 0 ? cambio : 0);

        if (promo.promo) {
            $('#boxPromocion').removeClass('alert-secondary alert-warning').addClass('alert-info');
            $('#txtPromocion').text(promo.promo);
        } else {
            $('#boxPromocion').removeClass('alert-info').addClass(esFestivo ? 'alert-warning' : 'alert-secondary');
            $('#txtPromocion').text(esFestivo ? 'No aplica promoción por día festivo' : 'Sin promoción');
        }

        return {
            totalCalcetines,
            idCalcetin,
            cantidadCalcetin,            
            tipo,
            tipoNombre: nombreTipo(tipo),
            ninos,
            adultos,
            cantidad,
            precio,
            subtotal,
            cover,
            promocion: promo.promo,
            descuento: promo.descuento,
            total,
            pagaCon,
            cambio,
            esFestivo
        };
    }

    function calcularCambioExtra() {
        const cargo = redondearCobro($('#salidaCargoExtra').val());
        const pagaCon = redondearCobro($('#pagaConExtra').val());
        const cambio = pagaCon - cargo;

        $('#cambioExtraView').val(formatoMoneda(cambio >= 0 ? cambio : 0));

        return { cargo, pagaCon, cambio };
    }


    $(document).on('click', '.btnTipoEntrada', function () {
        const tipo = $(this).data('tipo');

        if (!tipo) {
            return;
        }

        $('#tipoEntrada').val(tipo).trigger('change');
        calcularEntrada();
    });

    $(document).on('click', '.btnCantidad', function () {
        const target = $(this).data('target');
        const step = parseInt($(this).data('step')) || 0;
        const input = $('#' + target);

        if (!input.length) {
            return;
        }

        let valor = parseInt(input.val()) || 0;
        valor = Math.max(0, valor + step);

        input.val(valor).trigger('change');
    });

    $(document).on(
    'input change',

    '#tipoEntrada, #ninos, #adultos, #pagaCon, #cobrarCover, #esDiaFestivo, #idCalcetin, #cantidadCalcetin', function () {
        calcularEntrada();
    });

    $(document).on('input change', '#pagaConExtra', function () {
        calcularCambioExtra();
    });



    function obtenerCalcetinSeleccionado(selectId) {
        const id = $('#' + selectId).val();

        if (!id) {
            return null;
        }

        return catalogoCalcetines.find(
            x => String(x.id) === String(id)
        ) || null;
    }

    function obtenerExistenciasCalcetin(producto) {
        if (!producto) {
            return 0;
        }

        return Number(producto.existencias ?? producto.stock ?? 0);
    }



    function actualizarInfoCalcetinMultiple() {
        const producto = obtenerCalcetinSeleccionado('multi_id_calcetin');
        const cantidad = parseInt($('#multi_cantidad_calcetin').val()) || 0;

        if (!producto) {
            $('#multi_calcetin_titulo').html('<i class="bi bi-bag"></i> Calcetines');
            $('#multi_calcetin_info').html('<span class="text-muted">Sin existencias disponibles.</span>');
            $('#multi_total_calcetines_view').val(formatoMoneda(0));
            return;
        }

        const existencias = obtenerExistenciasCalcetin(producto);
        const precio = Number(producto.precio || 0);

        $('#multi_calcetin_titulo').html(
            '<i class="bi bi-bag"></i> Calcetines - ' + formatoMoneda(precio) +
            ' <span class="text-muted fw-normal">| Existencia: ' + existencias + '</span>'
        );

        if (cantidad <= 0) {
            $('#multi_calcetin_info').html('<span class="text-muted">Cantidad 0 = no agregar calcetines.</span>');
        } else if (cantidad > existencias) {
            $('#multi_calcetin_info').html('<span class="text-danger fw-semibold">Stock insuficiente: solicitaste ' + cantidad + ', disponible ' + existencias + '.</span>');
        } else if (cantidad === existencias) {
            $('#multi_calcetin_info').html('<span class="text-warning fw-semibold">Stock máximo alcanzado. Disponible: ' + existencias + ' par(es).</span>');
        } else {
            $('#multi_calcetin_info').html('<span class="text-success">Disponible: ' + existencias + ' par(es).</span>');
        }
    }

    function cargarCatalogoCalcetines(callback) {
        $.ajax({
            url: BASE_URL + 'calcetines/list',
            type: 'POST',
            data: {
                start: 0,
                length: 500
            },
            dataType: 'json',
            success: function (resp) {
                if (!resp || !resp.data) {
                    if (typeof callback === 'function') callback();
                    return;
                }

                catalogoCalcetines = resp.data;

                let html = '<option value="">No agregar calcetines</option>';

                resp.data.forEach(function (item) {
                    const existencias = obtenerExistenciasCalcetin(item);

                    if (existencias <= 0) return;

                    html += `
                        <option value="${item.id}">
                            Calcetines
                            - ${formatoMoneda(item.precio)}
                            | Existencias:${existencias}
                        </option>
                    `;
                });

                $('#idCalcetin').html(html);
                $('#multi_id_calcetin').html(html);

                if (typeof callback === 'function') callback();
            },
            error: function (xhr) {
                console.error(xhr.responseText);
                if (typeof callback === 'function') callback();
            }
        });
    }

    function calcularPromocionMultiple(tipo, cantidad, precio) {
        const esFestivo = $('#multi_es_dia_festivo').is(':checked');
        return calcularPromocion(tipo, cantidad, precio, esFestivo);
    }

    function agregarConceptoMultiple(conceptos, tipo, nombre, cantidad, precio) {
        if (cantidad <= 0) {
            return;
        }

        const subtotal = cantidad * precio;
        const promo = calcularPromocionMultiple(tipo, cantidad, precio);
        const total = Number(promo.totalPromo || subtotal);
        const descuento = Number(promo.descuento || 0);

        conceptos.push({
            tipo: tipo,
            nombre: nombre,
            cantidad: cantidad,
            precio: precio,
            subtotal: subtotal,
            promocion: promo.promo || '',
            descuento: descuento,
            total: total
        });
    }

    function calcularPagoMixtoMultiple(totalVenta) {
        totalVenta = redondearCobro(totalVenta);

        const efectivo = redondearCobro($('#pago_efectivo').val());
        const tarjeta = redondearCobro($('#pago_tarjeta').val());
        const transferencia = redondearCobro($('#pago_transferencia').val());
        const cortesia = redondearCobro($('#pago_cortesia').val());

        const totalCapturado = efectivo + tarjeta + transferencia + cortesia;
        const pendiente = Math.max(0, totalVenta - totalCapturado);
        const cambio = Math.max(0, totalCapturado - totalVenta);

        $('#multi_total_pagado_view').val(formatoMoneda(totalCapturado));
        $('#multi_pendiente_view').val(formatoMoneda(pendiente));
        $('#multi_cambio_view').val(formatoMoneda(cambio));

        return {
            efectivo,
            tarjeta,
            transferencia,
            cortesia,
            totalCapturado,
            pendiente,
            cambio
        };
    }


    function calcularVentaMultiple() {
        const q1 = parseInt($('#multi_1_hora').val()) || 0;
        const q2 = parseInt($('#multi_2_horas').val()) || 0;
        const qi = parseInt($('#multi_ilimitado').val()) || 0;
        const qc = parseInt($('#multi_cover').val()) || 0;

        let idCalcetin = $('#multi_id_calcetin').val();
        const cantidadCalcetin = parseInt($('#multi_cantidad_calcetin').val()) || 0;

        // Si el usuario captura calcetines y el select oculto está vacío,
        // seleccionamos automáticamente el primer calcetín disponible.
        // Si la cantidad es 0, se interpreta como "no agregar calcetines".
        if (cantidadCalcetin > 0 && !idCalcetin) {
            const primeroDisponible = catalogoCalcetines.find(function (item) {
                return obtenerExistenciasCalcetin(item) > 0;
            });

            if (primeroDisponible) {
                idCalcetin = String(primeroDisponible.id);
                $('#multi_id_calcetin').val(idCalcetin);
            }
        }

        let totalCalcetines = 0;
        let calcetinDisponible = 0;

        if (idCalcetin && cantidadCalcetin > 0) {
            const producto = obtenerCalcetinSeleccionado('multi_id_calcetin');

            if (producto) {
                calcetinDisponible = obtenerExistenciasCalcetin(producto);
                totalCalcetines = Number(producto.precio) * cantidadCalcetin;
            }
        }

        const conceptos = [];

        if (q1 > 0) {
            conceptos.push({
                tipo: '1_HORA',
                nombre: '1 Hora',
                cantidad: q1,
                precio: PRECIOS['1_HORA'],
                subtotal: q1 * PRECIOS['1_HORA'],
                promocion: '',
                descuento: 0,
                total: q1 * PRECIOS['1_HORA']
            });
        }

        agregarConceptoMultiple(conceptos, '2_HORAS', '2 Horas', q2, PRECIOS['2_HORAS']);
        agregarConceptoMultiple(conceptos, 'ILIMITADO', 'Ilimitado', qi, PRECIOS['ILIMITADO']);

        if (qc > 0) {
            conceptos.push({
                tipo: 'SOLO_COVER',
                nombre: 'Sólo Cover',
                cantidad: qc,
                precio: PRECIOS['SOLO_COVER'],
                subtotal: qc * PRECIOS['SOLO_COVER'],
                promocion: '',
                descuento: 0,
                total: qc * PRECIOS['SOLO_COVER']
            });
        }

        if (totalCalcetines > 0) {
            conceptos.push({
                tipo: 'SOLO_CALCETINES',
                nombre: 'Calcetines',
                cantidad: cantidadCalcetin,
                precio: totalCalcetines / cantidadCalcetin,
                subtotal: totalCalcetines,
                promocion: '',
                descuento: 0,
                total: totalCalcetines
            });
        }

        const totalCalculado = conceptos.reduce((acc, item) => acc + Number(item.total || 0), 0);
        const total = redondearCobro(totalCalculado);
        const descuentoTotal = conceptos.reduce((acc, item) => acc + Number(item.descuento || 0), 0);
        const pagoMixto = calcularPagoMixtoMultiple(total);
        const hayPromociones = conceptos.some(item => item.promocion || Number(item.descuento || 0) > 0);

        let html = '';

        if (conceptos.length === 0) {
            html = '<span class="text-muted">Sin conceptos agregados.</span>';
        } else {
            html = '<div class="table-responsive"><table class="table table-sm mb-0">';
            html += '<thead><tr><th>Concepto</th><th class="text-center">Cant.</th><th class="text-end">Precio</th>';

            if (hayPromociones) {
                html += '<th>Promoción</th><th class="text-end">Desc.</th>';
            }

            html += '<th class="text-end">Total</th></tr></thead><tbody>';

            conceptos.forEach(function (item) {
                html += `
                    <tr>
                        <td>${item.nombre}</td>
                        <td class="text-center">${item.cantidad}</td>
                        <td class="text-end">${formatoMoneda(item.precio)}</td>
                `;

                if (hayPromociones) {
                    html += `
                        <td>${item.promocion || 'Sin promoción'}</td>
                        <td class="text-end">${formatoMoneda(item.descuento || 0)}</td>
                    `;
                }

                html += `
                        <td class="text-end">${formatoMoneda(item.total)}</td>
                    </tr>
                `;
            });

            html += '</tbody>';

            if (hayPromociones) {
                html += `
                    <tfoot>
                        <tr>
                            <th colspan="4" class="text-end">Descuento total</th>
                            <th class="text-end">${formatoMoneda(descuentoTotal)}</th>
                            <th></th>
                        </tr>
                    </tfoot>
                `;
            }

            html += '</table></div>';
        }

        $('#resumenVentaMultiple').html(html);
        $('#multi_total_calcetines_view').val(formatoMoneda(totalCalcetines));
        $('#multi_total').val(total);
        $('#multi_total_view').text(formatoMoneda(total));
        actualizarInfoCalcetinMultiple();

        return {
            q1,
            q2,
            qi,
            qc,
            idCalcetin,
            cantidadCalcetin,
            calcetinDisponible,
            totalCalcetines,
            descuentoTotal,
            conceptos,
            total,
            pagoMixto,
            pagaCon: pagoMixto.totalCapturado,
            cambio: pagoMixto.cambio
        };
    }

    $(document).on('click', '.btnCantidadMultiple', function () {
        const target = $(this).data('target');
        const step = parseInt($(this).data('step')) || 0;
        const input = $('#' + target);

        if (!input.length) {
            return;
        }

        let valor = parseInt(input.val()) || 0;
        valor = Math.max(0, valor + step);

        input.val(valor).trigger('change');
    });

    $(document).on(
        'input change',
        '#multi_1_hora, #multi_2_horas, #multi_ilimitado, #multi_cover, #multi_id_calcetin, #multi_cantidad_calcetin, #multi_es_dia_festivo, .campoPagoMixto',
        function () {
            calcularVentaMultiple();
        }
    );

    $('#modalVentaMultiple').on('shown.bs.modal', function () {
        $('#formVentaMultiple')[0].reset();
        cargarCatalogoCalcetines(function () {
            calcularVentaMultiple();
        });
    });

    $('#modalVentaMultiple').on('hidden.bs.modal', function () {
        $('#formVentaMultiple')[0].reset();
        calcularVentaMultiple();
    });

    $(document).on('submit', '#formVentaMultiple', function (e) {
        e.preventDefault();

        const form = this;
        const btn = $(form).find('button[type="submit"]');
        const originalHtml = btn.html();

        const datos = calcularVentaMultiple();

        const tieneEntradas =
            datos.q1 > 0 ||
            datos.q2 > 0 ||
            datos.qi > 0 ||
            datos.qc > 0;

        const tieneCalcetines = datos.cantidadCalcetin > 0;

        // Cantidad 0 = no agregar calcetines.
        // El select oculto puede conservar un producto seleccionado para mostrar precio/existencia,
        // pero no debe enviarse al backend cuando la cantidad es 0.
        if (datos.cantidadCalcetin <= 0) {
            datos.idCalcetin = '';
            $('#multi_id_calcetin').val('');
            $('#multi_cantidad_calcetin').val(0);
        }

        if (!tieneEntradas && !tieneCalcetines) {
            Swal.fire(
                'Validación',
                'Agrega al menos una entrada, cover o calcetines.',
                'warning'
            );
            return;
        }

        if (datos.cantidadCalcetin > 0 && !datos.idCalcetin) {
            Swal.fire(
                'Sin stock',
                'No hay calcetines disponibles para vender en este momento.',
                'warning'
            );
            return;
        }

        if (datos.idCalcetin && datos.cantidadCalcetin > datos.calcetinDisponible) {
            Swal.fire(
                'Stock insuficiente',
                'Solicitaste ' + datos.cantidadCalcetin + ' par(es) de calcetines, pero sólo hay ' + datos.calcetinDisponible + ' disponible(s).',
                'warning'
            );
            return;
        }

        if (datos.pagoMixto.totalCapturado < datos.total) {
            Swal.fire(
                'Pago insuficiente',
                'Falta capturar ' + formatoMoneda(redondearCobro(datos.total - datos.pagoMixto.totalCapturado)) + ' para completar la venta.',
                'warning'
            );
            return;
        }

        if (datos.pagoMixto.cambio > datos.pagoMixto.efectivo) {
            Swal.fire(
                'Pago inválido',
                'El cambio no puede ser mayor al efectivo recibido. Revisa tarjeta, transferencia o cortesía.',
                'warning'
            );
            return;
        }

        $.ajax({
            url: $(form).attr('action'),
            type: 'POST',
            data: $(form).serialize(),
            dataType: 'json',
            beforeSend: function () {
                btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Guardando...');
            },
            success: function (resp) {
                if (resp && resp.success) {
                    const ids = resp.ids || [];

                    let html = `
                        <div class="text-start">
                            <p><strong>Registros creados:</strong> ${ids.length}</p>
                            <p><strong>Total:</strong> ${formatoMoneda(resp.total || datos.total)}</p>
                            <p><strong>Total capturado:</strong> ${formatoMoneda(resp.total_capturado || datos.pagaCon)}</p>
                            <p><strong>Cambio:</strong> ${formatoMoneda(resp.cambio || datos.cambio)}</p>
                        </div>
                    `;

                    Swal.fire({
                        icon: 'success',
                        title: 'Venta múltiple registrada',
                        html: html,
                        confirmButtonText: 'Imprimir tickets'
                    }).then(() => {
                        ids.forEach(function (id, index) {
                            setTimeout(function () {
                                window.open(BASE_URL + 'entradas/ticket?id=' + id, '_blank');
                            }, index * 350);
                        });

                        const modalEl = document.getElementById('modalVentaMultiple');
                        const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);

                        modal.hide();
                        form.reset();
                        cargarCatalogoCalcetines(function () {
                            calcularVentaMultiple();
                        });

                        if (tablaEntradas) {
                            tablaEntradas.ajax.reload(null, false);
                        } else {
                            location.reload();
                        }
                    });
                } else {
                    mostrarErrorDetalle(
                        'Error',
                        resp && resp.message ? resp.message : 'No se pudo registrar la venta múltiple.',
                        resp && resp.debug ? resp.debug : ''
                    );
                    cargarCatalogoCalcetines(function () {
                        calcularVentaMultiple();
                    });
                }
            },
            error: function (xhr) {
                console.error(xhr.responseText);
                mostrarErrorDetalle(
                    'Error',
                    getMensajeAjax(xhr, 'No se pudo registrar la venta múltiple.'),
                    getDebugAjax(xhr)
                );
                cargarCatalogoCalcetines(function () {
                    calcularVentaMultiple();
                });
            },
            complete: function () {
                btn.prop('disabled', false).html(originalHtml);
            }
        });
    });


    if ($('#tablaEntradas').length && $.fn.DataTable) {
        tablaEntradas = $('#tablaEntradas').DataTable({
            processing: true,
            serverSide: true,
            scrollX: true,
            ajax: {
                url: BASE_URL + 'entradas/list',
                type: 'POST',
                error: function (xhr) {
                    console.error('Error DataTable entradas:', xhr.responseText);
                    Swal.fire('Error', getMensajeAjax(xhr, 'No se pudieron cargar las entradas.'), 'error');
                }
            },
            order: [[0, 'desc']],
            columns: [
                { data: 'id' },
                { data: 'tipo_entrada', render: d => nombreTipo(d) },
                { data: 'cantidad' },
                { data: 'precio_unitario', render: d => formatoMoneda(d) },
                { data: 'promocion_aplicada', render: d => d && d !== '' ? d : 'Sin promoción' },
                { data: 'descuento', render: d => formatoMoneda(d) },
                { data: 'cover', render: d => formatoMoneda(d) },
                { data: 'total', render: d => formatoMoneda(d) },
                { data: 'hora_entrada', render: d => d || '' },
                {
                    data: 'hora_salida_programada',
                    render: function (d, type, row) {
                        return row.tipo_entrada === 'ILIMITADO' ? 'Ilimitado' : (d || '');
                    }
                },
                { data: 'minutos_extra', render: d => Number(d || 0) + ' min' },
                { data: 'cargo_extra', render: d => formatoMoneda(d) },
                { data: 'estado_tiempo', render: d => formatoEstadoTiempo(d) },
                { data: 'metodo_pago' },
                { data: 'usuario' },
                { data: 'fecha_registro' },
                {
                    data: null,
                    orderable: false,
                    searchable: false,
                    render: function (row) {
                        let html = `
                            <a href="${BASE_URL}entradas/ticket?id=${row.id}"
                               target="_blank"
                               class="btn btn-sm btn-outline-secondary me-1"
                               title="Imprimir ticket">
                                <i class="bi bi-printer"></i>
                            </a>
                        `;

                        if (row.estado_tiempo !== 'FINALIZADA') {
                            html += `
                                <button type="button"
                                        class="btn btn-sm btn-primary btnRegistrarSalida"
                                        data-id="${row.id}">
                                    Salida
                                </button>
                            `;
                        }

                        return html;
                    }
                }
            ],
            language: {
                url: 'https://cdn.datatables.net/plug-ins/2.0.8/i18n/es-MX.json'
            }
        });
    }

    $(document).on('submit', '#formEntrada', function (e) {
        e.preventDefault();

        const form = this;
        const btn = $(form).find('button[type="submit"]');
        const originalHtml = btn.html();

        const datos = calcularEntrada();

        if (datos.tipo !== 'SOLO_COVER' && datos.tipo !== 'SOLO_CALCETINES' && datos.ninos <= 0) {
            Swal.fire('Validación', 'Debe capturar al menos 1 niño.', 'warning');
            return;
        }

        if (datos.tipo === 'SOLO_COVER' && datos.adultos <= 0) {
            Swal.fire('Validación', 'Debe capturar al menos 1 adulto.', 'warning');
            return;
        }

        if (datos.tipo !== 'SOLO_CALCETINES' && datos.precio <= 0) {
            Swal.fire('Validación', 'El precio unitario debe ser mayor a cero.', 'warning');
            return;
        }

        if (datos.pagaCon < datos.total) {
            Swal.fire('Pago insuficiente', 'El cliente debe pagar al menos ' + formatoMoneda(datos.total), 'warning');
            return;
        }

        $.ajax({
            url: $(form).attr('action'),
            type: 'POST',
            data: $(form).serialize(),
            dataType: 'json',
            beforeSend: function () {
                btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Guardando...');
            },
            success: function (resp) {
                if (resp && resp.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Entrada registrada',
                        html: `
                            <div class="text-start">
                                <p><strong>Tipo:</strong> ${datos.tipoNombre}</p>
                                <p><strong>Cantidad cobrada:</strong> ${datos.cantidad}</p>
                                <p><strong>Niños:</strong> ${datos.ninos}</p>
                                <p><strong>Adultos:</strong> ${datos.adultos}</p>
                                <p><strong>Subtotal:</strong> ${formatoMoneda(datos.subtotal)}</p>
                                <p><strong>Promoción:</strong> ${datos.promocion || 'Sin promoción'}</p>
                                <p><strong>Descuento:</strong> ${formatoMoneda(datos.descuento)}</p>
                                <p><strong>Cover:</strong> ${formatoMoneda(datos.cover)}</p>
                                <hr>
                                <p><strong>Total:</strong> ${formatoMoneda(datos.total)}</p>
                                <p><strong>Recibido:</strong> ${formatoMoneda(datos.pagaCon)}</p>
                                <p><strong>Cambio:</strong> ${formatoMoneda(datos.cambio)}</p>
                            </div>
                        `,
                        confirmButtonText: 'Imprimir ticket'
                    }).then(() => {
                        if (resp.id_entrada) {
                            window.open(BASE_URL + 'entradas/ticket?id=' + resp.id_entrada, '_blank');
                        }

                        const modalEl = document.getElementById('modalEntrada');
                        const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);

                        modal.hide();
                        form.reset();
                        limpiarCampos();

                        if (tablaEntradas) {
                            tablaEntradas.ajax.reload(null, false);
                        } else {
                            location.reload();
                        }
                    });
                } else {
                    Swal.fire('Error', resp && resp.message ? resp.message : 'No se pudo registrar.', 'error');
                }
            },
            error: function (xhr) {
                console.error(xhr.responseText);
                Swal.fire('Error', getMensajeAjax(xhr, 'No se pudo registrar la entrada.'), 'error');
            },
            complete: function () {
                btn.prop('disabled', false).html(originalHtml);
            }
        });
    });

    $(document).on('click', '.btnRegistrarSalida', function () {
        const id = $(this).data('id');

        $.ajax({
            url: BASE_URL + 'entradas/calcular-salida',
            type: 'POST',
            data: { id_entrada: id, id: id },
            dataType: 'json',
            success: function (resp) {
                if (!resp || !resp.success) {
                    Swal.fire('Error', resp && resp.message ? resp.message : 'No se pudo calcular la salida.', 'error');
                    return;
                }

                const d = resp.data;

                $('#salidaIdEntrada').val(d.id);
                $('#salidaFolio').text('#' + d.id);
                $('#salidaTipo').text(nombreTipo(d.tipo_entrada));
                $('#salidaHoraEntrada').text(d.hora_entrada || '');
                $('#salidaProgramada').text(d.hora_salida_programada || 'Ilimitado');
                $('#salidaReal').text(d.hora_salida_real_calculada || '');
                $('#salidaMinutosExtra').val((d.minutos_extra || 0) + ' min');
                const cargoExtraRedondeado = redondearCobro(d.cargo_extra || 0);
                $('#salidaCargoExtra').val(cargoExtraRedondeado);
                $('#salidaCargoExtraView').val(formatoMoneda(cargoExtraRedondeado));
                $('#pagaConExtra').val(cargoExtraRedondeado);

                if (Number(d.cargo_extra || 0) > 0) {
                    $('#boxPagoExtra').removeClass('d-none');
                    $('#boxSinExtra').addClass('d-none');
                } else {
                    $('#boxPagoExtra').addClass('d-none');
                    $('#boxSinExtra').removeClass('d-none');
                }

                calcularCambioExtra();

                const modal = new bootstrap.Modal(document.getElementById('modalSalida'));
                modal.show();
            },
            error: function (xhr) {
                console.error(xhr.responseText);
                Swal.fire('Error', getMensajeAjax(xhr, 'No se pudo calcular la salida.'), 'error');
            }
        });
    });

    $(document).on('submit', '#formSalida', function (e) {
        e.preventDefault();

        const form = this;
        const btn = $(form).find('button[type="submit"]');
        const originalHtml = btn.html();
        const pago = calcularCambioExtra();

        if (pago.pagaCon < pago.cargo) {
            Swal.fire('Pago insuficiente', 'El cliente debe pagar al menos ' + formatoMoneda(pago.cargo), 'warning');
            return;
        }

        $.ajax({
            url: $(form).attr('action'),
            type: 'POST',
            data: $(form).serialize(),
            dataType: 'json',
            beforeSend: function () {
                btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Registrando...');
            },
            success: function (resp) {
                if (!resp || !resp.success) {
                    Swal.fire('Error', resp && resp.message ? resp.message : 'No se pudo registrar la salida.', 'error');
                    return;
                }

                const d = resp.data || {};

                Swal.fire({
                    icon: 'success',
                    title: 'Salida registrada',
                    html: `
                        <div class="text-start">
                            <p><strong>Minutos extra:</strong> ${d.minutos_extra || 0} min</p>
                            <p><strong>Cargo extra:</strong> ${formatoMoneda(d.cargo_extra || 0)}</p>
                            <p><strong>Recibido extra:</strong> ${formatoMoneda(d.paga_con_extra || 0)}</p>
                            <p><strong>Cambio extra:</strong> ${formatoMoneda(d.cambio_extra || 0)}</p>
                        </div>
                    `
                }).then(() => {
                    const modalEl = document.getElementById('modalSalida');
                    const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);

                    modal.hide();

                    if (tablaEntradas) {
                        tablaEntradas.ajax.reload(null, false);
                    } else {
                        location.reload();
                    }
                });
            },
            error: function (xhr) {
                console.error(xhr.responseText);
                Swal.fire('Error', getMensajeAjax(xhr, 'No se pudo registrar la salida.'), 'error');
            },
            complete: function () {
                btn.prop('disabled', false).html(originalHtml);
            }
        });
    });

    function limpiarCampos() {
        $('#tipoEntrada').val('1_HORA');
        $('#ninos').val(0);
        $('#adultos').val(0);
        $('#cantidad').val(0);
        $('#precioUnitario').val('189.00');
        $('#precioUnitarioView').val('$189');
        $('#cover').val(0);
        $('#promocionAplicada').val('');
        $('#descuento').val(0);
        $('#subtotalEntradaView').val('$0');
        $('#descuentoEntradaView').val('$0');
        $('#coverEntradaView').val('$0');
        $('#totalEntrada').val('');
        $('#pagaCon').val('');
        $('#cambioEntrada').val('');
        $('#boxCover').addClass('d-none');
        $('#alertAdultos').addClass('d-none');
        $('#boxPromocion').removeClass('alert-info alert-warning').addClass('alert-secondary');
        $('#txtPromocion').text('Sin promoción');
        $('#cobrarCover').prop('checked', false);
        $('#esDiaFestivo').prop('checked', false);
        $('#txtAdultosExtra').text('0 adulto(s) extra');

        calcularEntrada();
    }

    $('#modalEntrada').on('hidden.bs.modal', function () {
        $('#formEntrada')[0].reset();
        limpiarCampos();
    });

    $('#modalEntrada').on('shown.bs.modal', function () {
        limpiarCampos();
    });


    $('.campoPagoMixto, #pagaConExtra, #pagaCon').attr('step', '1');

    cargarCatalogoCalcetines();
});