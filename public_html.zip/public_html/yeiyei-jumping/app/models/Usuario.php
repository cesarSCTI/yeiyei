<?php
require_once __DIR__ . '/Model.php';

class Usuario extends Model
{
    public function findByUsername(string $usuario): ?array
    {
        $stmt = $this->db->prepare("SELECT u.*, r.nombre AS rol FROM usuarios u INNER JOIN roles r ON r.id = u.id_rol WHERE u.usuario = ? AND u.estado = 1 LIMIT 1");
        $stmt->execute([$usuario]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function findById(int $id): ?array
    {
        $stmt = $this->db->prepare("SELECT id, id_rol, nombre, usuario, estado, fecha_registro FROM usuarios WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function roles(): array
    {
        $stmt = $this->db->query("SELECT id, nombre FROM roles ORDER BY id ASC");
        return $stmt->fetchAll();
    }

    public function listDataTables(int $start, int $length, string $search): array
    {
        $where = "WHERE 1=1";
        $params = [];

        if ($search !== '') {
            $where .= " AND (u.nombre LIKE ? OR u.usuario LIKE ? OR r.nombre LIKE ?)";
            $params = ["%$search%", "%$search%", "%$search%"];
        }

        $total = (int)$this->db->query("SELECT COUNT(*) FROM usuarios")->fetchColumn();

        $stmtCount = $this->db->prepare("
            SELECT COUNT(*)
            FROM usuarios u
            INNER JOIN roles r ON r.id = u.id_rol
            $where
        ");
        $stmtCount->execute($params);
        $filtered = (int)$stmtCount->fetchColumn();

        $stmt = $this->db->prepare("
            SELECT
                u.id,
                u.nombre,
                u.usuario,
                u.id_rol,
                r.nombre AS rol,
                u.estado,
                u.fecha_registro
            FROM usuarios u
            INNER JOIN roles r ON r.id = u.id_rol
            $where
            ORDER BY u.id DESC
            LIMIT :start, :length
        ");

        foreach ($params as $index => $value) {
            $stmt->bindValue($index + 1, $value, PDO::PARAM_STR);
        }

        $stmt->bindValue(':start', $start, PDO::PARAM_INT);
        $stmt->bindValue(':length', $length, PDO::PARAM_INT);
        $stmt->execute();

        return [
            'total' => $total,
            'filtered' => $filtered,
            'data' => $stmt->fetchAll()
        ];
    }

    public function usernameExists(string $usuario, int $excludeId = 0): bool
    {
        if ($excludeId > 0) {
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM usuarios WHERE usuario = ? AND id <> ?");
            $stmt->execute([$usuario, $excludeId]);
        } else {
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM usuarios WHERE usuario = ?");
            $stmt->execute([$usuario]);
        }

        return (int)$stmt->fetchColumn() > 0;
    }

    public function create(array $data): bool
    {
        $stmt = $this->db->prepare("
            INSERT INTO usuarios (id_rol, nombre, usuario, password, estado)
            VALUES (?, ?, ?, ?, 1)
        ");

        return $stmt->execute([
            (int)$data['id_rol'],
            trim($data['nombre']),
            trim($data['usuario']),
            password_hash($data['password'], PASSWORD_DEFAULT)
        ]);
    }

    public function updateUser(int $id, array $data): bool
    {
        $stmt = $this->db->prepare("
            UPDATE usuarios
            SET id_rol = ?, nombre = ?, usuario = ?
            WHERE id = ?
            LIMIT 1
        ");

        return $stmt->execute([
            (int)$data['id_rol'],
            trim($data['nombre']),
            trim($data['usuario']),
            $id
        ]);
    }

    public function updatePasswordHash(int $id, string $hash): bool
    {
        $stmt = $this->db->prepare("UPDATE usuarios SET password = ? WHERE id = ? LIMIT 1");
        return $stmt->execute([$hash, $id]);
    }

    public function changePassword(int $id, string $password): bool
    {
        return $this->updatePasswordHash($id, password_hash($password, PASSWORD_DEFAULT));
    }

    public function toggleStatus(int $id): bool
    {
        $stmt = $this->db->prepare("
            UPDATE usuarios
            SET estado = CASE WHEN estado = 1 THEN 0 ELSE 1 END
            WHERE id = ?
            LIMIT 1
        ");

        return $stmt->execute([$id]);
    }
}
