<?php
require_once __DIR__ . '/Model.php';

class Fiesta extends Model
{
    public function paquetes(): array
    {
        return $this->db->query("SELECT * FROM paquetes_fiesta WHERE estado=1 ORDER BY tipo_dia, personas")->fetchAll();
    }

    public function crear(array $d): bool
    {
        $stmtP = $this->db->prepare("SELECT * FROM paquetes_fiesta WHERE id=? AND estado=1");
        $stmtP->execute([$d['id_paquete']]);
        $p = $stmtP->fetch();

        if (!$p) {
            throw new Exception('El paquete seleccionado no existe o está inactivo.');
        }

        $total = (float)$p['precio'];
        $anticipo = max((float)$d['anticipo'], 0);

        if ($anticipo > $total) {
            throw new Exception('El anticipo no puede ser mayor al total del paquete.');
        }

        $saldo = max($total - $anticipo, 0);
        $horaInicio = strlen($d['hora_inicio']) === 5 ? $d['hora_inicio'] . ':00' : $d['hora_inicio'];
        $horaFin = date('H:i:s', strtotime($horaInicio . ' +5 hours'));

        $this->validarHorarioDisponible($d['fecha_evento'], $horaInicio, $horaFin);

        $this->db->beginTransaction();

        try {
            $estado = $saldo <= 0 ? 'PAGADO' : 'APARTADO';

            $stmt = $this->db->prepare("INSERT INTO reservaciones_fiesta(id_paquete,id_usuario,nombre_cliente,telefono,fecha_evento,hora_inicio,hora_fin,total,anticipo,saldo,estado,observaciones) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)");
            $stmt->execute([
                $d['id_paquete'],
                $d['id_usuario'],
                $d['nombre_cliente'],
                $d['telefono'],
                $d['fecha_evento'],
                $horaInicio,
                $horaFin,
                $total,
                $anticipo,
                $saldo,
                $estado,
                $d['observaciones']
            ]);

            $idReserva = (int)$this->db->lastInsertId();

            if ($anticipo > 0) {
                $this->registrarPagoIngreso($idReserva, (int)$d['id_usuario'], (int)$d['id_metodo_pago'], $anticipo, 'Anticipo inicial', 'Anticipo fiesta: ' . $d['nombre_cliente']);
            }

            $this->db->commit();
            return true;
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }
    }

    public function obtener(int $id): ?array
    {
        $stmt = $this->db->prepare("
            SELECT
                r.*,
                p.personas,
                p.tipo_dia,
                p.precio,
                u.nombre AS usuario
            FROM reservaciones_fiesta r
            INNER JOIN paquetes_fiesta p ON p.id = r.id_paquete
            INNER JOIN usuarios u ON u.id = r.id_usuario
            WHERE r.id = ?
            LIMIT 1
        ");
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function pagos(int $idReservacion): array
    {
        if (!$this->tablaExiste('pagos_fiesta')) {
            return [];
        }

        $stmt = $this->db->prepare("
            SELECT
                pf.*,
                u.nombre AS usuario,
                mp.nombre AS metodo_pago
            FROM pagos_fiesta pf
            INNER JOIN usuarios u ON u.id = pf.id_usuario
            INNER JOIN metodos_pago mp ON mp.id = pf.id_metodo_pago
            WHERE pf.id_reservacion = ?
            AND COALESCE(pf.estado, 1) = 1
            ORDER BY pf.id DESC
        ");
        $stmt->execute([$idReservacion]);
        return $stmt->fetchAll();
    }

    public function abonar(int $idReservacion, int $idUsuario, int $idMetodoPago, float $monto, string $observaciones = ''): bool
    {
        if ($monto <= 0) {
            throw new Exception('El monto debe ser mayor a cero.');
        }

        $reserva = $this->obtener($idReservacion);

        if (!$reserva) {
            throw new Exception('La reservación no existe.');
        }

        if ($reserva['estado'] === 'CANCELADO') {
            throw new Exception('No se puede abonar a una reservación cancelada.');
        }

        if ($reserva['estado'] === 'PAGADO' || (float)$reserva['saldo'] <= 0) {
            throw new Exception('La reservación ya está liquidada.');
        }

        $saldoActual = (float)$reserva['saldo'];

        if ($monto > $saldoActual) {
            throw new Exception('El abono no puede ser mayor al saldo pendiente.');
        }

        $nuevoAnticipo = (float)$reserva['anticipo'] + $monto;
        $nuevoSaldo = max((float)$reserva['total'] - $nuevoAnticipo, 0);
        $nuevoEstado = $nuevoSaldo <= 0 ? 'PAGADO' : 'APARTADO';

        $this->db->beginTransaction();

        try {
            $stmt = $this->db->prepare("UPDATE reservaciones_fiesta SET anticipo=?, saldo=?, estado=? WHERE id=?");
            $stmt->execute([$nuevoAnticipo, $nuevoSaldo, $nuevoEstado, $idReservacion]);

            $conceptoPago = $nuevoEstado === 'PAGADO' ? 'Liquidación de reservación' : 'Abono de reservación';
            $conceptoIngreso = ($nuevoEstado === 'PAGADO' ? 'Liquidación fiesta: ' : 'Abono fiesta: ') . $reserva['nombre_cliente'];

            $this->registrarPagoIngreso($idReservacion, $idUsuario, $idMetodoPago, $monto, $conceptoPago . ($observaciones ? ' - ' . $observaciones : ''), $conceptoIngreso);

            $this->db->commit();
            return true;
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }
    }

    public function liquidar(int $idReservacion, int $idUsuario, int $idMetodoPago): bool
    {
        $reserva = $this->obtener($idReservacion);

        if (!$reserva) {
            throw new Exception('La reservación no existe.');
        }

        $saldo = (float)$reserva['saldo'];

        if ($saldo <= 0 || $reserva['estado'] === 'PAGADO') {
            throw new Exception('La reservación ya está liquidada.');
        }

        return $this->abonar($idReservacion, $idUsuario, $idMetodoPago, $saldo, 'Liquidación total');
    }

    public function cancelar(int $idReservacion): bool
    {
        $reserva = $this->obtener($idReservacion);

        if (!$reserva) {
            throw new Exception('La reservación no existe.');
        }

        if ($reserva['estado'] === 'CANCELADO') {
            throw new Exception('La reservación ya está cancelada.');
        }

        $stmt = $this->db->prepare("UPDATE reservaciones_fiesta SET estado='CANCELADO' WHERE id=?");
        return $stmt->execute([$idReservacion]);
    }

    private function registrarPagoIngreso(int $idReserva, int $idUsuario, int $idMetodoPago, float $monto, string $conceptoPago, string $conceptoIngreso): void
    {
        if ($this->tablaExiste('pagos_fiesta')) {
            $stmtP = $this->db->prepare("INSERT INTO pagos_fiesta(id_reservacion,id_usuario,id_metodo_pago,monto,concepto,observaciones) VALUES(?,?,?,?,?,?)");
            $stmtP->execute([
                $idReserva,
                $idUsuario,
                $idMetodoPago,
                $monto,
                $conceptoPago,
                $conceptoPago
            ]);
        }

        $stmtI = $this->db->prepare("INSERT INTO ingresos(id_usuario,tipo,referencia_id,concepto,monto,id_metodo_pago) VALUES(?,?,?,?,?,?)");
        $stmtI->execute([
            $idUsuario,
            'FIESTA',
            $idReserva,
            $conceptoIngreso,
            $monto,
            $idMetodoPago
        ]);
    }

    private function validarHorarioDisponible(string $fecha, string $horaInicio, string $horaFin): void
    {
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM reservaciones_fiesta WHERE fecha_evento = ? AND estado <> 'CANCELADO' AND (? < hora_fin AND ? > hora_inicio)");
        $stmt->execute([$fecha, $horaInicio, $horaFin]);

        if ((int)$stmt->fetchColumn() > 0) {
            throw new Exception('El horario seleccionado ya está ocupado para esa fecha.');
        }
    }

    private function tablaExiste(string $tabla): bool
    {
        $stmt = $this->db->prepare("SHOW TABLES LIKE ?");
        $stmt->execute([$tabla]);
        return (bool)$stmt->fetchColumn();
    }

    public function listDataTables(int $start, int $length, string $search): array
    {
        $length = $length > 0 ? $length : 10;
        $where = "WHERE 1=1";
        $params = [];

        if ($search !== '') {
            $where .= " AND (r.nombre_cliente LIKE :search OR r.telefono LIKE :search OR r.estado LIKE :search)";
            $params[':search'] = "%$search%";
        }

        $total = (int)$this->db->query("SELECT COUNT(*) FROM reservaciones_fiesta")->fetchColumn();

        $stmtCount = $this->db->prepare("SELECT COUNT(*) FROM reservaciones_fiesta r INNER JOIN paquetes_fiesta p ON p.id=r.id_paquete $where");
        foreach ($params as $k => $v) {
            $stmtCount->bindValue($k, $v);
        }
        $stmtCount->execute();
        $filtered = (int)$stmtCount->fetchColumn();

        $stmt = $this->db->prepare("SELECT r.*, p.personas, p.tipo_dia, u.nombre AS usuario FROM reservaciones_fiesta r INNER JOIN paquetes_fiesta p ON p.id=r.id_paquete INNER JOIN usuarios u ON u.id=r.id_usuario $where ORDER BY r.id DESC LIMIT :start, :length");
        foreach ($params as $k => $v) {
            $stmt->bindValue($k, $v);
        }
        $stmt->bindValue(':start', (int)$start, PDO::PARAM_INT);
        $stmt->bindValue(':length', (int)$length, PDO::PARAM_INT);
        $stmt->execute();

        return [
            'total' => $total,
            'filtered' => $filtered,
            'data' => $stmt->fetchAll()
        ];
    }
}
