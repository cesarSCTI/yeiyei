<?php
require_once __DIR__ . '/Model.php';

class Dashboard extends Model
{
    public function resumenHoy(): array
    {
        $fecha = date('Y-m-d');

        $ingresos = $this->entero($this->sum("
            SELECT COALESCE(SUM(monto), 0)
            FROM ingresos
            WHERE DATE(fecha_registro) = ?
              AND estado = 1
        ", [$fecha]));

        $egresos = $this->entero($this->sum("
            SELECT COALESCE(SUM(monto), 0)
            FROM egresos
            WHERE DATE(fecha_registro) = ?
              AND estado = 1
        ", [$fecha]));

        $entradas = $this->entero($this->sum("
            SELECT COALESCE(SUM(total), 0)
            FROM entradas
            WHERE DATE(fecha_registro) = ?
              AND estado = 1
        ", [$fecha]));

        $fiestas = (int)$this->sum("
            SELECT COUNT(*)
            FROM reservaciones_fiesta
            WHERE fecha_evento = ?
              AND estado <> 'CANCELADO'
        ", [$fecha]);

        /*
         * Los importes por método se obtienen desde ingresos.
         * Esto respeta los pagos mixtos registrados en entrada_pagos/ingresos
         * y evita asignar toda una venta al método principal de entradas.
         */
        $efectivo = $this->ingresoPorMetodo($fecha, ['EFECTIVO']);
        $tarjeta = $this->ingresoPorMetodo($fecha, ['TARJETA', 'DEBITO', 'DÉBITO', 'CREDITO', 'CRÉDITO']);
        $transferencia = $this->ingresoPorMetodo($fecha, ['TRANSFER']);
        $cortesia = $this->ingresoPorMetodo($fecha, ['CORTESIA', 'CORTESÍA']);

        $cover = $this->entero($this->sum("
            SELECT COALESCE(SUM(cover), 0)
            FROM entradas
            WHERE DATE(fecha_registro) = ?
              AND estado = 1
        ", [$fecha]));

        $calcetines = $this->entero($this->sum("
            SELECT COALESCE(SUM(total_calcetines), 0)
            FROM entradas
            WHERE DATE(fecha_registro) = ?
              AND estado = 1
        ", [$fecha]));

        $tiempoExtra = $this->entero($this->sum("
            SELECT COALESCE(SUM(cargo_extra), 0)
            FROM entradas
            WHERE DATE(fecha_registro) = ?
              AND estado = 1
        ", [$fecha]));

        $balance = $ingresos - $egresos;
        $balanceEfectivo = $efectivo - $egresos;

        return [
            'ingresos' => $ingresos,
            'egresos' => $egresos,
            'balance' => $balance,
            'balance_efectivo' => $balanceEfectivo,

            'entradas' => $entradas,
            'fiestas' => $fiestas,
            'efectivo' => $efectivo,
            'tarjeta' => $tarjeta,
            'transferencia' => $transferencia,
            'cortesia' => $cortesia,
            'cover' => $cover,
            'calcetines' => $calcetines,
            'tiempo_extra' => $tiempoExtra
        ];
    }

    private function ingresoPorMetodo(string $fecha, array $palabras): int
    {
        if (count($palabras) === 0) {
            return 0;
        }

        $condiciones = [];
        $params = [$fecha];

        foreach ($palabras as $palabra) {
            $condiciones[] = "UPPER(mp.nombre) LIKE ?";
            $params[] = '%' . mb_strtoupper($palabra, 'UTF-8') . '%';
        }

        $sql = "
            SELECT COALESCE(SUM(i.monto), 0)
            FROM ingresos i
            INNER JOIN metodos_pago mp ON mp.id = i.id_metodo_pago
            WHERE DATE(i.fecha_registro) = ?
              AND i.estado = 1
              AND (" . implode(' OR ', $condiciones) . ")
        ";

        return $this->entero($this->sum($sql, $params));
    }

    private function entero(float $importe): int
    {
        return (int)round($importe, 0);
    }

    private function sum(string $sql, array $params): float
    {
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);

        return (float)$stmt->fetchColumn();
    }
}
