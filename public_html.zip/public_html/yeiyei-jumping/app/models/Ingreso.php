<?php
require_once __DIR__ . '/Model.php';

class Ingreso extends Model
{
    public function listDataTables(int $start, int $length, string $search): array
    {
        $where = "WHERE i.estado = 1 AND DATE(i.fecha_registro) = CURDATE()";
        $params = [];

        if ($search !== '') {
            $where .= " AND (i.concepto LIKE ? OR i.tipo LIKE ? OR u.nombre LIKE ? OR mp.nombre LIKE ?)";
            $params = ["%$search%", "%$search%", "%$search%", "%$search%"];
        }

        $stmtTotal = $this->db->prepare("
            SELECT COUNT(*)
            FROM ingresos i
            WHERE i.estado = 1
            AND DATE(i.fecha_registro) = CURDATE()
        ");
        $stmtTotal->execute();
        $total = (int)$stmtTotal->fetchColumn();

        $stmtCount = $this->db->prepare("
            SELECT COUNT(*)
            FROM ingresos i
            INNER JOIN usuarios u ON u.id = i.id_usuario
            INNER JOIN metodos_pago mp ON mp.id = i.id_metodo_pago
            $where
        ");
        $stmtCount->execute($params);
        $filtered = (int)$stmtCount->fetchColumn();

        $stmt = $this->db->prepare("
            SELECT
                i.*,
                u.nombre AS usuario,
                mp.nombre AS metodo_pago
            FROM ingresos i
            INNER JOIN usuarios u ON u.id = i.id_usuario
            INNER JOIN metodos_pago mp ON mp.id = i.id_metodo_pago
            $where
            ORDER BY i.id DESC
            LIMIT :start, :length
        ");

        foreach ($params as $index => $value) {
            $stmt->bindValue($index + 1, $value, PDO::PARAM_STR);
        }

        $stmt->bindValue(':start', $start, PDO::PARAM_INT);
        $stmt->bindValue(':length', $length, PDO::PARAM_INT);

        $stmt->execute();

        return [
            'total' => $total,
            'filtered' => $filtered,
            'data' => $stmt->fetchAll()
        ];
    }
}