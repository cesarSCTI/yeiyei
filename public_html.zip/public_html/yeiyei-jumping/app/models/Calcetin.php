<?php
require_once __DIR__ . '/Model.php';

class Calcetin extends Model
{
    public function findById(int $id): ?array
    {
        $stmt = $this->db->prepare("\n            SELECT\n                c.id,\n                c.precio,\n                c.stock_inicial,\n                c.stock,\n                c.stock AS existencias,\n                c.estado,\n                c.fecha_registro,\n                COALESCE(v.vendidos, 0) AS vendidos\n            FROM calcetines c\n            LEFT JOIN (\n                SELECT id_calcetin, SUM(cantidad) AS vendidos\n                FROM ventas_calcetines\n                GROUP BY id_calcetin\n            ) v ON v.id_calcetin = c.id\n            WHERE c.id = ?\n            LIMIT 1\n        ");

        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row ?: null;
    }

    public function listDataTables(int $start, int $length, string $search): array
    {
        $length = $length > 0 ? $length : 10;

        $where = "WHERE 1=1";
        $params = [];

        if ($search !== '') {
            $where .= "\n                AND (\n                    c.id LIKE :search\n                    OR c.precio LIKE :search\n                    OR c.stock_inicial LIKE :search\n                    OR c.stock LIKE :search\n                    OR COALESCE(v.vendidos, 0) LIKE :search\n                )\n            ";
            $params[':search'] = "%$search%";
        }

        $total = (int)$this->db->query("SELECT COUNT(*) FROM calcetines")->fetchColumn();

        $stmtCount = $this->db->prepare("\n            SELECT COUNT(*)\n            FROM calcetines c\n            LEFT JOIN (\n                SELECT id_calcetin, SUM(cantidad) AS vendidos\n                FROM ventas_calcetines\n                GROUP BY id_calcetin\n            ) v ON v.id_calcetin = c.id\n            $where\n        ");

        foreach ($params as $key => $value) {
            $stmtCount->bindValue($key, $value, PDO::PARAM_STR);
        }

        $stmtCount->execute();
        $filtered = (int)$stmtCount->fetchColumn();

        $stmt = $this->db->prepare("\n            SELECT\n                c.id,\n                c.precio,\n                c.stock_inicial,\n                COALESCE(v.vendidos, 0) AS vendidos,\n                c.stock AS existencias,\n                c.stock,\n                c.estado,\n                c.fecha_registro\n            FROM calcetines c\n            LEFT JOIN (\n                SELECT id_calcetin, SUM(cantidad) AS vendidos\n                FROM ventas_calcetines\n                GROUP BY id_calcetin\n            ) v ON v.id_calcetin = c.id\n            $where\n            ORDER BY c.id DESC\n            LIMIT :start, :length\n        ");

        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value, PDO::PARAM_STR);
        }

        $stmt->bindValue(':start', $start, PDO::PARAM_INT);
        $stmt->bindValue(':length', $length, PDO::PARAM_INT);
        $stmt->execute();

        return [
            'total' => $total,
            'filtered' => $filtered,
            'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)
        ];
    }

    public function create(array $data): bool
    {
        $stockInicial = (int)($data['stock_inicial'] ?? 0);

        $stmt = $this->db->prepare("\n            INSERT INTO calcetines\n            (precio, stock_inicial, stock, estado)\n            VALUES (?, ?, ?, 1)\n        ");

        return $stmt->execute([
            (float)$data['precio'],
            $stockInicial,
            $stockInicial
        ]);
    }

    public function updateCalcetin(int $id, array $data): bool
    {
        $row = $this->findById($id);

        if (!$row) {
            return false;
        }

        $stockInicial = (int)($data['stock_inicial'] ?? 0);
        $vendidos = (int)($row['vendidos'] ?? 0);
        $existencias = $stockInicial - $vendidos;

        if ($existencias < 0) {
            throw new Exception('El stock inicial no puede ser menor a los calcetines vendidos.');
        }

        $stmt = $this->db->prepare("\n            UPDATE calcetines\n            SET precio = ?,\n                stock_inicial = ?,\n                stock = ?\n            WHERE id = ?\n            LIMIT 1\n        ");

        return $stmt->execute([
            (float)$data['precio'],
            $stockInicial,
            $existencias,
            $id
        ]);
    }

    public function toggleStatus(int $id): bool
    {
        $stmt = $this->db->prepare("\n            UPDATE calcetines\n            SET estado = CASE WHEN estado = 1 THEN 0 ELSE 1 END\n            WHERE id = ?\n            LIMIT 1\n        ");

        return $stmt->execute([$id]);
    }

    public function adjustStock(int $id, int $cantidad): bool
    {
        if ($cantidad > 0) {
            $stmt = $this->db->prepare("\n                UPDATE calcetines\n                SET stock = stock + ?,\n                    stock_inicial = stock_inicial + ?\n                WHERE id = ?\n                LIMIT 1\n            ");

            return $stmt->execute([
                $cantidad,
                $cantidad,
                $id
            ]);
        }

        $stmt = $this->db->prepare("\n            UPDATE calcetines\n            SET stock = stock + ?\n            WHERE id = ?\n            AND stock + ? >= 0\n            LIMIT 1\n        ");

        return $stmt->execute([
            $cantidad,
            $id,
            $cantidad
        ]);
    }

    public function activos(): array
    {
        $stmt = $this->db->query("\n            SELECT\n                id,\n                precio,\n                stock,\n                stock AS existencias,\n                estado\n            FROM calcetines\n            WHERE estado = 1\n            AND stock > 0\n            ORDER BY id DESC\n        ");

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
