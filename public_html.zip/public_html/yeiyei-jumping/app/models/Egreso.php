<?php
require_once __DIR__ . '/Model.php';

class Egreso extends Model
{
    public function crear(array $d): bool
    {
        $stmt = $this->db->prepare("INSERT INTO egresos(id_usuario,concepto,monto,observaciones) VALUES(?,?,?,?)");
        return $stmt->execute([
            $d['id_usuario'],
            $d['concepto'],
            $d['monto'],
            $d['observaciones']
        ]);
    }

    public function listDataTables(int $start, int $length, string $search): array
    {
        $length = $length > 0 ? $length : 10;
        $where = "WHERE e.estado=1 AND DATE(e.fecha_registro) = CURDATE()";
        $params = [];

        if ($search !== '') {
            $where .= " AND (e.concepto LIKE :search OR u.nombre LIKE :search)";
            $params[':search'] = "%$search%";
        }

        $total = (int)$this->db->query("SELECT COUNT(*) FROM egresos WHERE estado=1")->fetchColumn();

        $stmtCount = $this->db->prepare("SELECT COUNT(*) FROM egresos e INNER JOIN usuarios u ON u.id=e.id_usuario $where");
        foreach ($params as $k => $v) {
            $stmtCount->bindValue($k, $v);
        }
        $stmtCount->execute();
        $filtered = (int)$stmtCount->fetchColumn();

        $stmt = $this->db->prepare("SELECT e.*, u.nombre AS usuario FROM egresos e INNER JOIN usuarios u ON u.id=e.id_usuario $where ORDER BY e.id DESC LIMIT :start, :length");
        foreach ($params as $k => $v) {
            $stmt->bindValue($k, $v);
        }
        $stmt->bindValue(':start', (int)$start, PDO::PARAM_INT);
        $stmt->bindValue(':length', (int)$length, PDO::PARAM_INT);
        $stmt->execute();

        return [
            'total' => $total,
            'filtered' => $filtered,
            'data' => $stmt->fetchAll()
        ];
    }
}
