<?php
require_once __DIR__ . '/Model.php';

class Entrada extends Model
{
    private const CARGO_EXTRA_15_MIN = 40.00;

    private function redondearCobro(float $importe): float
    {
        return (float)round($importe, 0);
    }

    public function prepararCalcetinVenta(int $idCalcetin, int $cantidadCalcetin): ?array
    {
        if ($idCalcetin <= 0 && $cantidadCalcetin <= 0) {
            return null;
        }

        if ($idCalcetin <= 0 || $cantidadCalcetin <= 0) {
            throw new Exception('Selecciona el calcetín y captura una cantidad válida.');
        }

        $stmt = $this->db->prepare("
            SELECT
                id,
                precio,
                stock,
                estado
            FROM calcetines
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([$idCalcetin]);
        $producto = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$producto) {
            throw new Exception('El calcetín seleccionado no existe.');
        }

        if ((int)$producto['estado'] !== 1) {
            throw new Exception('El calcetín seleccionado está inactivo.');
        }

        if ((int)$producto['stock'] < $cantidadCalcetin) {
            throw new Exception('Stock insuficiente de calcetines. Disponible: ' . (int)$producto['stock']);
        }

        $precio = (float)$producto['precio'];
        $total = $precio * $cantidadCalcetin;

        return [
            'id_calcetin' => (int)$producto['id'],
            'cantidad' => $cantidadCalcetin,
            'precio_unitario' => $precio,
            'total' => $total
        ];
    }

    public function crear(array $d): int
    {
        $this->db->beginTransaction();

        try {
            $duracionMinutos = $this->duracionMinutos($d['tipo_entrada']);

            $horaEntrada = $d['fecha_registro'] ?? date('Y-m-d H:i:s');
            $horaSalidaProgramada = null;

            if ($duracionMinutos > 0) {
                $horaSalidaProgramada = date('Y-m-d H:i:s', strtotime($horaEntrada . " +{$duracionMinutos} minutes"));
            }

            $estadoTiempo = in_array($d['tipo_entrada'], ['SOLO_COVER', 'SOLO_CALCETINES'], true)
                ? 'FINALIZADA'
                : 'ACTIVA';

            $totalCalcetines = (float)($d['total_calcetines'] ?? 0);

            $stmt = $this->db->prepare("
                INSERT INTO entradas
                (
                    id_usuario,
                    adultos,
                    ninos,
                    tipo_entrada,
                    cantidad,
                    precio_unitario,
                    total,
                    cover,
                    total_calcetines,
                    promocion_aplicada,
                    descuento,
                    es_dia_festivo,
                    paga_con,
                    cambio,
                    id_metodo_pago,
                    hora_entrada,
                    hora_salida_programada,
                    estado_tiempo,
                    fecha_registro
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $d['id_usuario'],
                $d['adultos'],
                $d['ninos'],
                $d['tipo_entrada'],
                $d['cantidad'],
                $d['precio_unitario'],
                $d['total'],
                $d['cover'],
                $totalCalcetines,
                $d['promocion_aplicada'],
                $d['descuento'],
                $d['es_dia_festivo'],
                $d['paga_con'],
                $d['cambio'],
                $d['id_metodo_pago'],
                $horaEntrada,
                $horaSalidaProgramada,
                $estadoTiempo,
                $horaEntrada
            ]);

            $idEntrada = (int)$this->db->lastInsertId();

            $calcetinVenta = $d['calcetin_venta'] ?? null;

            if ($calcetinVenta && (int)$calcetinVenta['cantidad'] > 0) {
                $stmtStock = $this->db->prepare("
                    UPDATE calcetines
                    SET stock = stock - ?
                    WHERE id = ?
                    AND estado = 1
                    AND stock >= ?
                ");

                $stmtStock->execute([
                    (int)$calcetinVenta['cantidad'],
                    (int)$calcetinVenta['id_calcetin'],
                    (int)$calcetinVenta['cantidad']
                ]);

                if ($stmtStock->rowCount() <= 0) {
                    throw new Exception('No se pudo descontar el stock de calcetines.');
                }

                $stmtVentaCalcetin = $this->db->prepare("
                    INSERT INTO ventas_calcetines
                    (
                        id_entrada,
                        id_calcetin,
                        id_usuario,
                        cantidad,
                        precio_unitario,
                        total
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                ");

                $stmtVentaCalcetin->execute([
                    $idEntrada,
                    (int)$calcetinVenta['id_calcetin'],
                    (int)$d['id_usuario'],
                    (int)$calcetinVenta['cantidad'],
                    (float)$calcetinVenta['precio_unitario'],
                    (float)$calcetinVenta['total']
                ]);
            }

            $registrarIngreso = array_key_exists('registrar_ingreso', $d)
                ? (bool)$d['registrar_ingreso']
                : true;

            if ($registrarIngreso) {
                $concepto = match ($d['tipo_entrada']) {
                    'SOLO_COVER' => 'Venta de cover',
                    'SOLO_CALCETINES' => 'Venta de calcetines',
                    default => 'Venta de entradas'
                };

                if (!empty($d['promocion_aplicada'])) {
                    $concepto .= ' - ' . $d['promocion_aplicada'];
                }

                if ((float)$d['cover'] > 0) {
                    $concepto .= ' + cover adultos extra';
                }

                if ($totalCalcetines > 0) {
                    $concepto .= ' + calcetines';
                }

                $stmtIngreso = $this->db->prepare("
                    INSERT INTO ingresos
                    (
                        id_usuario,
                        tipo,
                        referencia_id,
                        concepto,
                        monto,
                        id_metodo_pago
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                ");

                $stmtIngreso->execute([
                    $d['id_usuario'],
                    'ENTRADA',
                    $idEntrada,
                    $concepto,
                    $d['total'],
                    $d['id_metodo_pago']
                ]);
            }

            $this->db->commit();

            return $idEntrada;

        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            throw $e;
        }
    }

    public function registrarPagoEntrada(
        int $idEntrada,
        int $idUsuario,
        int $idMetodoPago,
        float $importe,
        string $concepto = 'Pago de entrada'
    ): void {
        $importe = $this->redondearCobro($importe);

        if ($idEntrada <= 0 || $idMetodoPago <= 0 || $importe <= 0) {
            return;
        }

        $stmtPago = $this->db->prepare("
            INSERT INTO entrada_pagos
            (
                id_entrada,
                id_metodo_pago,
                importe,
                fecha_registro
            )
            VALUES (?, ?, ?, NOW())
        ");

        $stmtPago->execute([
            $idEntrada,
            $idMetodoPago,
            $importe
        ]);

        $stmtIngreso = $this->db->prepare("
            INSERT INTO ingresos
            (
                id_usuario,
                tipo,
                referencia_id,
                concepto,
                monto,
                id_metodo_pago
            )
            VALUES (?, ?, ?, ?, ?, ?)
        ");

        $stmtIngreso->execute([
            $idUsuario,
            'ENTRADA',
            $idEntrada,
            $concepto,
            $importe,
            $idMetodoPago
        ]);
    }


    public function listDataTables(int $start, int $length, string $search): array
    {
        $length = $length > 0 ? $length : 10;

        $where = "WHERE e.estado = 1 AND DATE(e.fecha_registro) = CURDATE()";
        $params = [];

        if ($search !== '') {
            $where .= " AND (
                e.id LIKE :search
                OR e.tipo_entrada LIKE :search
                OR e.promocion_aplicada LIKE :search
                OR e.estado_tiempo LIKE :search
                OR u.nombre LIKE :search
                OR mp.nombre LIKE :search
            )";

            $params[':search'] = "%$search%";
        }

        $stmtTotal = $this->db->query("
            SELECT COUNT(*)
            FROM entradas e
            WHERE e.estado = 1
            AND DATE(e.fecha_registro) = CURDATE()
        ");

        $total = (int)$stmtTotal->fetchColumn();

        $stmtCount = $this->db->prepare("
            SELECT COUNT(*)
            FROM entradas e
            INNER JOIN usuarios u ON u.id = e.id_usuario
            INNER JOIN metodos_pago mp ON mp.id = e.id_metodo_pago
            $where
        ");

        foreach ($params as $key => $value) {
            $stmtCount->bindValue($key, $value, PDO::PARAM_STR);
        }

        $stmtCount->execute();

        $filtered = (int)$stmtCount->fetchColumn();

        $stmt = $this->db->prepare("
            SELECT
                e.id,
                e.adultos,
                e.ninos,
                e.tipo_entrada,
                e.cantidad,
                e.precio_unitario,
                e.promocion_aplicada,
                e.descuento,
                e.cover,
                e.total_calcetines,
                COALESCE((
                    SELECT GROUP_CONCAT(
                        CONCAT('Calcetines x', vc.cantidad)
                        SEPARATOR ', '
                    )
                    FROM ventas_calcetines vc
                    WHERE vc.id_entrada = e.id
                ), '') AS calcetines,
                e.total,
                e.paga_con,
                e.cambio,

                e.hora_entrada,
                e.hora_salida_programada,
                e.hora_salida_real,
                e.minutos_extra,
                e.cargo_extra,
                e.paga_con_extra,
                e.cambio_extra,
                e.estado_tiempo,

                mp.nombre AS metodo_pago,
                u.nombre AS usuario,
                e.fecha_registro

            FROM entradas e
            INNER JOIN usuarios u ON u.id = e.id_usuario
            INNER JOIN metodos_pago mp ON mp.id = e.id_metodo_pago
            $where
            ORDER BY e.id DESC
            LIMIT :start, :length
        ");

        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value, PDO::PARAM_STR);
        }

        $stmt->bindValue(':start', $start, PDO::PARAM_INT);
        $stmt->bindValue(':length', $length, PDO::PARAM_INT);

        $stmt->execute();

        return [
            'total' => $total,
            'filtered' => $filtered,
            'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)
        ];
    }

    public function obtenerTicket(int $id): ?array
    {
        $stmt = $this->db->prepare("
            SELECT
                e.*,
                COALESCE(mp.nombre, '') AS metodo_pago,
                COALESCE(u.nombre, '') AS usuario
            FROM entradas e
            LEFT JOIN usuarios u ON u.id = e.id_usuario
            LEFT JOIN metodos_pago mp ON mp.id = e.id_metodo_pago
            WHERE e.id = ?
            LIMIT 1
        ");

        $stmt->execute([$id]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row ?: null;
    }


    public function obtenerGrupoTicket(int $idEntrada): array
    {
        $entrada = $this->obtenerTicket($idEntrada);

        if (!$entrada) {
            return [];
        }

        $stmt = $this->db->prepare("
            SELECT
                e.*,
                COALESCE(mp.nombre, '') AS metodo_pago,
                COALESCE(u.nombre, '') AS usuario
            FROM entradas e
            LEFT JOIN usuarios u ON u.id = e.id_usuario
            LEFT JOIN metodos_pago mp ON mp.id = e.id_metodo_pago
            WHERE e.estado = 1
              AND e.id_usuario = ?
              AND e.id_metodo_pago = ?
              AND e.fecha_registro = ?
            ORDER BY e.id ASC
        ");

        $stmt->execute([
            (int)$entrada['id_usuario'],
            (int)$entrada['id_metodo_pago'],
            $entrada['fecha_registro']
        ]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerCalcetinesTickets(array $ids): array
    {
        $ids = array_values(array_filter(array_map('intval', $ids), fn($id) => $id > 0));

        if (count($ids) === 0) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($ids), '?'));

        $stmt = $this->db->prepare("
            SELECT
                vc.id_entrada,
                vc.cantidad,
                vc.precio_unitario,
                vc.total,
                'Calcetines' AS nombre,
                '' AS talla
            FROM ventas_calcetines vc
            WHERE vc.id_entrada IN ($placeholders)
            ORDER BY vc.id ASC
        ");

        $stmt->execute($ids);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerCalcetinesTicket(int $idEntrada): array
    {
        $stmt = $this->db->prepare("
            SELECT
                vc.cantidad,
                vc.precio_unitario,
                vc.total,
                'Calcetines' AS nombre,
                '' AS talla
            FROM ventas_calcetines vc
            WHERE vc.id_entrada = ?
            ORDER BY vc.id ASC
        ");

        $stmt->execute([$idEntrada]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function calcularSalida(int $idEntrada): ?array
    {
        $entrada = $this->obtenerTicket($idEntrada);

        if (!$entrada) {
            return null;
        }

        if ($entrada['estado_tiempo'] === 'FINALIZADA') {
            return [
                'id' => (int)$entrada['id'],
                'tipo_entrada' => $entrada['tipo_entrada'],
                'hora_entrada' => $entrada['hora_entrada'],
                'hora_salida_programada' => $entrada['hora_salida_programada'],
                'hora_salida_real_calculada' => $entrada['hora_salida_real'],
                'minutos_extra' => (int)$entrada['minutos_extra'],
                'cargo_extra' => (float)$entrada['cargo_extra'],
                'estado_tiempo' => $entrada['estado_tiempo']
            ];
        }

        $salidaReal = date('Y-m-d H:i:s');

        if ($entrada['tipo_entrada'] === 'ILIMITADO') {
            return [
                'id' => (int)$entrada['id'],
                'tipo_entrada' => $entrada['tipo_entrada'],
                'hora_entrada' => $entrada['hora_entrada'],
                'hora_salida_programada' => null,
                'hora_salida_real_calculada' => $salidaReal,
                'minutos_extra' => 0,
                'cargo_extra' => 0.00,
                'estado_tiempo' => $entrada['estado_tiempo']
            ];
        }

        if (empty($entrada['hora_salida_programada'])) {
            return [
                'id' => (int)$entrada['id'],
                'tipo_entrada' => $entrada['tipo_entrada'],
                'hora_entrada' => $entrada['hora_entrada'],
                'hora_salida_programada' => null,
                'hora_salida_real_calculada' => $salidaReal,
                'minutos_extra' => 0,
                'cargo_extra' => 0.00,
                'estado_tiempo' => $entrada['estado_tiempo']
            ];
        }

        $programada = strtotime($entrada['hora_salida_programada']);
        $real = strtotime($salidaReal);

        $minutosExtra = 0;
        $cargoExtra = 0.00;

        if ($real > $programada) {
            $minutosExtra = (int)ceil(($real - $programada) / 60);

            if ($minutosExtra >= 15) {
                $bloques = (int)floor($minutosExtra / 15);
                $cargoExtra = $bloques * self::CARGO_EXTRA_15_MIN;
            } else {
                $cargoExtra = 0.00;
            }
        }

        return [
            'id' => (int)$entrada['id'],
            'tipo_entrada' => $entrada['tipo_entrada'],
            'hora_entrada' => $entrada['hora_entrada'],
            'hora_salida_programada' => $entrada['hora_salida_programada'],
            'hora_salida_real_calculada' => $salidaReal,
            'minutos_extra' => $minutosExtra,
            'cargo_extra' => $cargoExtra,
            'estado_tiempo' => $entrada['estado_tiempo']
        ];
    }

    public function registrarSalida(
        int $idEntrada,
        int $idUsuario,
        int $idMetodoPago,
        float $pagaConExtra
    ): array {
        $this->db->beginTransaction();

        try {
            $calculo = $this->calcularSalida($idEntrada);

            if (!$calculo) {
                throw new Exception('No se encontró la entrada.');
            }

            $entrada = $this->obtenerTicket($idEntrada);

            if (!$entrada) {
                throw new Exception('No se encontró la entrada.');
            }

            if ($entrada['estado_tiempo'] === 'FINALIZADA') {
                throw new Exception('La entrada ya fue finalizada.');
            }

            $cargoExtra = $this->redondearCobro((float)$calculo['cargo_extra']);
            $pagaConExtra = $this->redondearCobro($pagaConExtra);
            $minutosExtra = (int)$calculo['minutos_extra'];
            $salidaReal = $calculo['hora_salida_real_calculada'];

            if ($pagaConExtra < $cargoExtra) {
                throw new Exception('Pago insuficiente para cubrir el cargo extra.');
            }

            $cambioExtra = $this->redondearCobro($pagaConExtra - $cargoExtra);

            $stmt = $this->db->prepare("
                UPDATE entradas
                SET
                    hora_salida_real = ?,
                    minutos_extra = ?,
                    cargo_extra = ?,
                    paga_con_extra = ?,
                    cambio_extra = ?,
                    estado_tiempo = 'FINALIZADA'
                WHERE id = ?
            ");

            $stmt->execute([
                $salidaReal,
                $minutosExtra,
                $cargoExtra,
                $pagaConExtra,
                $cambioExtra,
                $idEntrada
            ]);

            if ($cargoExtra > 0) {
                $stmtIngreso = $this->db->prepare("
                    INSERT INTO ingresos
                    (
                        id_usuario,
                        tipo,
                        referencia_id,
                        concepto,
                        monto,
                        id_metodo_pago
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                ");

                $stmtIngreso->execute([
                    $idUsuario,
                    'ENTRADA',
                    $idEntrada,
                    'Cargo extra por tiempo excedido',
                    $cargoExtra,
                    $idMetodoPago
                ]);
            }

            $this->db->commit();

            return [
                'id' => $idEntrada,
                'hora_salida_real' => $salidaReal,
                'minutos_extra' => $minutosExtra,
                'cargo_extra' => $cargoExtra,
                'paga_con_extra' => $pagaConExtra,
                'cambio_extra' => $cambioExtra,
                'estado_tiempo' => 'FINALIZADA'
            ];

        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            throw $e;
        }
    }

    private function duracionMinutos(string $tipoEntrada): int
    {
        return match ($tipoEntrada) {
            '1_HORA' => 60,
            '2_HORAS' => 120,
            'ILIMITADO' => 0,
            'SOLO_COVER' => 0,
            'SOLO_CALCETINES' => 0,
            default => 60
        };
    }
}
