<h3>Acceso restringido</h3><p>No tienes permisos para ver esta sección.</p>
