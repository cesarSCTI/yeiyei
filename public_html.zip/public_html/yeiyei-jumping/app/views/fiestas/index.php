<?php
require_once __DIR__ . '/../layouts/header.php';
require_once __DIR__ . '/../layouts/sidebar.php';
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h4 class="mb-1">Área de Fiestas</h4>
            <small class="text-muted">Reservaciones, anticipos, abonos y liquidaciones.</small>
        </div>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalFiesta">
            <i class="bi bi-plus-circle"></i> Nueva reservación
        </button>
    </div>

    <div class="card">
        <div class="card-body">
            <table id="tablaFiestas" class="table table-striped table-hover w-100 align-middle">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Cliente</th>
                        <th>Teléfono</th>
                        <th>Fecha</th>
                        <th>Horario</th>
                        <th>Paquete</th>
                        <th>Total</th>
                        <th>Anticipo</th>
                        <th>Saldo</th>
                        <th>Estado</th>
                        <th width="180">Acciones</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="modalFiesta" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <form id="formFiesta" method="POST" action="<?= base_url('fiestas/store') ?>" class="modal-content" autocomplete="off">
            <div class="modal-header">
                <h5 class="modal-title">Nueva reservación</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body row g-3">
                <div class="col-md-6">
                    <label class="form-label">Cliente</label>
                    <input name="nombre_cliente" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Teléfono</label>
                    <input name="telefono" class="form-control">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Fecha evento</label>
                    <input type="date" name="fecha_evento" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Hora inicio</label>
                    <input type="time" name="hora_inicio" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Paquete</label>
                    <select name="id_paquete" class="form-select" required>
                        <option value="">Seleccione paquete</option>
                        <?php foreach ($paquetes as $p): ?>
                            <option value="<?= (int)$p['id'] ?>">
                                <?= htmlspecialchars($p['tipo_dia']) ?> - <?= (int)$p['personas'] ?> personas - $<?= number_format((float)$p['precio'], 2) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Anticipo</label>
                    <input type="number" step="0.01" name="anticipo" class="form-control" value="0" min="0">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Método</label>
                    <select name="id_metodo_pago" class="form-select">
                        <option value="1">Efectivo</option>
                        <option value="2">Tarjeta</option>
                        <option value="3">Transferencia</option>
                    </select>
                </div>
                <div class="col-12">
                    <label class="form-label">Observaciones</label>
                    <textarea name="observaciones" class="form-control"></textarea>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-primary">Guardar</button>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="modalDetalleFiesta" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Detalle de reservación</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="detalleFiestaContenido"></div>
                <hr>
                <h6 class="fw-bold">Historial de pagos</h6>
                <div class="table-responsive">
                    <table class="table table-sm table-striped align-middle">
                        <thead>
                            <tr>
                                <th>Fecha</th>
                                <th>Concepto</th>
                                <th>Monto</th>
                                <th>Método</th>
                                <th>Usuario</th>
                            </tr>
                        </thead>
                        <tbody id="detalleFiestaPagos"></tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalAbonoFiesta" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <form id="formAbonoFiesta" method="POST" action="<?= base_url('fiestas/abonar') ?>" class="modal-content" autocomplete="off">
            <div class="modal-header">
                <h5 class="modal-title">Registrar abono</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="id" id="abono_id_reservacion">

                <div class="alert alert-info mb-3" id="abono_info_reserva"></div>

                <div class="mb-3">
                    <label class="form-label">Monto a abonar</label>
                    <input type="number" step="0.01" min="0.01" name="monto" id="abono_monto" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Método de pago</label>
                    <select name="id_metodo_pago" class="form-select" required>
                        <option value="1">Efectivo</option>
                        <option value="2">Tarjeta</option>
                        <option value="3">Transferencia</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Observaciones</label>
                    <textarea name="observaciones" class="form-control"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-success">Guardar abono</button>
            </div>
        </form>
    </div>
</div>

<?php $extra_js = ['fiestas.js']; ?>
<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
