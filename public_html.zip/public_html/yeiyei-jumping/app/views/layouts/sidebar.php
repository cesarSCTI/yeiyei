<aside class="sidebar">
    <div class="brand"><i class="bi bi-stars"></i> YeiYei</div>
    <nav class="nav flex-column">
        <a class="nav-link" href="<?= base_url('dashboard') ?>"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <a class="nav-link" href="<?= base_url('entradas') ?>"><i class="bi bi-ticket-perforated"></i> Entradas</a>
        <a class="nav-link" href="<?= base_url('fiestas') ?>"><i class="bi bi-balloon-heart"></i> Área de Fiestas</a>
        <?php if ((int)($_SESSION['user']['id_rol'] ?? 0) === 1): ?>
        <a class="nav-link" href="<?= base_url('ingresos') ?>"><i class="bi bi-cash-coin"></i> Ingresos</a>
        <a class="nav-link" href="<?= base_url('egresos') ?>"><i class="bi bi-wallet2"></i> Egresos</a>
        <a class="nav-link" href="<?= base_url('cortes') ?>"><i class="bi bi-clipboard-data"></i> Cortes</a>
        <a class="nav-link" href="<?= base_url('usuarios') ?>"><i class="bi bi-people"></i> Usuarios</a>
        <?php endif; ?>
        <a class="nav-link" href="<?= base_url('calcetines') ?>"><i class="bi bi-bag"></i> Calcetines</a>        
        <a class="nav-link text-danger" href="<?= base_url('logout') ?>"><i class="bi bi-box-arrow-right"></i> Salir</a>
    </nav>
</aside>
<main class="content">
<header class="topbar">
    <div><strong><?= APP_NAME ?></strong></div>
    <div><?= htmlspecialchars($_SESSION['user']['nombre'] ?? '') ?> <span class="badge bg-primary"><?= htmlspecialchars($_SESSION['user']['rol'] ?? '') ?></span></div>
</header>
