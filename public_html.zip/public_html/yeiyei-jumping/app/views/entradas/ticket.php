<?php
$grupoEntradas = $grupoEntradas ?? [];

if (empty($grupoEntradas) && !empty($entrada)) {
    $grupoEntradas = [$entrada];
}

$entradaBase = $entrada ?? ($grupoEntradas[0] ?? []);
$ticketId = (int)($entradaBase['id'] ?? 0);
$esTicketMultiple = count($grupoEntradas) > 1;

$metodo = $entradaBase['metodo_pago'] ?? '';
$usuario = $entradaBase['usuario'] ?? '';
$fecha = $entradaBase['fecha_registro'] ?? '';
$horaEntrada = $entradaBase['hora_entrada'] ?? '';
$horaSalida = $entradaBase['hora_salida_programada'] ?? '';

$fechaTicket = $fecha;
if (!empty($fecha) && ($ts = strtotime($fecha)) !== false) {
    $fechaTicket = date('d/m/Y H:i', $ts);
}

$horaEntradaTicket = $horaEntrada;
if (!empty($horaEntrada) && ($ts = strtotime($horaEntrada)) !== false) {
    $horaEntradaTicket = date('d/m/Y H:i', $ts);
}

$calcetines = $calcetines ?? [];

function ticketTipoNombre(string $tipo): string
{
    return match ($tipo) {
        '1_HORA' => '1 Hora',
        '2_HORAS' => '2 Horas',
        'ILIMITADO' => 'Ilimitado',
        'SOLO_COVER' => 'Sólo Cover',
        'SOLO_CALCETINES' => 'Sólo Calcetines',
        default => $tipo
    };
}

function ticketSalidaTexto(array $entrada): string
{
    $tipo = $entrada['tipo_entrada'] ?? '';

    if ($tipo === 'ILIMITADO') {
        return 'Ilimitado';
    }

    if (in_array($tipo, ['SOLO_COVER', 'SOLO_CALCETINES'], true)) {
        return 'No aplica';
    }

    if (empty($entrada['hora_salida_programada'])) {
        return 'No aplica';
    }

    $salida = (string)$entrada['hora_salida_programada'];
    $ts = strtotime($salida);

    return $ts !== false ? date('d/m/Y H:i', $ts) : $salida;
}

$totalGeneral = 0.00;
$subtotalGeneral = 0.00;
$descuentoGeneral = 0.00;
$coverGeneral = 0.00;
$totalCalcetines = 0.00;

foreach ($grupoEntradas as $e) {
    $cantidad = (int)($e['cantidad'] ?? 0);
    $precio = (float)($e['precio_unitario'] ?? 0);
    $subtotalGeneral += $cantidad * $precio;
    $descuentoGeneral += (float)($e['descuento'] ?? 0);
    $coverGeneral += (float)($e['cover'] ?? 0);
    $totalGeneral += (float)($e['total'] ?? 0);
}

foreach ($calcetines as $c) {
    $totalCalcetines += (float)($c['total'] ?? 0);
}
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Ticket #<?= $ticketId ?></title>

<style>
* { box-sizing: border-box; }
html, body {
    margin: 0 !important;
    padding: 0 !important;
    background: #fff;
    color: #000;
    font-family: Arial, Helvetica, sans-serif;
    font-size: 9.5px;
}
body { width: 58mm; }
.ticket {
    width: 42mm;
    max-width: 42mm;
    margin: 0;
    padding: 1mm 0.5mm 1.5mm 1mm;
    background: #fff;
    overflow: visible;
}
.center { text-align: center; }
.title { font-size: 12.5px; line-height: 1.1; font-weight: 700; white-space: nowrap; }
.line { width: 100%; border-top: 1px dashed #000; margin: 4px 0; }
.row {
    display: grid;
    grid-template-columns: 13mm minmax(0, 1fr);
    column-gap: 1mm;
    width: 100%;
    margin-bottom: 2px;
    font-size: 9.5px;
    line-height: 1.15;
}
.row > span { min-width: 0; }
.row > strong {
    min-width: 0;
    text-align: right;
    font-weight: 700;
    overflow-wrap: break-word;
}
.row.compact-value > strong { white-space: nowrap; font-size: 9px; }
.total { font-size: 12px; font-weight: 700; grid-template-columns: 13mm minmax(0, 1fr); }
.total > strong { white-space: nowrap; font-size: 12px; }
.item { width: 100%; font-size: 9.5px; line-height: 1.2; margin-bottom: 5px; }
.item-main {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    column-gap: 1mm;
    width: 100%;
    font-weight: 700;
}
.item-main span:first-child { min-width: 0; overflow-wrap: break-word; }
.item-main span:last-child { min-width: 0; text-align: right; white-space: nowrap; font-size: 9px; }
.item-promo { margin-top: 2px; font-size: 8.5px; line-height: 1.15; overflow-wrap: break-word; }
.section-title { text-align: center; font-weight: 700; font-size: 10.5px; margin-bottom: 4px; }
.note { width: 100%; text-align: center; font-size: 7.8px; line-height: 1.15; overflow-wrap: break-word; }
.actions { width: 42mm; margin: 8px 0; display: flex; justify-content: center; gap: 6px; }
.btn { border: none; padding: 7px 10px; border-radius: 5px; cursor: pointer; }
.btn-primary { background: #0d6efd; color: #fff; }
.btn-secondary { background: #6c757d; color: #fff; }
@page { size: 58mm auto; margin: 0; }
@media print {
    html, body { width: 58mm !important; margin: 0 !important; padding: 0 !important; }
    .ticket {
        width: 42mm !important;
        max-width: 42mm !important;
        margin: 0 !important;
        padding: 1mm 0.5mm 1.5mm 1mm !important;
    }
    .actions { display: none !important; }
}
</style>
</head>

<body>

<div class="ticket">

    <div class="center">
        <div class="title">YEIYEI JUMPING</div>
        <div><?= $esTicketMultiple ? 'TICKET VENTA MÚLTIPLE' : 'TICKET ENTRADA' ?></div>
        <div>Folio #<?= $ticketId ?></div>
        <?php if ($esTicketMultiple): ?>
            <div>Registros: <?= count($grupoEntradas) ?></div>
        <?php endif; ?>
    </div>

    <div class="line"></div>

    <div class="row compact-value"><span>Fecha:</span><strong><?= htmlspecialchars($fechaTicket) ?></strong></div>
    <div class="row"><span>Usuario:</span><strong><?= htmlspecialchars($usuario) ?></strong></div>
    <div class="row"><span>Método:</span><strong><?= htmlspecialchars($metodo) ?></strong></div>

    <?php if (!$esTicketMultiple): ?>
        <div class="line"></div>
        <div class="row compact-value"><span>Entrada:</span><strong><?= htmlspecialchars($horaEntradaTicket) ?></strong></div>
        <div class="row compact-value"><span>Salida:</span><strong><?= htmlspecialchars(ticketSalidaTexto($entradaBase)) ?></strong></div>
    <?php endif; ?>

    <div class="line"></div>
    <div class="section-title">CONCEPTOS</div>

    <?php foreach ($grupoEntradas as $e): ?>
        <?php
        $tipoEntrada = $e['tipo_entrada'] ?? '1_HORA';
        $tipoNombre = ticketTipoNombre((string)$tipoEntrada);
        $cantidad = (int)($e['cantidad'] ?? 0);
        $precio = (float)($e['precio_unitario'] ?? 0);
        $promocion = trim((string)($e['promocion_aplicada'] ?? ''));
        $descuento = (float)($e['descuento'] ?? 0);
        $cover = (float)($e['cover'] ?? 0);
        $totalCalcEntrada = (float)($e['total_calcetines'] ?? 0);

        if ($tipoEntrada === 'SOLO_CALCETINES') {
            continue;
        }

        $cantidadMostrar = $cantidad;

        if ($tipoEntrada === 'SOLO_COVER') {
            $cantidadMostrar = (int)($e['adultos'] ?? $cantidad);
            if ($cantidadMostrar <= 0) {
                $cantidadMostrar = $cantidad;
            }
        }

        if ($cantidadMostrar <= 0 && $cover <= 0) {
            continue;
        }
        ?>
        <div class="item">
            <div class="item-main">
                <span><?= htmlspecialchars($tipoNombre) ?></span>
                <span><?= $cantidadMostrar ?> x $<?= number_format($precio, 0) ?></span>
            </div>

            <?php if ($promocion !== ''): ?>
                <div class="item-promo">Promo: <?= htmlspecialchars($promocion) ?></div>
            <?php endif; ?>
        </div>

        <?php if ($totalCalcEntrada > 0 && empty($calcetines)): ?>
            <div class="item">
                <div class="item-main">
                    <span>Calcetines</span>
                    <span>$<?= number_format($totalCalcEntrada, 0) ?></span>
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>

    <?php if (!empty($calcetines)): ?>
        <?php foreach ($calcetines as $c): ?>
            <?php
            $nombreBase = trim($c['nombre'] ?? 'Calcetines');
            $talla = trim($c['talla'] ?? '');
            $nombre = $nombreBase;
            if ($talla !== '' && stripos($nombreBase, $talla) === false) {
                $nombre .= ' ' . $talla;
            }
            $cantidadCalcetin = (int)($c['cantidad'] ?? 0);
            $precioCalcetin = (float)($c['precio_unitario'] ?? 0);
            ?>
            <div class="item">
                <div class="item-main">
                    <span><?= htmlspecialchars($nombre) ?></span>
                    <span><?= $cantidadCalcetin ?> x $<?= number_format($precioCalcetin, 0) ?></span>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <div class="line"></div>

    <?php if ($descuentoGeneral > 0): ?>
        <div class="row"><span>Desc. total:</span><strong>-$<?= number_format($descuentoGeneral, 0) ?></strong></div>
    <?php endif; ?>

    <div class="row total"><span>Total:</span><strong>$<?= number_format($totalGeneral, 0) ?></strong></div>

    <div class="line"></div>

    <div class="note">
        Promos válidas sólo en 2 horas o ilimitado.
        No válidas en festivos. No acumulables.
    </div>

    <div class="line"></div>

    <div class="center">Gracias por tu visita</div>

</div>

<div class="actions">
    <button class="btn btn-primary" onclick="window.print()">Imprimir</button>
    <button class="btn btn-secondary" onclick="window.close()">Cerrar</button>
</div>

<script>
window.onload = function () {
    setTimeout(function () {
        window.print();
    }, 500);
};
</script>

</body>
</html>
