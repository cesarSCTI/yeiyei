<?php
require_once __DIR__ . '/../layouts/header.php';
require_once __DIR__ . '/../layouts/sidebar.php';
?>

<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0">Venta de entradas</h4>

        <div class="d-flex gap-2">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalVentaMultiple">
                <i class="bi bi-cart-plus"></i> Venta múltiple
            </button>
        </div>
    </div>

    <div class="card">
        <div class="card-body">

            <table id="tablaEntradas" class="table table-striped table-hover w-100 align-middle">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tipo</th>
                        <th>Cantidad</th>
                        <th>Precio</th>
                        <th>Promoción</th>
                        <th>Descuento</th>
                        <th>Cover</th>
                        <th>Total</th>
                        <th>Hora entrada</th>
                        <th>Salida programada</th>
                        <th>Min. extra</th>
                        <th>Cargo extra</th>
                        <th>Estado</th>
                        <th>Método</th>
                        <th>Usuario</th>
                        <th>Fecha</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>

        </div>
    </div>

</div>

<div class="modal fade" id="modalEntrada" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">

        <form id="formEntrada" method="POST" action="<?= base_url('entradas/store') ?>" class="modal-content" autocomplete="off">

            <div class="modal-header">
                <h5 class="modal-title">Nueva venta de entrada</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <div class="mb-3">
                    <label class="form-label">Tipo de entrada</label>
                    <select name="tipo_entrada" id="tipoEntrada" class="form-select" required>
                        <option value="1_HORA">1 Hora - $189</option>
                        <option value="2_HORAS">2 Horas - $219</option>
                        <option value="ILIMITADO">Tiempo ilimitado - $319</option>
                        <option value="SOLO_COVER">Sólo Cover - $30</option>                        
                    </select>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Niños</label>
                        <input type="number" name="ninos" id="ninos" class="form-control" min="0" value="0" required>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Adultos</label>
                        <input type="number" name="adultos" id="adultos" class="form-control" min="0" value="0" required>
                    </div>
                </div>

                <div class="alert alert-warning py-2 d-none" id="alertAdultos">
                    Debe haber al menos un adulto por cada niño.
                </div>

                <div class="mb-3 d-none" id="boxCover">
                    <label class="form-label">Adultos extra</label>

                    <div class="border rounded p-3 bg-light">
                        <div class="mb-2">
                            <strong id="txtAdultosExtra">0 adulto(s) extra</strong>
                        </div>

                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="cobrarCover" name="cobrar_cover" value="1">
                            <label class="form-check-label" for="cobrarCover">
                                Cobrar cover por adulto extra ($30 c/u)
                            </label>
                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="esDiaFestivo" name="es_dia_festivo" value="1">
                        <label class="form-check-label" for="esDiaFestivo">
                            Día festivo / No aplicar promoción
                        </label>
                    </div>
                </div>

                <div class="alert alert-info py-2" id="boxPromocion">
                    Promoción: <strong id="txtPromocion">Sin promoción</strong>
                </div>

                <input type="hidden" name="cantidad" id="cantidad" value="0">
                <input type="hidden" name="precio_unitario" id="precioUnitario" value="189">
                <input type="hidden" name="cover" id="cover" value="0">
                <input type="hidden" name="promocion_aplicada" id="promocionAplicada" value="">
                <input type="hidden" name="descuento" id="descuento" value="0">

                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Precio unitario</label>
                        <input type="text" id="precioUnitarioView" class="form-control" value="$189.00" readonly>
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="form-label">Subtotal</label>
                        <input type="text" id="subtotalEntradaView" class="form-control" value="$0.00" readonly>
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="form-label">Descuento</label>
                        <input type="text" id="descuentoEntradaView" class="form-control" value="$0.00" readonly>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Cover</label>
                        <input type="text" id="coverEntradaView" class="form-control" value="$0.00" readonly>
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="form-label">Total</label>
                        <input type="number" step="0.01" id="totalEntrada" class="form-control" readonly>
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="form-label">Paga con</label>
                        <input type="number" step="0.01" name="paga_con" id="pagaCon" class="form-control" min="0" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Cambio</label>
                    <input type="number" step="0.01" id="cambioEntrada" class="form-control" readonly>
                </div>

                <hr>

                <h6 class="mb-3" id="tituloCalcetines">
                    <i class="bi bi-bag"></i> Calcetines (Opcional)
                </h6>

                <div class="row">

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Modelo / Producto</label>

                        <select id="idCalcetin"
                                name="id_calcetin"
                                class="form-select">

                            <option value="">No agregar calcetines</option>

                        </select>
                    </div>

                    <div class="col-md-3 mb-3">
                        <label class="form-label">Cantidad</label>

                        <input type="number"
                            id="cantidadCalcetin"
                            name="cantidad_calcetin"
                            class="form-control"
                            min="0"
                            value="0">
                    </div>

                    <div class="col-md-3 mb-3">
                        <label class="form-label">Total calcetines</label>

                        <input type="text"
                            id="totalCalcetines"
                            class="form-control"
                            readonly
                            value="$0.00">
                    </div>

                </div>

                <div class="mb-3">
                    <label class="form-label">Método de pago</label>
                    <select name="id_metodo_pago" class="form-select" required>
                        <option value="1">Efectivo</option>
                        <option value="2">Tarjeta</option>
                        <option value="3">Transferencia</option>
                    </select>
                </div>

                <small class="text-muted">
                    Promociones válidas únicamente en compra de 2 horas o tiempo ilimitado. No válidas en días festivos. No acumulables.
                </small>

            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-primary">Guardar</button>
            </div>

        </form>

    </div>
</div>


<div class="modal fade" id="modalVentaMultiple" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">

        <form id="formVentaMultiple" method="POST" action="<?= base_url('entradas/store-multiple') ?>" class="modal-content" autocomplete="off">

            <div class="modal-header">
                <h5 class="modal-title">Venta múltiple</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <div class="alert alert-info py-2">
                    Agrega diferentes tipos de entrada en una sola operación. El sistema registrará cada concepto por separado.
                </div>

                <div class="form-check mb-3">
                    <input class="form-check-input"
                           type="checkbox"
                           name="multi_es_dia_festivo"
                           id="multi_es_dia_festivo"
                           value="1">
                    <label class="form-check-label" for="multi_es_dia_festivo">
                        Día festivo / No aplicar promoción
                    </label>
                </div>

                <div class="row g-3">

                    <div class="col-md-6">
                        <label class="form-label">1 Hora - $189</label>
                        <div class="input-group input-group-lg">
                            <button type="button" class="btn btn-outline-secondary btnCantidadMultiple" data-target="multi_1_hora" data-step="-1">−</button>
                            <input type="number" name="multi_1_hora" id="multi_1_hora" class="form-control text-center campoMultiple" min="0" value="0">
                            <button type="button" class="btn btn-outline-secondary btnCantidadMultiple" data-target="multi_1_hora" data-step="1">+</button>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">2 Horas - $219</label>
                        <div class="input-group input-group-lg">
                            <button type="button" class="btn btn-outline-secondary btnCantidadMultiple" data-target="multi_2_horas" data-step="-1">−</button>
                            <input type="number" name="multi_2_horas" id="multi_2_horas" class="form-control text-center campoMultiple" min="0" value="0">
                            <button type="button" class="btn btn-outline-secondary btnCantidadMultiple" data-target="multi_2_horas" data-step="1">+</button>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Ilimitado - $319</label>
                        <div class="input-group input-group-lg">
                            <button type="button" class="btn btn-outline-secondary btnCantidadMultiple" data-target="multi_ilimitado" data-step="-1">−</button>
                            <input type="number" name="multi_ilimitado" id="multi_ilimitado" class="form-control text-center campoMultiple" min="0" value="0">
                            <button type="button" class="btn btn-outline-secondary btnCantidadMultiple" data-target="multi_ilimitado" data-step="1">+</button>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Sólo Cover - $30</label>
                        <div class="input-group input-group-lg">
                            <button type="button" class="btn btn-outline-secondary btnCantidadMultiple" data-target="multi_cover" data-step="-1">−</button>
                            <input type="number" name="multi_cover" id="multi_cover" class="form-control text-center campoMultiple" min="0" value="0">
                            <button type="button" class="btn btn-outline-secondary btnCantidadMultiple" data-target="multi_cover" data-step="1">+</button>
                        </div>
                    </div>

                </div>

                <hr>

                <div class="mb-2">
                    <h6 class="mb-1" id="multi_calcetin_titulo">
                        <i class="bi bi-bag"></i> Calcetines
                    </h6>
                    <small class="text-muted" id="multi_calcetin_info">
                        Cantidad 0 = no agregar calcetines.
                    </small>
                </div>

                <select id="multi_id_calcetin" name="multi_id_calcetin" class="form-select d-none">
                    <option value="">No agregar calcetines</option>
                </select>

                <div class="row g-3 align-items-end mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Cantidad calcetines</label>
                        <div class="input-group input-group-lg">
                            <button type="button" class="btn btn-outline-secondary btnCantidadMultiple" data-target="multi_cantidad_calcetin" data-step="-1">−</button>
                            <input type="number" id="multi_cantidad_calcetin" name="multi_cantidad_calcetin" class="form-control text-center campoMultiple" min="0" value="0">
                            <button type="button" class="btn btn-outline-secondary btnCantidadMultiple" data-target="multi_cantidad_calcetin" data-step="1">+</button>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Total calcetines</label>
                        <input type="text" id="multi_total_calcetines_view" class="form-control form-control-lg" value="$0.00" readonly>
                    </div>
                </div>

                <div class="card bg-light mb-3">
                    <div class="card-body">
                        <h6 class="mb-3">Resumen</h6>

                        <div id="resumenVentaMultiple" class="small text-muted">
                            Sin conceptos agregados.
                        </div>

                        <hr>

                        <div class="d-flex justify-content-between align-items-center">
                            <span class="fw-bold">Total</span>
                            <span class="fs-4 fw-bold" id="multi_total_view">$0.00</span>
                        </div>
                    </div>
                </div>

                <input type="hidden" name="multi_total" id="multi_total" value="0">

                <div class="card border-primary-subtle mb-3">
                    <div class="card-body">
                        <h6 class="mb-3">
                            <i class="bi bi-cash-coin"></i> Pago mixto
                        </h6>

                        <div class="row g-3">
                            <div class="col-md-3">
                                <label class="form-label">Efectivo</label>
                                <input type="number" step="0.01" min="0" name="pago_efectivo" id="pago_efectivo" class="form-control campoPagoMixto" value="0">
                            </div>

                            <div class="col-md-3">
                                <label class="form-label">Tarjeta</label>
                                <input type="number" step="0.01" min="0" name="pago_tarjeta" id="pago_tarjeta" class="form-control campoPagoMixto" value="0">
                            </div>

                            <div class="col-md-3">
                                <label class="form-label">Transferencia</label>
                                <input type="number" step="0.01" min="0" name="pago_transferencia" id="pago_transferencia" class="form-control campoPagoMixto" value="0">
                            </div>

                            <div class="col-md-3">
                                <label class="form-label">Cortesía</label>
                                <input type="number" step="0.01" min="0" name="pago_cortesia" id="pago_cortesia" class="form-control campoPagoMixto" value="0">
                            </div>
                        </div>

                        <div class="row g-3 mt-2">
                            <div class="col-md-4">
                                <label class="form-label">Total capturado</label>
                                <input type="text" id="multi_total_pagado_view" class="form-control" value="$0.00" readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label">Pendiente</label>
                                <input type="text" id="multi_pendiente_view" class="form-control" value="$0.00" readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label">Cambio</label>
                                <input type="text" id="multi_cambio_view" class="form-control" value="$0.00" readonly>
                            </div>
                        </div>

                        <small class="text-muted d-block mt-2">
                            El cambio sólo puede generarse con efectivo. Tarjeta, transferencia y cortesía no deben exceder el total pendiente.
                        </small>
                    </div>
                </div>

            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-primary">Guardar venta múltiple</button>
            </div>

        </form>

    </div>
</div>


<div class="modal fade" id="modalSalida" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">

        <form id="formSalida" method="POST" action="<?= base_url('entradas/registrar-salida') ?>" class="modal-content" autocomplete="off">

            <div class="modal-header">
                <h5 class="modal-title">Registrar salida</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <input type="hidden" name="id_entrada" id="salidaIdEntrada">

                <div class="mb-3">
                    <label class="form-label">Folio</label>
                    <div class="form-control bg-light" id="salidaFolio">#</div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Tipo de entrada</label>
                    <div class="form-control bg-light" id="salidaTipo"></div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Hora de entrada</label>
                    <div class="form-control bg-light" id="salidaHoraEntrada"></div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Salida programada</label>
                    <div class="form-control bg-light" id="salidaProgramada"></div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Salida real</label>
                    <div class="form-control bg-light" id="salidaReal"></div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Minutos extra</label>
                    <input type="text" id="salidaMinutosExtra" class="form-control" readonly>
                </div>

                <input type="hidden" name="cargo_extra" id="salidaCargoExtra" value="0">

                <div class="mb-3">
                    <label class="form-label">Cargo extra</label>
                    <input type="text" id="salidaCargoExtraView" class="form-control" readonly>
                    <small class="text-muted">Cada 15 minutos extra = $40</small>
                </div>

                <div id="boxPagoExtra" class="d-none">
                    <div class="mb-3">
                        <label class="form-label">Paga con</label>
                        <input type="number" step="0.01" min="0" name="paga_con_extra" id="pagaConExtra" class="form-control">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Cambio</label>
                        <input type="text" id="cambioExtraView" class="form-control" readonly>
                    </div>

                    <div class="alert alert-warning py-2">
                        Hay cargo extra por tiempo excedido. Confirma el cobro antes de finalizar.
                    </div>
                </div>

                <div class="alert alert-success py-2 d-none" id="boxSinExtra">
                    No hay tiempo extra para cobrar.
                </div>

            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-primary">Registrar salida</button>
            </div>

        </form>

    </div>
</div>

<?php $extra_js = ['entradas.js']; ?>
<?php require_once __DIR__ . '/../layouts/footer.php'; ?>