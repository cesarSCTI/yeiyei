<?php
require_once __DIR__ . '/../layouts/header.php';
require_once __DIR__ . '/../layouts/sidebar.php';
?>

<div class="container-fluid py-4">
    <h4 class="mb-3">Ingresos</h4>
    <div class="card">
        <div class="card-body">
            <table id="tablaIngresos" class="table table-striped table-hover w-100 align-middle">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tipo</th>
                        <th>Concepto</th>
                        <th>Monto</th>
                        <th>Método</th>
                        <th>Usuario</th>
                        <th>Fecha</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
</div>

<?php $extra_js = ['ingresos.js']; ?>
<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
