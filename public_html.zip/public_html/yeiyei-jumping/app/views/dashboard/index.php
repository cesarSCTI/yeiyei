<?php require_once __DIR__ . '/../layouts/header.php'; ?>
<?php require_once __DIR__ . '/../layouts/sidebar.php'; ?>

<div class="container-fluid py-4">

    <h4 class="mb-4">Dashboard del día</h4>

    <div class="row g-3">

        <div class="col-md-3">
            <div class="stat-card">
                <span>Ingresos</span>
                <strong>$<?= number_format($resumen['ingresos'],2) ?></strong>
            </div>
        </div>

        <div class="col-md-3">
            <div class="stat-card">
                <span>Egresos</span>
                <strong>$<?= number_format($resumen['egresos'],2) ?></strong>
            </div>
        </div>

        <div class="col-md-3">
            <div class="stat-card">
                <span>Balance</span>
                <strong>$<?= number_format($resumen['balance'],2) ?></strong>
            </div>
        </div>

        <div class="col-md-3">
            <div class="stat-card">
                <span>Fiestas hoy</span>
                <strong><?= (int)$resumen['fiestas'] ?></strong>
            </div>
        </div>

    </div>

    <hr class="my-4">

    <h5 class="mb-3">Ingresos por método de pago</h5>

    <div class="row g-3">

        <div class="col-md-4">
            <div class="stat-card">
                <span>Efectivo</span>
                <strong>
                    $<?= number_format($resumen['efectivo'] ?? 0,2) ?>
                </strong>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card">
                <span>Tarjeta</span>
                <strong>
                    $<?= number_format($resumen['tarjeta'] ?? 0,2) ?>
                </strong>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card">
                <span>Transferencia</span>
                <strong>
                    $<?= number_format($resumen['transferencia'] ?? 0,2) ?>
                </strong>
            </div>
        </div>

    </div>

    <hr class="my-4">

    <h5 class="mb-3">Detalle de entradas</h5>

    <div class="row g-3">

        <div class="col-md-4">
            <div class="stat-card">
                <span>Calcetines</span>
                <strong>
                    $<?= number_format($resumen['calcetines'] ?? 0,2) ?>
                </strong>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card">
                <span>Cover</span>
                <strong>
                    $<?= number_format($resumen['cover'] ?? 0,2) ?>
                </strong>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card">
                <span>Tiempo extra</span>
                <strong>
                    $<?= number_format($resumen['tiempo_extra'] ?? 0,2) ?>
                </strong>
            </div>
        </div>

    </div>

</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>