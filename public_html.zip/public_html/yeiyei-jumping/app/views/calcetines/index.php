<?php
require_once __DIR__ . '/../layouts/header.php';
require_once __DIR__ . '/../layouts/sidebar.php';
?>

<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h4 class="mb-0">Calcetines</h4>
            <small class="text-muted">Control de stock inicial, vendidos y existencias.</small>
        </div>

        <button type="button" class="btn btn-primary" id="btnNuevoCalcetin">
            <i class="bi bi-plus-circle"></i> Nuevo registro
        </button>
    </div>

    <div class="card">
        <div class="card-body">

            <table id="tablaCalcetines" class="table table-striped table-hover w-100 align-middle">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Precio venta</th>
                        <th>Stock inicial</th>
                        <th>Vendidos</th>
                        <th>Existencias</th>
                        <th>Estado</th>
                        <th>Fecha</th>
                        <th width="170">Acciones</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>

        </div>
    </div>

</div>

<div class="modal fade" id="modalCalcetin" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">

        <form id="formCalcetin"
              method="POST"
              action="<?= base_url('calcetines/store') ?>"
              class="modal-content"
              autocomplete="off">

            <div class="modal-header">
                <h5 class="modal-title" id="tituloModalCalcetin">Nuevo registro de calcetines</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>

            <div class="modal-body">

                <input type="hidden" name="id" id="calcetin_id">
                <input type="hidden" name="calcetin_id" id="calcetin_id_alt">

                <div class="alert alert-info py-2">
                    Se manejará como producto único: <strong>Calcetines</strong>.
                    El sistema calculará vendidos desde las entradas registradas.
                </div>

                <div class="mb-3">
                    <label class="form-label">Precio de venta</label>
                    <input type="number"
                           name="precio"
                           id="precio"
                           class="form-control"
                           min="0.01"
                           step="0.01"
                           required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Stock inicial</label>
                    <input type="number"
                           name="stock_inicial"
                           id="stock_inicial"
                           class="form-control"
                           min="0"
                           step="1"
                           required>
                    <small class="text-muted">
                        Las existencias se calculan tomando en cuenta los calcetines vendidos.
                    </small>
                </div>

                <div class="row d-none" id="resumenEditarStock">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Vendidos</label>
                        <input type="text" id="vendidos_view" class="form-control" readonly>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Existencias actuales</label>
                        <input type="text" id="existencias_view" class="form-control" readonly>
                    </div>
                </div>

            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    Cancelar
                </button>
                <button type="submit" class="btn btn-primary" id="btnGuardarCalcetin">
                    Guardar
                </button>
            </div>

        </form>

    </div>
</div>

<div class="modal fade" id="modalStock" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">

        <form id="formStock"
              method="POST"
              action="<?= base_url('calcetines/stock') ?>"
              class="modal-content"
              autocomplete="off">

            <div class="modal-header">
                <h5 class="modal-title">Ajustar existencias</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>

            <div class="modal-body">

                <input type="hidden" name="stock_calcetin_id" id="stock_calcetin_id">

                <div class="mb-3">
                    <label class="form-label">Producto</label>
                    <input type="text" id="stock_producto" class="form-control" value="Calcetines" readonly>
                </div>

                <div class="mb-3">
                    <label class="form-label">Cantidad de ajuste</label>
                    <input type="number" name="cantidad" id="cantidadStock" class="form-control" step="1" required>
                    <small class="text-muted">
                        Usa positivo para sumar existencias. Usa negativo para corregir una merma o ajuste.
                    </small>
                </div>

                <div class="alert alert-warning py-2">
                    Si el ajuste es positivo, también aumentará el stock inicial.
                    Si es negativo, sólo descontará existencias.
                </div>

            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    Cancelar
                </button>
                <button type="submit" class="btn btn-primary" id="btnGuardarStock">
                    Aplicar ajuste
                </button>
            </div>

        </form>

    </div>
</div>

<?php $extra_js = ['calcetines.js']; ?>
<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
