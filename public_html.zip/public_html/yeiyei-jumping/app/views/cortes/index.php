<?php
require_once __DIR__ . '/../layouts/header.php';
require_once __DIR__ . '/../layouts/sidebar.php';

function corteMoneda($valor): string
{
    return '$' . number_format((float)$valor, 0, '.', ',');
}
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="mb-1">Corte del día</h4>
            <small class="text-muted"><?= date('d/m/Y') ?></small>
        </div>

        <button type="button" class="btn btn-outline-secondary" onclick="window.print()">
            <i class="bi bi-printer"></i> Imprimir corte
        </button>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card h-100 border-primary">
                <div class="card-body">
                    <div class="text-muted mb-1">Ingresos totales</div>
                    <div class="fs-3 fw-bold text-primary"><?= corteMoneda($resumen['ingresos'] ?? 0) ?></div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card h-100 border-danger">
                <div class="card-body">
                    <div class="text-muted mb-1">Egresos</div>
                    <div class="fs-3 fw-bold text-danger"><?= corteMoneda($resumen['egresos'] ?? 0) ?></div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card h-100 border-success">
                <div class="card-body">
                    <div class="text-muted mb-1">Resultado del día</div>
                    <div class="fs-3 fw-bold text-success"><?= corteMoneda($resumen['balance'] ?? 0) ?></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-lg-7">
            <div class="card h-100">
                <div class="card-header bg-white">
                    <strong>Ingresos por método de pago</strong>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-sm-6">
                            <div class="border rounded p-3 h-100">
                                <div class="text-muted">Efectivo</div>
                                <div class="fs-4 fw-bold"><?= corteMoneda($resumen['efectivo'] ?? 0) ?></div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="border rounded p-3 h-100">
                                <div class="text-muted">Tarjeta</div>
                                <div class="fs-4 fw-bold"><?= corteMoneda($resumen['tarjeta'] ?? 0) ?></div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="border rounded p-3 h-100">
                                <div class="text-muted">Transferencia</div>
                                <div class="fs-4 fw-bold"><?= corteMoneda($resumen['transferencia'] ?? 0) ?></div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="border rounded p-3 h-100">
                                <div class="text-muted">Cortesía</div>
                                <div class="fs-4 fw-bold"><?= corteMoneda($resumen['cortesia'] ?? 0) ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="card h-100 border-success">
                <div class="card-header bg-success text-white">
                    <strong>Balance de efectivo</strong>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-3">
                        <span>Efectivo recibido</span>
                        <strong><?= corteMoneda($resumen['efectivo'] ?? 0) ?></strong>
                    </div>
                    <div class="d-flex justify-content-between mb-3 text-danger">
                        <span>(−) Egresos</span>
                        <strong><?= corteMoneda($resumen['egresos'] ?? 0) ?></strong>
                    </div>
                    <hr>
                    <div class="text-center">
                        <div class="text-muted mb-1">Efectivo que debe entregarse</div>
                        <div class="display-6 fw-bold text-success">
                            <?= corteMoneda($resumen['balance_efectivo'] ?? 0) ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header bg-white">
            <strong>Desglose operativo</strong>
        </div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-3 col-6">
                    <div class="text-muted">Entradas</div>
                    <div class="fs-5 fw-bold"><?= corteMoneda($resumen['entradas'] ?? 0) ?></div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="text-muted">Cover</div>
                    <div class="fs-5 fw-bold"><?= corteMoneda($resumen['cover'] ?? 0) ?></div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="text-muted">Calcetines</div>
                    <div class="fs-5 fw-bold"><?= corteMoneda($resumen['calcetines'] ?? 0) ?></div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="text-muted">Tiempo extra</div>
                    <div class="fs-5 fw-bold"><?= corteMoneda($resumen['tiempo_extra'] ?? 0) ?></div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
@media print {
    .sidebar,
    .navbar,
    .btn,
    footer {
        display: none !important;
    }

    .container-fluid {
        padding: 0 !important;
    }

    .card {
        break-inside: avoid;
    }
}
</style>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
