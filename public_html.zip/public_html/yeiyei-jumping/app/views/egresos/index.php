<?php
require_once __DIR__ . '/../layouts/header.php';
require_once __DIR__ . '/../layouts/sidebar.php';
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0">Egresos</h4>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalEgreso">Nuevo egreso</button>
    </div>

    <div class="card">
        <div class="card-body">
            <table id="tablaEgresos" class="table table-striped table-hover w-100 align-middle">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Concepto</th>
                        <th>Monto</th>
                        <th>Usuario</th>
                        <th>Fecha</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="modalEgreso" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <form id="formEgreso" method="POST" action="<?= base_url('egresos/store') ?>" class="modal-content" autocomplete="off">
            <div class="modal-header">
                <h5 class="modal-title">Nuevo egreso</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Concepto</label>
                    <input name="concepto" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Monto</label>
                    <input type="number" step="0.01" name="monto" class="form-control" min="0.01" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Observaciones</label>
                    <textarea name="observaciones" class="form-control"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-primary">Guardar</button>
            </div>
        </form>
    </div>
</div>

<?php $extra_js = ['egresos.js']; ?>
<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
