<?php require_once __DIR__ . '/../../../config/config.php'; ?>
<!DOCTYPE html>
<html lang="es">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>YeiYei Jumping — Login</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<link rel="stylesheet" href="<?= base_url('assets/css/login.css') ?>?v=<?= time() ?>">

<script>
const BASE_URL = "<?= BASE_URL ?>";
</script>

</head>

<body>

<div class="login-container">

    <div class="login-card">

        <div class="login-header">

            <div class="logo-circle">

                <i class="bi bi-controller"></i>

            </div>

            <h1>YeiYei Jumping</h1>

            <p>Acceso al sistema</p>

        </div>

        <?php if (!empty($_SESSION['login_error'])): ?>
            <div class="alert alert-danger py-2">
                <?= htmlspecialchars($_SESSION['login_error']) ?>
            </div>
            <?php unset($_SESSION['login_error']); ?>
        <?php endif; ?>

        <form id="formLogin" method="POST" action="<?= base_url('auth/login') ?>">

            <div class="mb-4">

                <label>Usuario</label>

                <div class="input-group-custom">

                    <i class="bi bi-person"></i>

                    <input
                        type="text"
                        name="usuario"
                        placeholder="Ingrese su usuario"
                        required>

                </div>

            </div>

            <div class="mb-4">

                <label>Contraseña</label>

                <div class="input-group-custom">

                    <i class="bi bi-lock"></i>

                    <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Ingrese su contraseña"
                        required>

                    <button
                        type="button"
                        id="togglePass">

                        <i class="bi bi-eye"></i>

                    </button>

                </div>

            </div>

            <button type="submit" class="btn-login">

                <i class="bi bi-box-arrow-in-right"></i>

                Ingresar

            </button>

        </form>

        <div class="footer-text">

            © <?= date('Y') ?> YeiYei Jumping

        </div>

    </div>

</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script src="<?= base_url('assets/js/auth.js') ?>?v=<?= time() ?>"></script>

</body>
</html>
