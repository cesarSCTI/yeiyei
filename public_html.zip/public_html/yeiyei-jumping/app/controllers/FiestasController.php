<?php
require_once __DIR__ . '/Controller.php';
require_once __DIR__ . '/../models/Fiesta.php';

class FiestasController extends Controller
{
    public function index(): void
    {
        $this->requireAuth();
        $paquetes = (new Fiesta())->paquetes();
        $this->view('fiestas/index', compact('paquetes'));
    }

    public function store(): void
    {
        $this->requireAuth();

        try {
            $data = [
                'id_usuario' => $_SESSION['user']['id'],
                'id_paquete' => (int)($_POST['id_paquete'] ?? 0),
                'nombre_cliente' => trim($_POST['nombre_cliente'] ?? ''),
                'telefono' => trim($_POST['telefono'] ?? ''),
                'fecha_evento' => $_POST['fecha_evento'] ?? '',
                'hora_inicio' => $_POST['hora_inicio'] ?? '',
                'anticipo' => (float)($_POST['anticipo'] ?? 0),
                'id_metodo_pago' => (int)($_POST['id_metodo_pago'] ?? 1),
                'observaciones' => trim($_POST['observaciones'] ?? '')
            ];

            if ($data['id_paquete'] <= 0 || $data['nombre_cliente'] === '' || $data['fecha_evento'] === '' || $data['hora_inicio'] === '') {
                $this->json(['success'=>false,'message'=>'Datos obligatorios incompletos.']);
            }

            $ok = (new Fiesta())->crear($data);

            $this->json([
                'success' => $ok,
                'message' => $ok ? 'Reservación registrada.' : 'No se pudo registrar.'
            ]);
        } catch (Throwable $e) {
            $this->json([
                'success' => false,
                'message' => 'Error al registrar reservación: ' . $e->getMessage()
            ]);
        }
    }

    public function list(): void
    {
        $this->requireAuth();

        try {
            $r = (new Fiesta())->listDataTables(
                (int)($_POST['start'] ?? 0),
                (int)($_POST['length'] ?? 10),
                trim($_POST['search']['value'] ?? '')
            );

            $this->json([
                'draw' => (int)($_POST['draw'] ?? 1),
                'recordsTotal' => $r['total'],
                'recordsFiltered' => $r['filtered'],
                'data' => $r['data']
            ]);
        } catch (Throwable $e) {
            $this->json([
                'draw' => (int)($_POST['draw'] ?? 1),
                'recordsTotal' => 0,
                'recordsFiltered' => 0,
                'data' => [],
                'error' => $e->getMessage()
            ]);
        }
    }

    public function show(): void
    {
        $this->requireAuth();

        try {
            $id = (int)($_POST['id'] ?? 0);
            $fiesta = new Fiesta();
            $reserva = $fiesta->obtener($id);

            if (!$reserva) {
                $this->json(['success' => false, 'message' => 'Reservación no encontrada.']);
            }

            $this->json([
                'success' => true,
                'reserva' => $reserva,
                'pagos' => $fiesta->pagos($id)
            ]);
        } catch (Throwable $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function abonar(): void
    {
        $this->requireAuth();

        try {
            $id = (int)($_POST['id'] ?? 0);
            $monto = (float)($_POST['monto'] ?? 0);
            $idMetodoPago = (int)($_POST['id_metodo_pago'] ?? 1);
            $observaciones = trim($_POST['observaciones'] ?? '');

            $ok = (new Fiesta())->abonar($id, (int)$_SESSION['user']['id'], $idMetodoPago, $monto, $observaciones);

            $this->json([
                'success' => $ok,
                'message' => $ok ? 'Abono registrado correctamente.' : 'No se pudo registrar el abono.'
            ]);
        } catch (Throwable $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function liquidar(): void
    {
        $this->requireAuth();

        try {
            $id = (int)($_POST['id'] ?? 0);
            $idMetodoPago = (int)($_POST['id_metodo_pago'] ?? 1);

            $ok = (new Fiesta())->liquidar($id, (int)$_SESSION['user']['id'], $idMetodoPago);

            $this->json([
                'success' => $ok,
                'message' => $ok ? 'Reservación liquidada correctamente.' : 'No se pudo liquidar.'
            ]);
        } catch (Throwable $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function cancelar(): void
    {
        $this->requireAuth();

        try {
            $id = (int)($_POST['id'] ?? 0);
            $ok = (new Fiesta())->cancelar($id);

            $this->json([
                'success' => $ok,
                'message' => $ok ? 'Reservación cancelada correctamente.' : 'No se pudo cancelar.'
            ]);
        } catch (Throwable $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
}
