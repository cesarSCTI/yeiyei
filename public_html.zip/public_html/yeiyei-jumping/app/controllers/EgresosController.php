<?php
require_once __DIR__ . '/Controller.php';
require_once __DIR__ . '/../models/Egreso.php';

class EgresosController extends Controller
{
    public function index(): void
    {
        $this->requireAdmin();
        $this->view('egresos/index');
    }

    public function store(): void
    {
        $this->requireAdmin();

        try {
            $concepto = trim($_POST['concepto'] ?? '');
            $monto = (float)($_POST['monto'] ?? 0);

            if ($concepto === '' || $monto <= 0) {
                $this->json(['success'=>false,'message'=>'Datos incompletos.']);
            }

            $ok = (new Egreso())->crear([
                'id_usuario' => $_SESSION['user']['id'],
                'concepto' => $concepto,
                'monto' => $monto,
                'observaciones' => trim($_POST['observaciones'] ?? '')
            ]);

            $this->json([
                'success' => $ok,
                'message' => $ok ? 'Egreso registrado.' : 'No se pudo registrar.'
            ]);
        } catch (Throwable $e) {
            $this->json([
                'success' => false,
                'message' => 'Error al registrar egreso: ' . $e->getMessage()
            ]);
        }
    }

    public function list(): void
    {
        $this->requireAdmin();

        try {
            $r = (new Egreso())->listDataTables(
                (int)($_POST['start'] ?? 0),
                (int)($_POST['length'] ?? 10),
                trim($_POST['search']['value'] ?? '')
            );

            $this->json([
                'draw' => (int)($_POST['draw'] ?? 1),
                'recordsTotal' => $r['total'],
                'recordsFiltered' => $r['filtered'],
                'data' => $r['data']
            ]);
        } catch (Throwable $e) {
            $this->json([
                'draw' => (int)($_POST['draw'] ?? 1),
                'recordsTotal' => 0,
                'recordsFiltered' => 0,
                'data' => [],
                'error' => $e->getMessage()
            ]);
        }
    }
}
