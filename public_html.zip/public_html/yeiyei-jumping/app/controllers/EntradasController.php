<?php
require_once __DIR__ . '/Controller.php';
require_once __DIR__ . '/../models/Entrada.php';

class EntradasController extends Controller
{
    public function index(): void
    {
        $this->requireAuth();
        $this->view('entradas/index');
    }

    public function store(): void
    {
        $this->requireAuth();

        $entradaModel = new Entrada();

        try {
            $tipoEntrada = $_POST['tipo_entrada'] ?? '1_HORA';
            $ninos = (int)($_POST['ninos'] ?? 0);
            $adultos = (int)($_POST['adultos'] ?? 0);
            $cantidad = (int)($_POST['cantidad'] ?? 0);
            $precio = (float)($_POST['precio_unitario'] ?? 0);
            $cover = (float)($_POST['cover'] ?? 0);
            $promocion = trim($_POST['promocion_aplicada'] ?? '');
            $descuento = (float)($_POST['descuento'] ?? 0);
            $esDiaFestivo = isset($_POST['es_dia_festivo']) ? 1 : 0;
            $pagaCon = (float)($_POST['paga_con'] ?? 0);
            $metodo = (int)($_POST['id_metodo_pago'] ?? 0);

            $idCalcetin = (int)($_POST['id_calcetin'] ?? 0);
            $cantidadCalcetin = (int)($_POST['cantidad_calcetin'] ?? 0);

            $this->logEntrada('store_intento', 'POST recibido en entradas/store', [
                'post' => $_POST,
                'normalizado' => [
                    'tipo_entrada' => $tipoEntrada,
                    'ninos' => $ninos,
                    'adultos' => $adultos,
                    'cantidad' => $cantidad,
                    'precio_unitario' => $precio,
                    'cover' => $cover,
                    'paga_con' => $pagaCon,
                    'id_metodo_pago' => $metodo,
                    'id_calcetin' => $idCalcetin,
                    'cantidad_calcetin' => $cantidadCalcetin
                ]
            ], false);

            if (!in_array($tipoEntrada, ['1_HORA', '2_HORAS', 'ILIMITADO', 'SOLO_COVER', 'SOLO_CALCETINES'], true)) {
                $this->errorJson(
                    'Tipo de entrada inválido.',
                    'Valor recibido en tipo_entrada: ' . $tipoEntrada,
                    'store_validacion_tipo',
                    $_POST
                );
            }

            if ($tipoEntrada !== 'SOLO_COVER' && $tipoEntrada !== 'SOLO_CALCETINES' && $ninos <= 0) {
                $this->errorJson(
                    'Debe capturar al menos un niño.',
                    'La validación aplica porque tipo_entrada no es SOLO_COVER ni SOLO_CALCETINES. tipo_entrada=' . $tipoEntrada . ', ninos=' . $ninos,
                    'store_validacion_ninos',
                    $_POST
                );
            }

            if ($tipoEntrada === 'SOLO_COVER' && $adultos <= 0) {
                $this->errorJson(
                    'Debe capturar al menos un adulto.',
                    'Para SOLO_COVER se cobra por adulto. adultos=' . $adultos,
                    'store_validacion_adultos_cover',
                    $_POST
                );
            }

            if ($tipoEntrada === 'SOLO_CALCETINES' && ($idCalcetin <= 0 || $cantidadCalcetin <= 0)) {
                $this->errorJson(
                    'Para Sólo Calcetines debes seleccionar calcetines y capturar una cantidad mayor a cero.',
                    'id_calcetin=' . $idCalcetin . ', cantidad_calcetin=' . $cantidadCalcetin,
                    'store_validacion_solo_calcetines',
                    $_POST
                );
            }

            if ($tipoEntrada === 'SOLO_COVER') {
                $cantidad = $adultos;
                $precio = 30.00;
                $cover = 0.00;
                $promocion = '';
                $descuento = 0.00;
                $esDiaFestivo = 0;
            }

            if ($tipoEntrada === 'SOLO_CALCETINES') {
                $ninos = 0;
                $adultos = 0;
                $cantidad = 0;
                $precio = 0.00;
                $cover = 0.00;
                $promocion = '';
                $descuento = 0.00;
                $esDiaFestivo = 0;
            }

            if ($tipoEntrada !== 'SOLO_CALCETINES' && ($cantidad <= 0 || $precio <= 0)) {
                $this->errorJson(
                    'Datos incompletos o inválidos.',
                    'Valores calculados: cantidad=' . $cantidad . ', precio=' . $precio,
                    'store_validacion_datos',
                    [
                        'post' => $_POST,
                        'calculado' => [
                            'tipo_entrada' => $tipoEntrada,
                            'cantidad' => $cantidad,
                            'precio_unitario' => $precio,
                            'id_metodo_pago' => $metodo
                        ]
                    ]
                );
            }

            if ($metodo <= 0) {
                $this->errorJson(
                    'Datos incompletos o inválidos.',
                    'Valores calculados: cantidad=' . $cantidad . ', precio=' . $precio . ', metodo=' . $metodo,
                    'store_validacion_datos',
                    [
                        'post' => $_POST,
                        'calculado' => [
                            'tipo_entrada' => $tipoEntrada,
                            'cantidad' => $cantidad,
                            'precio_unitario' => $precio,
                            'id_metodo_pago' => $metodo
                        ]
                    ]
                );
            }

            $calcetinVenta = $entradaModel->prepararCalcetinVenta($idCalcetin, $cantidadCalcetin);
            $totalCalcetines = (float)($calcetinVenta['total'] ?? 0);

            if ($tipoEntrada === 'SOLO_CALCETINES' && $totalCalcetines <= 0) {
                $this->errorJson(
                    'Para Sólo Calcetines debes seleccionar calcetines y capturar una cantidad mayor a cero.',
                    'total_calcetines calculado=' . $totalCalcetines,
                    'store_validacion_total_calcetines',
                    $_POST
                );
            }

            $subtotal = $cantidad * $precio;
            $totalCalculado = ($subtotal - $descuento) + $cover + $totalCalcetines;
            $total = $this->redondearCobro($totalCalculado);
            $pagaCon = $this->redondearCobro($pagaCon);
            $cambio = $pagaCon - $total;

            if ($pagaCon < $total) {
                $this->errorJson(
                    'Pago insuficiente. El total es $' . number_format($total, 0),
                    'paga_con=' . number_format($pagaCon, 0) . ', total=' . number_format($total, 0),
                    'store_validacion_pago',
                    [
                        'post' => $_POST,
                        'calculado' => [
                            'subtotal' => $subtotal,
                            'cover' => $cover,
                            'total_calcetines' => $totalCalcetines,
                            'descuento' => $descuento,
                            'total' => $total,
                            'paga_con' => $pagaCon
                        ]
                    ]
                );
            }

            $idEntrada = $entradaModel->crear([
                'id_usuario' => $this->getUsuarioId(),
                'adultos' => $adultos,
                'ninos' => $ninos,
                'tipo_entrada' => $tipoEntrada,
                'cantidad' => $cantidad,
                'precio_unitario' => $precio,
                'total' => $total,
                'cover' => $cover,
                'total_calcetines' => $totalCalcetines,
                'promocion_aplicada' => $promocion,
                'descuento' => $descuento,
                'es_dia_festivo' => $esDiaFestivo,
                'paga_con' => $pagaCon,
                'cambio' => $cambio,
                'id_metodo_pago' => $metodo,
                'calcetin_venta' => $calcetinVenta
            ]);

            $this->logEntrada('store_exito', 'Entrada registrada correctamente', [
                'id_entrada' => $idEntrada,
                'tipo_entrada' => $tipoEntrada,
                'adultos' => $adultos,
                'ninos' => $ninos,
                'cantidad' => $cantidad,
                'precio_unitario' => $precio,
                'total' => $total
            ], false);

            $this->json([
                'success' => true,
                'message' => 'Entrada registrada.',
                'id_entrada' => $idEntrada,
                'ticket_url' => base_url('entradas/ticket?id=' . $idEntrada)
            ]);

        } catch (Throwable $e) {
            $this->errorJson(
                'Error al registrar entrada.',
                $e->getMessage(),
                'store_exception',
                [
                    'post' => $_POST,
                    'archivo' => $e->getFile(),
                    'linea' => $e->getLine()
                ],
                $e
            );
        }
    }


    public function storeMultiple(): void
    {
        $this->requireAuth();

        $entradaModel = new Entrada();

        try {
            $q1 = max(0, (int)($_POST['multi_1_hora'] ?? 0));
            $q2 = max(0, (int)($_POST['multi_2_horas'] ?? 0));
            $qi = max(0, (int)($_POST['multi_ilimitado'] ?? 0));
            $qc = max(0, (int)($_POST['multi_cover'] ?? 0));

            $idCalcetin = (int)($_POST['multi_id_calcetin'] ?? 0);
            $cantidadCalcetin = max(0, (int)($_POST['multi_cantidad_calcetin'] ?? 0));
            $esDiaFestivo = isset($_POST['multi_es_dia_festivo']) ? 1 : 0;

            $pagos = $this->normalizarPagosMixtos($_POST);

            $this->logEntrada('store_multiple_intento', 'POST recibido en entradas/store-multiple', [
                'post' => $_POST,
                'normalizado' => [
                    'multi_1_hora' => $q1,
                    'multi_2_horas' => $q2,
                    'multi_ilimitado' => $qi,
                    'multi_cover' => $qc,
                    'multi_id_calcetin' => $idCalcetin,
                    'multi_cantidad_calcetin' => $cantidadCalcetin,
                    'multi_es_dia_festivo' => $esDiaFestivo,
                    'pagos' => $pagos
                ]
            ], false);

            $conceptos = [];

            if ($q1 > 0) {
                $precio = 189.00;
                $conceptos[] = [
                    'tipo_entrada' => '1_HORA',
                    'nombre' => '1 Hora',
                    'cantidad' => $q1,
                    'ninos' => $q1,
                    'adultos' => 0,
                    'precio_unitario' => $precio,
                    'subtotal' => $q1 * $precio,
                    'promocion_aplicada' => '',
                    'descuento' => 0.00,
                    'total' => $q1 * $precio,
                    'cover' => 0.00,
                    'total_calcetines' => 0.00,
                    'calcetin_venta' => null
                ];
            }

            if ($q2 > 0) {
                $precio = 219.00;
                $promo = $this->calcularPromocionMultipleBackend('2_HORAS', $q2, $precio, $esDiaFestivo);
                $conceptos[] = [
                    'tipo_entrada' => '2_HORAS',
                    'nombre' => '2 Horas',
                    'cantidad' => $q2,
                    'ninos' => $q2,
                    'adultos' => 0,
                    'precio_unitario' => $precio,
                    'subtotal' => $q2 * $precio,
                    'promocion_aplicada' => $promo['promo'],
                    'descuento' => $promo['descuento'],
                    'total' => $promo['totalPromo'],
                    'cover' => 0.00,
                    'total_calcetines' => 0.00,
                    'calcetin_venta' => null
                ];
            }

            if ($qi > 0) {
                $precio = 319.00;
                $promo = $this->calcularPromocionMultipleBackend('ILIMITADO', $qi, $precio, $esDiaFestivo);
                $conceptos[] = [
                    'tipo_entrada' => 'ILIMITADO',
                    'nombre' => 'Ilimitado',
                    'cantidad' => $qi,
                    'ninos' => $qi,
                    'adultos' => 0,
                    'precio_unitario' => $precio,
                    'subtotal' => $qi * $precio,
                    'promocion_aplicada' => $promo['promo'],
                    'descuento' => $promo['descuento'],
                    'total' => $promo['totalPromo'],
                    'cover' => 0.00,
                    'total_calcetines' => 0.00,
                    'calcetin_venta' => null
                ];
            }

            if ($qc > 0) {
                $precio = 30.00;
                $conceptos[] = [
                    'tipo_entrada' => 'SOLO_COVER',
                    'nombre' => 'Sólo Cover',
                    'cantidad' => $qc,
                    'ninos' => 0,
                    'adultos' => $qc,
                    'precio_unitario' => $precio,
                    'subtotal' => $qc * $precio,
                    'promocion_aplicada' => '',
                    'descuento' => 0.00,
                    'total' => $qc * $precio,
                    'cover' => 0.00,
                    'total_calcetines' => 0.00,
                    'calcetin_venta' => null
                ];
            }

            if ($cantidadCalcetin > 0) {
                if ($idCalcetin <= 0) {
                    $this->errorJson(
                        'No hay calcetines disponibles para vender.',
                        'id_calcetin=' . $idCalcetin . ', cantidad_calcetin=' . $cantidadCalcetin,
                        'store_multiple_validacion_calcetin',
                        $_POST
                    );
                }

                $calcetinVenta = $entradaModel->prepararCalcetinVenta($idCalcetin, $cantidadCalcetin);
                $totalCalcetines = (float)($calcetinVenta['total'] ?? 0);

                if ($totalCalcetines <= 0) {
                    $this->errorJson(
                        'Captura una cantidad válida de calcetines.',
                        'total_calcetines calculado=' . $totalCalcetines,
                        'store_multiple_validacion_total_calcetines',
                        $_POST
                    );
                }

                $conceptos[] = [
                    'tipo_entrada' => 'SOLO_CALCETINES',
                    'nombre' => 'Calcetines',
                    'cantidad' => 0,
                    'ninos' => 0,
                    'adultos' => 0,
                    'precio_unitario' => 0.00,
                    'subtotal' => $totalCalcetines,
                    'promocion_aplicada' => '',
                    'descuento' => 0.00,
                    'total' => $totalCalcetines,
                    'cover' => 0.00,
                    'total_calcetines' => $totalCalcetines,
                    'calcetin_venta' => $calcetinVenta,
                    'cantidad_calcetin' => $cantidadCalcetin
                ];
            }

            if (count($conceptos) === 0) {
                $this->errorJson(
                    'Agrega al menos una entrada, cover o calcetines.',
                    'No se recibió ninguna cantidad mayor a cero.',
                    'store_multiple_validacion_vacia',
                    $_POST
                );
            }

            $totalCalculadoVenta = array_reduce($conceptos, function ($carry, $item) {
                return $carry + (float)$item['total'];
            }, 0.00);

            $totalVenta = $this->redondearCobro($totalCalculadoVenta);

            $pagosCalculados = $this->calcularPagosMixtos($pagos, $totalVenta);

            if (!$pagosCalculados['valido']) {
                $this->errorJson(
                    $pagosCalculados['mensaje'],
                    $pagosCalculados['debug'],
                    'store_multiple_validacion_pago_mixto',
                    [
                        'post' => $_POST,
                        'pagos' => $pagos,
                        'total' => $totalVenta
                    ]
                );
            }

            $ids = [];
            $fechaGrupo = date('Y-m-d H:i:s');
            $idMetodoPrincipal = $pagosCalculados['id_metodo_principal'];
            $totalCapturado = $pagosCalculados['total_capturado'];
            $cambio = $pagosCalculados['cambio'];

            foreach ($conceptos as $concepto) {
                $ids[] = $entradaModel->crear([
                    'id_usuario' => $this->getUsuarioId(),
                    'adultos' => (int)$concepto['adultos'],
                    'ninos' => (int)$concepto['ninos'],
                    'tipo_entrada' => $concepto['tipo_entrada'],
                    'cantidad' => (int)$concepto['cantidad'],
                    'precio_unitario' => (float)$concepto['precio_unitario'],
                    'total' => (float)$concepto['total'],
                    'cover' => (float)$concepto['cover'],
                    'total_calcetines' => (float)$concepto['total_calcetines'],
                    'promocion_aplicada' => $concepto['promocion_aplicada'],
                    'descuento' => (float)$concepto['descuento'],
                    'es_dia_festivo' => $esDiaFestivo,
                    'paga_con' => (float)$concepto['total'],
                    'cambio' => 0.00,
                    'id_metodo_pago' => $idMetodoPrincipal,
                    'calcetin_venta' => $concepto['calcetin_venta'],
                    'fecha_registro' => $fechaGrupo,
                    'registrar_ingreso' => false
                ]);
            }

            $idReferenciaPago = (int)($ids[0] ?? 0);

            foreach ($pagosCalculados['pagos_registrables'] as $pago) {
                $entradaModel->registrarPagoEntrada(
                    $idReferenciaPago,
                    $this->getUsuarioId(),
                    (int)$pago['id_metodo_pago'],
                    (float)$pago['importe'],
                    'Pago de venta múltiple'
                );
            }

            $this->logEntrada('store_multiple_exito', 'Venta múltiple registrada correctamente', [
                'ids' => $ids,
                'conceptos' => $conceptos,
                'pagos' => $pagosCalculados,
                'total' => $totalVenta,
                'total_capturado' => $totalCapturado,
                'cambio' => $cambio
            ], false);

            $this->json([
                'success' => true,
                'message' => 'Venta múltiple registrada.',
                'ids' => $ids,
                'total' => $totalVenta,
                'total_capturado' => $totalCapturado,
                'paga_con' => $totalCapturado,
                'cambio' => $cambio,
                'pagos' => $pagosCalculados['pagos_registrables']
            ]);

        } catch (Throwable $e) {
            $this->errorJson(
                'Error al registrar venta múltiple.',
                $e->getMessage(),
                'store_multiple_exception',
                [
                    'post' => $_POST,
                    'archivo' => $e->getFile(),
                    'linea' => $e->getLine()
                ],
                $e
            );
        }
    }


    public function list(): void
    {
        $this->requireAuth();

        try {
            $m = new Entrada();

            $r = $m->listDataTables(
                (int)($_POST['start'] ?? 0),
                (int)($_POST['length'] ?? 10),
                trim($_POST['search']['value'] ?? '')
            );

            $this->json([
                'draw' => (int)($_POST['draw'] ?? 1),
                'recordsTotal' => $r['total'],
                'recordsFiltered' => $r['filtered'],
                'data' => $r['data']
            ]);

        } catch (Throwable $e) {
            $this->logEntrada('list_exception', 'Error al listar entradas', [
                'post' => $_POST,
                'error' => $e->getMessage(),
                'archivo' => $e->getFile(),
                'linea' => $e->getLine()
            ], true, $e);

            $this->json([
                'draw' => (int)($_POST['draw'] ?? 1),
                'recordsTotal' => 0,
                'recordsFiltered' => 0,
                'data' => [],
                'error' => $e->getMessage(),
                'debug' => $e->getMessage()
            ]);
        }
    }

    public function ticket(): void
    {
        $this->requireAuth();

        $id = (int)($_GET['id'] ?? 0);

        if ($id <= 0) {
            http_response_code(400);
            echo 'Ticket inválido.';
            return;
        }

        $model = new Entrada();
        $entrada = $model->obtenerTicket($id);

        if (!$entrada) {
            http_response_code(404);
            echo 'Ticket no encontrado.';
            return;
        }

        $grupoEntradas = $model->obtenerGrupoTicket($id);

        if (count($grupoEntradas) <= 1) {
            $grupoEntradas = [$entrada];
        }

        $idsGrupo = array_map(static function ($item) {
            return (int)$item['id'];
        }, $grupoEntradas);

        $calcetines = $model->obtenerCalcetinesTickets($idsGrupo);

        $this->view('entradas/ticket', [
            'entrada' => $entrada,
            'grupoEntradas' => $grupoEntradas,
            'calcetines' => $calcetines
        ]);
    }

    public function calcularSalida(): void
    {
        $this->requireAuth();

        try {
            $idEntrada = (int)($_POST['id_entrada'] ?? $_POST['id'] ?? 0);

            if ($idEntrada <= 0) {
                $this->errorJson(
                    'ID de entrada inválido.',
                    'POST recibido: ' . json_encode($_POST, JSON_UNESCAPED_UNICODE),
                    'calcular_salida_validacion',
                    $_POST
                );
            }

            $calculo = (new Entrada())->calcularSalida($idEntrada);

            if (!$calculo) {
                $this->errorJson(
                    'No se encontró la entrada.',
                    'id_entrada=' . $idEntrada,
                    'calcular_salida_no_encontrada',
                    $_POST
                );
            }

            $this->json([
                'success' => true,
                'data' => $calculo
            ]);

        } catch (Throwable $e) {
            $this->errorJson(
                'Error al calcular salida.',
                $e->getMessage(),
                'calcular_salida_exception',
                [
                    'post' => $_POST,
                    'archivo' => $e->getFile(),
                    'linea' => $e->getLine()
                ],
                $e
            );
        }
    }

    public function registrarSalida(): void
    {
        $this->requireAuth();

        try {
            $idEntrada = (int)($_POST['id_entrada'] ?? $_POST['id'] ?? 0);
            $pagaConExtra = (float)($_POST['paga_con_extra'] ?? 0);
            $idMetodoPago = (int)($_POST['id_metodo_pago_extra'] ?? $_POST['id_metodo_pago'] ?? 1);

            if ($idEntrada <= 0) {
                $this->errorJson(
                    'ID de entrada inválido.',
                    'POST recibido: ' . json_encode($_POST, JSON_UNESCAPED_UNICODE),
                    'registrar_salida_validacion_id',
                    $_POST
                );
            }

            if ($idMetodoPago <= 0) {
                $idMetodoPago = 1;
            }

            $resultado = (new Entrada())->registrarSalida(
                $idEntrada,
                $this->getUsuarioId(),
                $idMetodoPago,
                $pagaConExtra
            );

            $this->json([
                'success' => true,
                'message' => 'Salida registrada.',
                'data' => $resultado
            ]);

        } catch (Throwable $e) {
            $this->errorJson(
                'Error al registrar salida.',
                $e->getMessage(),
                'registrar_salida_exception',
                [
                    'post' => $_POST,
                    'archivo' => $e->getFile(),
                    'linea' => $e->getLine()
                ],
                $e
            );
        }
    }


    private function redondearCobro(float $importe): float
    {
        return (float)round($importe, 0);
    }

    private function normalizarPagosMixtos(array $post): array
    {
        return [
            'efectivo' => $this->redondearCobro(max(0, (float)($post['pago_efectivo'] ?? 0))),
            'tarjeta' => $this->redondearCobro(max(0, (float)($post['pago_tarjeta'] ?? 0))),
            'transferencia' => $this->redondearCobro(max(0, (float)($post['pago_transferencia'] ?? 0))),
            'cortesia' => $this->redondearCobro(max(0, (float)($post['pago_cortesia'] ?? 0)))
        ];
    }

    private function calcularPagosMixtos(array $pagos, float $totalVenta): array
    {
        $totalVenta = $this->redondearCobro($totalVenta);

        $efectivo = $this->redondearCobro((float)($pagos['efectivo'] ?? 0));
        $tarjeta = $this->redondearCobro((float)($pagos['tarjeta'] ?? 0));
        $transferencia = $this->redondearCobro((float)($pagos['transferencia'] ?? 0));
        $cortesia = $this->redondearCobro((float)($pagos['cortesia'] ?? 0));

        $totalCapturado = $efectivo + $tarjeta + $transferencia + $cortesia;
        $cambio = max(0, $totalCapturado - $totalVenta);

        if ($totalVenta <= 0) {
            return [
                'valido' => false,
                'mensaje' => 'El total de la venta debe ser mayor a cero.',
                'debug' => 'total=' . $totalVenta
            ];
        }

        if ($totalCapturado < $totalVenta) {
            return [
                'valido' => false,
                'mensaje' => 'Pago insuficiente. Falta $' . number_format($totalVenta - $totalCapturado, 0),
                'debug' => 'total=' . number_format($totalVenta, 0) . ', capturado=' . number_format($totalCapturado, 0)
            ];
        }

        if ($cambio > $efectivo) {
            return [
                'valido' => false,
                'mensaje' => 'El cambio no puede ser mayor al efectivo recibido.',
                'debug' => 'efectivo=' . number_format($efectivo, 0) . ', cambio=' . number_format($cambio, 0)
            ];
        }

        $efectivoRegistrado = $this->redondearCobro($efectivo - $cambio);

        $pagosRegistrables = [];

        if ($efectivoRegistrado > 0) {
            $pagosRegistrables[] = ['id_metodo_pago' => 1, 'nombre' => 'Efectivo', 'importe' => $efectivoRegistrado];
        }

        if ($tarjeta > 0) {
            $pagosRegistrables[] = ['id_metodo_pago' => 2, 'nombre' => 'Tarjeta', 'importe' => $tarjeta];
        }

        if ($transferencia > 0) {
            $pagosRegistrables[] = ['id_metodo_pago' => 3, 'nombre' => 'Transferencia', 'importe' => $transferencia];
        }

        if ($cortesia > 0) {
            $pagosRegistrables[] = ['id_metodo_pago' => 4, 'nombre' => 'Cortesía', 'importe' => $cortesia];
        }

        $totalRegistrable = $this->redondearCobro(array_reduce($pagosRegistrables, function ($carry, $pago) {
            return $carry + (float)$pago['importe'];
        }, 0.00));

        if (abs($totalRegistrable - $totalVenta) > 0.01) {
            return [
                'valido' => false,
                'mensaje' => 'Los métodos de pago no cuadran con el total de la venta.',
                'debug' => 'registrable=' . number_format($totalRegistrable, 0) . ', total=' . number_format($totalVenta, 0)
            ];
        }

        $idMetodoPrincipal = count($pagosRegistrables) > 0 ? (int)$pagosRegistrables[0]['id_metodo_pago'] : 1;

        return [
            'valido' => true,
            'pagos_originales' => [
                'efectivo' => $efectivo,
                'tarjeta' => $tarjeta,
                'transferencia' => $transferencia,
                'cortesia' => $cortesia
            ],
            'pagos_registrables' => $pagosRegistrables,
            'total_capturado' => $totalCapturado,
            'total_registrado' => $totalRegistrable,
            'cambio' => $cambio,
            'id_metodo_principal' => $idMetodoPrincipal
        ];
    }


    private function calcularPromocionMultipleBackend(string $tipo, int $cantidad, float $precio, int $esDiaFestivo = 0): array
    {
        $subtotal = $cantidad * $precio;

        $promo = '';
        $descuento = 0.00;
        $totalPromo = $subtotal;

        $aplicaPromo = !$esDiaFestivo && in_array($tipo, ['2_HORAS', 'ILIMITADO'], true);

        if (!$aplicaPromo || $cantidad <= 0) {
            return [
                'promo' => $promo,
                'descuento' => $descuento,
                'totalPromo' => $totalPromo
            ];
        }

        $dia = (int)date('N'); // 1=Lunes, 2=Martes, ..., 7=Domingo

        if ($dia === 1) {
            $promo = 'Lunes: Agua natural gratis';
        }

        if ($dia === 2) {
            $descuento = $subtotal * 0.10;
            $totalPromo = $subtotal - $descuento;
            $promo = 'Martes: 10% de descuento';
        }

        if ($dia === 3) {
            $promo = 'Miércoles: Pizza individual gratis';
        }

        // Jueves: promoción exclusiva para Ilimitado.
        // No aplica para 2 Horas.
        if ($dia === 4 && $tipo === 'ILIMITADO') {
            $bloques = intdiv($cantidad, 3);
            $restantes = $cantidad % 3;

            if ($bloques > 0) {
                $totalPromo = ($bloques * 599.00) + ($restantes * $precio);
                $descuento = $subtotal - $totalPromo;
                $promo = 'Jueves: 3 personas por $599';
            }
        }

        if ($dia === 5) {
            $pagados = (int)ceil($cantidad / 2);
            $totalPromo = $pagados * $precio;
            $descuento = $subtotal - $totalPromo;
            $promo = 'Viernes: 2x1';
        }

        return [
            'promo' => $promo,
            'descuento' => round($descuento, 2),
            'totalPromo' => round($totalPromo, 2)
        ];
    }


    private function getUsuarioId(): int
    {
        if (isset($_SESSION['user']['id'])) {
            return (int)$_SESSION['user']['id'];
        }

        if (isset($_SESSION['usuario']['id'])) {
            return (int)$_SESSION['usuario']['id'];
        }

        if (isset($_SESSION['id_usuario'])) {
            return (int)$_SESSION['id_usuario'];
        }

        return 1;
    }

    private function errorJson(
        string $message,
        string $debug,
        string $accion,
        array $datos = [],
        ?Throwable $e = null
    ): void {
        $this->logEntrada($accion, $message . ' | ' . $debug, $datos, true, $e);

        $this->json([
            'success' => false,
            'message' => $message,
            'debug' => $debug,
            'log_file' => 'logs/entradas_error.log'
        ]);
    }

    private function logEntrada(
        string $accion,
        string $mensaje,
        array $datos = [],
        bool $esError = true,
        ?Throwable $e = null
    ): void {
        $usuarioId = $this->getUsuarioId();
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $url = $_SERVER['REQUEST_URI'] ?? '';
        $metodo = $_SERVER['REQUEST_METHOD'] ?? '';

        $payload = [
            'fecha' => date('Y-m-d H:i:s'),
            'accion' => $accion,
            'usuario_id' => $usuarioId,
            'ip' => $ip,
            'metodo' => $metodo,
            'url' => $url,
            'mensaje' => $mensaje,
            'datos' => $datos
        ];

        if ($e) {
            $payload['exception'] = [
                'message' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString()
            ];
        }

        $logDir = __DIR__ . '/../../logs';

        if (!is_dir($logDir)) {
            @mkdir($logDir, 0755, true);
        }

        $filename = $esError ? 'entradas_error.log' : 'entradas_debug.log';
        $file = $logDir . '/' . $filename;

        $line = "==================================================\n";
        $line .= json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        $line .= "\n";

        @file_put_contents($file, $line, FILE_APPEND);

        try {
            if (class_exists('Entrada')) {
                (new Entrada())->registrarLogEntrada($accion, $mensaje, $datos, $usuarioId, $ip, $esError);
            }
        } catch (Throwable $ignore) {
            // No romper el flujo principal por un fallo al guardar log en BD.
        }
    }
}
