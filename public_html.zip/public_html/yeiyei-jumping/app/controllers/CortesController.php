<?php
require_once __DIR__ . '/Controller.php';
require_once __DIR__ . '/../models/Dashboard.php';
class CortesController extends Controller
{
    public function index(): void { $this->requireAdmin(); $resumen=(new Dashboard())->resumenHoy(); $this->view('cortes/index', compact('resumen')); }
}
