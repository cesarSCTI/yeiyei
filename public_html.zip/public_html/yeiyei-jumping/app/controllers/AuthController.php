<?php
require_once __DIR__ . '/Controller.php';
require_once __DIR__ . '/../models/Usuario.php';

class AuthController extends Controller
{
    public function index(): void
    {
        if (!empty($_SESSION['user'])) {
            header('Location: ' . base_url('dashboard'));
            exit;
        }

        $this->view('auth/login');
    }

    public function login(): void
    {
        try {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                $this->responderLogin(false, 'Método no permitido.');
                return;
            }

            $usuario = trim($_POST['usuario'] ?? '');
            $password = trim($_POST['password'] ?? '');

            if ($usuario === '' || $password === '') {
                $this->responderLogin(false, 'Usuario y contraseña son obligatorios.');
                return;
            }

            $model = new Usuario();
            $user = $model->findByUsername($usuario);

            if (!$user) {
                $this->responderLogin(false, 'Credenciales incorrectas.');
                return;
            }

            $passwordOk = password_verify($password, $user['password']);

            // Respaldo para instalaciones donde el password haya quedado temporalmente en texto plano.
            // Si entra por este caso, actualiza el hash automáticamente.
            if (!$passwordOk && hash_equals((string)$user['password'], $password)) {
                $passwordOk = true;
                $model->updatePasswordHash((int)$user['id'], password_hash($password, PASSWORD_DEFAULT));
            }

            if (!$passwordOk) {
                $this->responderLogin(false, 'Credenciales incorrectas.');
                return;
            }

            $_SESSION['user'] = [
                'id' => (int)$user['id'],
                'id_rol' => (int)$user['id_rol'],
                'nombre' => $user['nombre'],
                'usuario' => $user['usuario'],
                'rol' => $user['rol'] ?? 'Usuario'
            ];

            $this->responderLogin(true, 'Bienvenido', base_url('dashboard'));

        } catch (Throwable $e) {
            $this->responderLogin(false, 'Error al iniciar sesión: ' . $e->getMessage());
        }
    }

    public function logout(): void
    {
        session_destroy();
        header('Location: ' . base_url('login'));
        exit;
    }

    private function responderLogin(bool $success, string $message, ?string $redirect = null): void
    {
        $payload = [
            'success' => $success,
            'message' => $message
        ];

        if ($redirect !== null) {
            $payload['redirect'] = $redirect;
        }

        /*
         * Si el formulario se envía por AJAX, responder JSON.
         * Si por alguna razón auth.js no carga o el formulario se envía normal,
         * NO dejamos el JSON visible en pantalla: redirigimos.
         */
        if ($this->isAjaxRequest()) {
            $this->json($payload);
            return;
        }

        if ($success) {
            header('Location: ' . ($redirect ?? base_url('dashboard')));
            exit;
        }

        $_SESSION['login_error'] = $message;
        header('Location: ' . base_url('login'));
        exit;
    }

    private function isAjaxRequest(): bool
    {
        $requestedWith = strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '');
        $accept = strtolower($_SERVER['HTTP_ACCEPT'] ?? '');

        return $requestedWith === 'xmlhttprequest'
            || str_contains($accept, 'application/json');
    }
}
