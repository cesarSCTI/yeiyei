<?php
require_once __DIR__ . '/Controller.php';
require_once __DIR__ . '/../models/Dashboard.php';

class DashboardController extends Controller
{
    public function index(): void
    {
        $this->requireAuth();
        $resumen = (new Dashboard())->resumenHoy();
        $this->view('dashboard/index', compact('resumen'));
    }
}
