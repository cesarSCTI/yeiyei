<?php
require_once __DIR__ . '/Controller.php';
require_once __DIR__ . '/../models/Ingreso.php';
class IngresosController extends Controller
{
    public function index(): void { $this->requireAdmin(); $this->view('ingresos/index'); }
    public function list(): void { $this->requireAdmin(); $r=(new Ingreso())->listDataTables((int)($_POST['start']??0),(int)($_POST['length']??10),trim($_POST['search']['value']??'')); $this->json(['draw'=>(int)($_POST['draw']??1),'recordsTotal'=>$r['total'],'recordsFiltered'=>$r['filtered'],'data'=>$r['data']]); }
}
