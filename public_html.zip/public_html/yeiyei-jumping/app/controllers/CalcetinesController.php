<?php
require_once __DIR__ . '/Controller.php';
require_once __DIR__ . '/../models/Calcetin.php';

class CalcetinesController extends Controller
{
    public function index(): void
    {
        $this->requireAdmin();
        $this->view('calcetines/index');
    }

    public function list(): void
    {
        $this->requireAdmin();

        try {
            $r = (new Calcetin())->listDataTables(
                (int)($_POST['start'] ?? 0),
                (int)($_POST['length'] ?? 10),
                trim($_POST['search']['value'] ?? '')
            );

            $this->json([
                'draw' => (int)($_POST['draw'] ?? 1),
                'recordsTotal' => $r['total'],
                'recordsFiltered' => $r['filtered'],
                'data' => $r['data']
            ]);
        } catch (Throwable $e) {
            $this->json([
                'draw' => (int)($_POST['draw'] ?? 1),
                'recordsTotal' => 0,
                'recordsFiltered' => 0,
                'data' => [],
                'error' => $e->getMessage()
            ]);
        }
    }

    public function show(): void
    {
        $this->requireAdmin();

        try {
            $id = (int)($_POST['id'] ?? 0);

            if ($id <= 0) {
                $this->json([
                    'success' => false,
                    'message' => 'Registro inválido.'
                ]);
                return;
            }

            $row = (new Calcetin())->findById($id);

            if (!$row) {
                $this->json([
                    'success' => false,
                    'message' => 'Registro no encontrado.'
                ]);
                return;
            }

            $this->json([
                'success' => true,
                'message' => 'Registro encontrado.',
                'data' => $row
            ]);
        } catch (Throwable $e) {
            $this->json([
                'success' => false,
                'message' => 'Error al obtener registro: ' . $e->getMessage()
            ]);
        }
    }

    public function store(): void
    {
        $this->requireAdmin();

        try {
            $precio = (float)($_POST['precio'] ?? 0);
            $stockInicial = (int)($_POST['stock_inicial'] ?? 0);

            if ($precio <= 0) {
                $this->json([
                    'success' => false,
                    'message' => 'El precio debe ser mayor a cero.'
                ]);
                return;
            }

            if ($stockInicial < 0) {
                $this->json([
                    'success' => false,
                    'message' => 'El stock inicial no puede ser negativo.'
                ]);
                return;
            }

            $ok = (new Calcetin())->create([
                'precio' => $precio,
                'stock_inicial' => $stockInicial
            ]);

            $this->json([
                'success' => $ok,
                'message' => $ok
                    ? 'Registro de calcetines creado correctamente.'
                    : 'No se pudo registrar calcetines.'
            ]);
        } catch (Throwable $e) {
            $this->json([
                'success' => false,
                'message' => 'Error al registrar: ' . $e->getMessage()
            ]);
        }
    }

    public function update(): void
    {
        $this->requireAdmin();

        try {
            $id = (int)($_POST['calcetin_id'] ?? ($_POST['id'] ?? 0));
            $precio = (float)($_POST['precio'] ?? 0);
            $stockInicial = (int)($_POST['stock_inicial'] ?? 0);

            if ($id <= 0) {
                $this->json([
                    'success' => false,
                    'message' => 'Registro inválido.'
                ]);
                return;
            }

            if ($precio <= 0) {
                $this->json([
                    'success' => false,
                    'message' => 'El precio debe ser mayor a cero.'
                ]);
                return;
            }

            if ($stockInicial < 0) {
                $this->json([
                    'success' => false,
                    'message' => 'El stock inicial no puede ser negativo.'
                ]);
                return;
            }

            $model = new Calcetin();
            $calcetin = $model->findById($id);

            if (!$calcetin) {
                $this->json([
                    'success' => false,
                    'message' => 'Registro no encontrado.'
                ]);
                return;
            }

            $vendidos = (int)($calcetin['vendidos'] ?? 0);

            if ($stockInicial < $vendidos) {
                $this->json([
                    'success' => false,
                    'message' => 'El stock inicial no puede ser menor a los calcetines ya vendidos (' . $vendidos . ').'
                ]);
                return;
            }

            $ok = $model->updateCalcetin($id, [
                'precio' => $precio,
                'stock_inicial' => $stockInicial
            ]);

            $this->json([
                'success' => $ok,
                'message' => $ok
                    ? 'Registro actualizado correctamente.'
                    : 'No se pudo actualizar el registro.'
            ]);
        } catch (Throwable $e) {
            $this->json([
                'success' => false,
                'message' => 'Error al actualizar: ' . $e->getMessage()
            ]);
        }
    }

    public function toggle(): void
    {
        $this->requireAdmin();

        try {
            $id = (int)($_POST['id'] ?? 0);

            if ($id <= 0) {
                $this->json([
                    'success' => false,
                    'message' => 'Registro inválido.'
                ]);
                return;
            }

            $ok = (new Calcetin())->toggleStatus($id);

            $this->json([
                'success' => $ok,
                'message' => $ok
                    ? 'Estado actualizado correctamente.'
                    : 'No se pudo actualizar el estado.'
            ]);
        } catch (Throwable $e) {
            $this->json([
                'success' => false,
                'message' => 'Error al cambiar estado: ' . $e->getMessage()
            ]);
        }
    }

    public function stock(): void
    {
        $this->requireAdmin();
        $this->procesarAjusteStock();
    }

    public function ajustarStock(): void
    {
        $this->requireAdmin();
        $this->procesarAjusteStock();
    }

    private function procesarAjusteStock(): void
    {
        try {
            $id = (int)($_POST['stock_calcetin_id'] ?? ($_POST['id'] ?? 0));
            $cantidad = (int)($_POST['cantidad'] ?? 0);

            if ($id <= 0) {
                $this->json([
                    'success' => false,
                    'message' => 'Registro inválido.'
                ]);
                return;
            }

            if ($cantidad === 0) {
                $this->json([
                    'success' => false,
                    'message' => 'La cantidad del ajuste no puede ser cero.'
                ]);
                return;
            }

            $model = new Calcetin();
            $calcetin = $model->findById($id);

            if (!$calcetin) {
                $this->json([
                    'success' => false,
                    'message' => 'Registro no encontrado.'
                ]);
                return;
            }

            $existencias = (int)($calcetin['existencias'] ?? $calcetin['stock'] ?? 0);
            $nuevoStock = $existencias + $cantidad;

            if ($nuevoStock < 0) {
                $this->json([
                    'success' => false,
                    'message' => 'El ajuste deja las existencias en negativo.'
                ]);
                return;
            }

            $ok = $model->adjustStock($id, $cantidad);

            $this->json([
                'success' => $ok,
                'message' => $ok
                    ? 'Existencias actualizadas correctamente.'
                    : 'No se pudo actualizar la existencia.'
            ]);
        } catch (Throwable $e) {
            $this->json([
                'success' => false,
                'message' => 'Error al ajustar existencias: ' . $e->getMessage()
            ]);
        }
    }
}
