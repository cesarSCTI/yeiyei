<?php
require_once __DIR__ . '/Controller.php';
require_once __DIR__ . '/../models/Usuario.php';

class UsuariosController extends Controller
{
    public function index(): void
    {
        $this->requireAdmin();
        $model = new Usuario();
        $this->view('usuarios/index', [
            'roles' => $model->roles()
        ]);
    }

    public function list(): void
    {
        $this->requireAdmin();
        $r = (new Usuario())->listDataTables(
            (int)($_POST['start'] ?? 0),
            (int)($_POST['length'] ?? 10),
            trim($_POST['search']['value'] ?? '')
        );

        $this->json([
            'draw' => (int)($_POST['draw'] ?? 1),
            'recordsTotal' => $r['total'],
            'recordsFiltered' => $r['filtered'],
            'data' => $r['data']
        ]);
    }

    public function show(): void
    {
        $this->requireAdmin();

        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            $this->json(['success' => false, 'message' => 'Usuario inválido.']);
        }

        $usuario = (new Usuario())->findById($id);
        if (!$usuario) {
            $this->json(['success' => false, 'message' => 'Usuario no encontrado.']);
        }

        $this->json(['success' => true, 'data' => $usuario]);
    }

    public function store(): void
    {
        $this->requireAdmin();

        try {
            $nombre = trim($_POST['nombre'] ?? '');
            $usuario = trim($_POST['usuario'] ?? '');
            $password = trim($_POST['password'] ?? '');
            $idRol = (int)($_POST['id_rol'] ?? 0);

            if ($nombre === '' || $usuario === '' || $password === '' || $idRol <= 0) {
                $this->json(['success' => false, 'message' => 'Todos los campos son obligatorios.']);
            }

            if (strlen($password) < 6) {
                $this->json(['success' => false, 'message' => 'La contraseña debe tener mínimo 6 caracteres.']);
            }

            $model = new Usuario();
            if ($model->usernameExists($usuario)) {
                $this->json(['success' => false, 'message' => 'El nombre de usuario ya existe.']);
            }

            $ok = $model->create([
                'nombre' => $nombre,
                'usuario' => $usuario,
                'password' => $password,
                'id_rol' => $idRol
            ]);

            $this->json([
                'success' => $ok,
                'message' => $ok ? 'Usuario registrado correctamente.' : 'No se pudo registrar el usuario.'
            ]);
        } catch (Throwable $e) {
            $this->json(['success' => false, 'message' => 'Error al registrar: ' . $e->getMessage()]);
        }
    }

    public function update(): void
    {
        $this->requireAdmin();

        try {
            $id = (int)($_POST['id'] ?? 0);
            $nombre = trim($_POST['nombre'] ?? '');
            $usuario = trim($_POST['usuario'] ?? '');
            $idRol = (int)($_POST['id_rol'] ?? 0);

            if ($id <= 0 || $nombre === '' || $usuario === '' || $idRol <= 0) {
                $this->json(['success' => false, 'message' => 'Datos incompletos.']);
            }

            $model = new Usuario();
            if (!$model->findById($id)) {
                $this->json(['success' => false, 'message' => 'Usuario no encontrado.']);
            }

            if ($model->usernameExists($usuario, $id)) {
                $this->json(['success' => false, 'message' => 'El nombre de usuario ya está en uso.']);
            }

            $ok = $model->updateUser($id, [
                'nombre' => $nombre,
                'usuario' => $usuario,
                'id_rol' => $idRol
            ]);

            $this->json([
                'success' => $ok,
                'message' => $ok ? 'Usuario actualizado correctamente.' : 'No se pudo actualizar el usuario.'
            ]);
        } catch (Throwable $e) {
            $this->json(['success' => false, 'message' => 'Error al actualizar: ' . $e->getMessage()]);
        }
    }

    public function password(): void
    {
        $this->requireAdmin();

        try {
            $id = (int)($_POST['id'] ?? 0);
            $password = trim($_POST['password'] ?? '');
            $confirmar = trim($_POST['confirmar_password'] ?? '');

            if ($id <= 0 || $password === '' || $confirmar === '') {
                $this->json(['success' => false, 'message' => 'Datos incompletos.']);
            }

            if ($password !== $confirmar) {
                $this->json(['success' => false, 'message' => 'Las contraseñas no coinciden.']);
            }

            if (strlen($password) < 6) {
                $this->json(['success' => false, 'message' => 'La contraseña debe tener mínimo 6 caracteres.']);
            }

            $ok = (new Usuario())->changePassword($id, $password);

            $this->json([
                'success' => $ok,
                'message' => $ok ? 'Contraseña actualizada correctamente.' : 'No se pudo actualizar la contraseña.'
            ]);
        } catch (Throwable $e) {
            $this->json(['success' => false, 'message' => 'Error al cambiar contraseña: ' . $e->getMessage()]);
        }
    }

    public function toggle(): void
    {
        $this->requireAdmin();

        try {
            $id = (int)($_POST['id'] ?? 0);
            $sessionId = (int)($_SESSION['user']['id'] ?? 0);

            if ($id <= 0) {
                $this->json(['success' => false, 'message' => 'Usuario inválido.']);
            }

            if ($id === $sessionId) {
                $this->json(['success' => false, 'message' => 'No puedes desactivar tu propio usuario.']);
            }

            $ok = (new Usuario())->toggleStatus($id);

            $this->json([
                'success' => $ok,
                'message' => $ok ? 'Estado actualizado correctamente.' : 'No se pudo actualizar el estado.'
            ]);
        } catch (Throwable $e) {
            $this->json(['success' => false, 'message' => 'Error al cambiar estado: ' . $e->getMessage()]);
        }
    }
}
