<?php
class Controller
{
    protected function view(string $view, array $data = []): void
    {
        extract($data);
        require __DIR__ . '/../views/' . $view . '.php';
    }

    protected function json(array $data): void
    {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data);
        exit;
    }

    protected function requireAuth(): void
    {
        if (empty($_SESSION['user'])) {
            header('Location: ' . base_url('login'));
            exit;
        }
    }

    protected function requireAdmin(): void
    {
        $this->requireAuth();
        if ((int)$_SESSION['user']['id_rol'] !== 1) {
            http_response_code(403);
            $this->view('errors/403');
            exit;
        }
    }
}
