<?php

define('APP_NAME', 'Comanda360');

define('BASE_URL', '/comanda360/public');

date_default_timezone_set('America/Mexico_City');