<?php

define('DB_HOST', 'localhost');

define('DB_NAME', 'yeiyeisw_comanda360');

define('DB_USER', 'yeiyeisw');

define('DB_PASS', '8p@A5M-pTkV52g');