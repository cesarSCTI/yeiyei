<?php

require_once "config/database.php";

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS
    );

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "CONEXIÓN CORRECTA";

} catch (PDOException $e) {
    echo "ERROR: " . $e->getMessage();
}