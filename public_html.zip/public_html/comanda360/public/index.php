<?php

ini_set('session.gc_maxlifetime', 43200);
ini_set('session.cookie_lifetime', 43200);

session_set_cookie_params([
    'lifetime' => 43200,
    'path' => '/',
    'secure' => isset($_SERVER['HTTPS']),
    'httponly' => true,
    'samesite' => 'Lax'
]);

session_start();

require_once "../config/app.php";
require_once "../config/database.php";

require_once "../app/core/Database.php";
require_once "../app/core/Controller.php";
require_once "../app/core/Model.php";
require_once "../app/helpers/AuthHelper.php";

$url = $_GET['url'] ?? 'auth/login';

$url = explode('/', rtrim($url, '/'));

$controllerName = ucfirst($url[0]) . 'Controller';

$method = $url[1] ?? 'index';

$controllerFile = "../app/controllers/" . $controllerName . ".php";

if (!file_exists($controllerFile)) {
    die("Controlador no encontrado");
}

require_once $controllerFile;

$controller = new $controllerName();

if (!method_exists($controller, $method)) {
    die("Método no encontrado");
}

$params = array_slice($url, 2);

call_user_func_array([$controller, $method], $params);