document.addEventListener('DOMContentLoaded', function () {
    const fechaInput = document.getElementById('fechaEgreso');

    if (fechaInput) {
        fechaInput.value = obtenerFechaHoy();
    }

    cargarEgresos();

    const form = document.getElementById('formEgreso');

    if (form) {
        form.addEventListener('submit', guardarEgreso);
    }
});

function obtenerFechaHoy() {
    const hoy = new Date();
    const year = hoy.getFullYear();
    const month = String(hoy.getMonth() + 1).padStart(2, '0');
    const day = String(hoy.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}`;
}

function cargarEgresos() {
    const fecha = document.getElementById('fechaEgreso').value;

    fetch(`${BASE_URL}/egresos/listar?fecha=${fecha}`)
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                Swal.fire('Aviso', data.message, 'warning');
                return;
            }

            document.getElementById('totalEgresos').innerText = `$${formatoMoneda(data.total)}`;
            renderEgresos(data.data);
        })
        .catch(error => {
            console.error(error);
            Swal.fire('Error', 'No se pudieron cargar los egresos.', 'error');
        });
}

function guardarEgreso(e) {
    e.preventDefault();

    const form = document.getElementById('formEgreso');
    const fecha = document.getElementById('fechaEgreso').value;

    const formData = new FormData(form);
    formData.append('fecha', fecha);

    fetch(`${BASE_URL}/egresos/guardar`, {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                Swal.fire('Aviso', data.message, 'warning');
                return;
            }

            Swal.fire({
                icon: 'success',
                title: 'Egreso registrado',
                text: data.message,
                timer: 1300,
                showConfirmButton: false
            });

            form.reset();
            cargarEgresos();
        })
        .catch(error => {
            console.error(error);
            Swal.fire('Error', 'No se pudo guardar el egreso.', 'error');
        });
}

function renderEgresos(egresos) {
    const contenedor = document.getElementById('contenedorEgresos');

    if (!egresos || egresos.length === 0) {
        contenedor.innerHTML = `
            <div class="alert alert-secondary">
                No hay egresos registrados para esta fecha.
            </div>
        `;
        return;
    }

    let html = `
        <div class="table-responsive">
            <table class="table table-sm table-hover align-middle">
                <thead>
                    <tr>
                        <th>Concepto</th>
                        <th>Descripción</th>
                        <th>Usuario</th>
                        <th class="text-end">Monto</th>
                        <th>Fecha registro</th>
                    </tr>
                </thead>
                <tbody>
    `;

    egresos.forEach(e => {
        html += `
            <tr>
                <td>${escaparHtml(e.concepto)}</td>
                <td>${e.descripcion ? escaparHtml(e.descripcion) : '<span class="text-muted">Sin descripción</span>'}</td>
                <td>${escaparHtml(e.usuario)}</td>
                <td class="text-end fw-bold">$${formatoMoneda(e.monto)}</td>
                <td>${e.created_at}</td>
            </tr>
        `;
    });

    html += `
                </tbody>
            </table>
        </div>
    `;

    contenedor.innerHTML = html;
}

function formatoMoneda(valor) {
    return parseFloat(valor || 0).toFixed(2);
}

function escaparHtml(texto) {
    const div = document.createElement('div');
    div.textContent = texto ?? '';
    return div.innerHTML;
}