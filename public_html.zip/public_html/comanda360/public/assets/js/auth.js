document.addEventListener('DOMContentLoaded', function () {
    const formLogin = document.getElementById('formLogin');
    const btnLogin = document.getElementById('btnLogin');

    if (!formLogin) {
        return;
    }

    formLogin.addEventListener('submit', function (e) {
        e.preventDefault();

        const formData = new FormData(formLogin);

        btnLogin.disabled = true;
        btnLogin.innerText = 'Validando...';

        fetch(`${BASE_URL}/auth/validar`, {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = data.redirect;
                    return;
                }

                Swal.fire({
                    icon: 'warning',
                    title: 'Acceso no permitido',
                    text: data.message
                });
            })
            .catch(error => {
                console.error(error);

                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'No se pudo procesar el inicio de sesión.'
                });
            })
            .finally(() => {
                btnLogin.disabled = false;
                btnLogin.innerText = 'Ingresar';
            });
    });
});