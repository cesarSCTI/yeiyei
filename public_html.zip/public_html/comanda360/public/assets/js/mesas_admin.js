let mesasAdminGlobal = [];

document.addEventListener('DOMContentLoaded', function () {
    cargarMesasAdmin();
});

function cargarMesasAdmin() {
    fetch(`${BASE_URL}/mesasAdmin/listar`)
        .then(r => r.json())
        .then(data => {
            if (!data.success) {
                Swal.fire('Aviso', data.message, 'warning');
                return;
            }

            mesasAdminGlobal = data.data;
            renderMesasAdmin(data.data);
        })
        .catch(error => {
            console.error(error);
            Swal.fire('Error', 'No se pudieron cargar las mesas.', 'error');
        });
}

function renderMesasAdmin(mesas) {
    const contenedor = document.getElementById('contenedorMesasAdmin');

    if (!mesas || mesas.length === 0) {
        contenedor.innerHTML = `
            <div class="alert alert-secondary">
                No hay mesas registradas.
            </div>
        `;
        return;
    }

    let html = `
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-sm table-hover align-middle">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Mesa</th>
                                <th>Descripción</th>
                                <th>Estado operativo</th>
                                <th>Activa</th>
                                <th class="text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
    `;

    mesas.forEach(m => {
        html += `
            <tr>
                <td>${m.id}</td>
                <td><strong>${escaparHtml(m.nombre)}</strong></td>
                <td>${m.descripcion ? escaparHtml(m.descripcion) : '<span class="text-muted">Sin descripción</span>'}</td>
                <td>
                    <span class="badge ${badgeEstado(m.estado)}">
                        ${m.estado.replace('_', ' ')}
                    </span>
                </td>
                <td>
                    <span class="badge ${parseInt(m.activo) === 1 ? 'bg-success' : 'bg-secondary'}">
                        ${parseInt(m.activo) === 1 ? 'Sí' : 'No'}
                    </span>
                </td>
                <td class="text-center">
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-primary" onclick="editarMesa(${m.id})">
                            Editar
                        </button>

                        <button 
                            class="btn ${parseInt(m.activo) === 1 ? 'btn-outline-danger' : 'btn-outline-success'}"
                            onclick="cambiarActivoMesa(${m.id}, ${parseInt(m.activo) === 1 ? 0 : 1})"
                        >
                            ${parseInt(m.activo) === 1 ? 'Desactivar' : 'Activar'}
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });

    html += `
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    `;

    contenedor.innerHTML = html;
}

function nuevaMesa() {
    abrirModalMesa(null);
}

function editarMesa(id) {
    const mesa = mesasAdminGlobal.find(m => parseInt(m.id) === parseInt(id));
    abrirModalMesa(mesa);
}

function abrirModalMesa(mesa) {
    const editar = !!mesa;

    Swal.fire({
        title: editar ? 'Editar mesa' : 'Nueva mesa',
        html: `
            <div class="text-start">
                <input type="hidden" id="mesaId" value="${editar ? mesa.id : 0}">

                <label class="form-label">Nombre</label>
                <input 
                    id="nombreMesa" 
                    class="form-control mb-3" 
                    value="${editar ? escaparAtributo(mesa.nombre) : ''}"
                    placeholder="Ej. Mesa 10"
                >

                <label class="form-label">Descripción</label>
                <textarea 
                    id="descripcionMesa" 
                    class="form-control" 
                    rows="3"
                    placeholder="Ej. Área principal, ventana, exterior"
                >${editar && mesa.descripcion ? escaparHtml(mesa.descripcion) : ''}</textarea>

                ${editar ? `
                    <div class="alert alert-light border mt-3 mb-0">
                        Estado operativo actual: <strong>${mesa.estado.replace('_', ' ')}</strong>
                        <br>
                        <small>Este estado lo controla automáticamente el sistema.</small>
                    </div>
                ` : ''}
            </div>
        `,
        width: 600,
        showCancelButton: true,
        confirmButtonText: 'Guardar',
        cancelButtonText: 'Cancelar',
        preConfirm: () => {
            const data = {
                id: document.getElementById('mesaId').value,
                nombre: document.getElementById('nombreMesa').value.trim(),
                descripcion: document.getElementById('descripcionMesa').value.trim()
            };

            if (!data.nombre) {
                Swal.showValidationMessage('Captura el nombre de la mesa.');
                return false;
            }

            return data;
        }
    }).then(result => {
        if (!result.isConfirmed) return;

        guardarMesa(result.value);
    });
}

function guardarMesa(data) {
    const formData = new FormData();
    formData.append('id', data.id);
    formData.append('nombre', data.nombre);
    formData.append('descripcion', data.descripcion);

    fetch(`${BASE_URL}/mesasAdmin/guardar`, {
        method: 'POST',
        body: formData
    })
        .then(r => r.json())
        .then(data => {
            Swal.fire(
                data.success ? 'Listo' : 'Aviso',
                data.message,
                data.success ? 'success' : 'warning'
            );

            if (data.success) {
                cargarMesasAdmin();
            }
        })
        .catch(error => {
            console.error(error);
            Swal.fire('Error', 'No se pudo guardar la mesa.', 'error');
        });
}

function cambiarActivoMesa(id, activo) {
    const accion = activo === 1 ? 'activar' : 'desactivar';

    Swal.fire({
        title: `¿Deseas ${accion} esta mesa?`,
        text: activo === 0
            ? 'Si la desactivas, dejará de aparecer en la operación.'
            : 'La mesa volverá a estar disponible en operación.',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Sí',
        cancelButtonText: 'Cancelar'
    }).then(result => {
        if (!result.isConfirmed) return;

        const formData = new FormData();
        formData.append('id', id);
        formData.append('activo', activo);

        fetch(`${BASE_URL}/mesasAdmin/activo`, {
            method: 'POST',
            body: formData
        })
            .then(r => r.json())
            .then(data => {
                Swal.fire(
                    data.success ? 'Listo' : 'Aviso',
                    data.message,
                    data.success ? 'success' : 'warning'
                );

                if (data.success) {
                    cargarMesasAdmin();
                }
            })
            .catch(error => {
                console.error(error);
                Swal.fire('Error', 'No se pudo actualizar la mesa.', 'error');
            });
    });
}

function badgeEstado(estado) {
    switch (estado) {
        case 'LIBRE':
            return 'bg-success';

        case 'OCUPADA':
            return 'bg-warning text-dark';

        case 'CUENTA_SOLICITADA':
            return 'bg-primary';

        case 'COBRADA':
            return 'bg-secondary';

        default:
            return 'bg-dark';
    }
}

function escaparHtml(texto) {
    const div = document.createElement('div');
    div.textContent = texto ?? '';
    return div.innerHTML;
}

function escaparAtributo(texto) {
    return String(texto ?? '')
        .replace(/\\/g, '\\\\')
        .replace(/'/g, "\\'")
        .replace(/"/g, '&quot;');
}