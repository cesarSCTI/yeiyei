document.addEventListener('DOMContentLoaded', function () {
    const fechaInput = document.getElementById('fechaCorte');

    if (fechaInput) {
        fechaInput.value = obtenerFechaHoy();
    }

    cargarResumenCorte();
    cargarHistorialCortes();
});

function obtenerFechaHoy() {
    const hoy = new Date();
    const year = hoy.getFullYear();
    const month = String(hoy.getMonth() + 1).padStart(2, '0');
    const day = String(hoy.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}`;
}

function cargarResumenCorte() {
    const fecha = document.getElementById('fechaCorte').value;

    fetch(`${BASE_URL}/cortes/resumen?fecha=${fecha}`)
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                Swal.fire('Aviso', data.message, 'warning');
                return;
            }

            renderResumen(data.resumen, data.corte_realizado);
        })
        .catch(error => {
            console.error(error);
            Swal.fire('Error', 'No se pudo cargar el corte.', 'error');
        });
}

function renderResumen(resumen, corteRealizado) {
    document.getElementById('resEfectivo').innerText = `$${formatoMoneda(resumen.efectivo)}`;
    document.getElementById('resTarjeta').innerText = `$${formatoMoneda(resumen.tarjeta)}`;
    document.getElementById('resTransferencia').innerText = `$${formatoMoneda(resumen.transferencia)}`;
    document.getElementById('resIngresos').innerText = `$${formatoMoneda(resumen.total_ingresos)}`;
    document.getElementById('resEgresos').innerText = `$${formatoMoneda(resumen.total_egresos)}`;
    document.getElementById('resFinal').innerText = `$${formatoMoneda(resumen.total_final)}`;

    const alerta = document.getElementById('alertaCorte');
    const btnGuardar = document.getElementById('btnGuardarCorte');

    if (corteRealizado) {
        alerta.innerHTML = `
            <div class="alert alert-warning">
                Ya existe un corte registrado para esta fecha.
            </div>
        `;
        btnGuardar.disabled = true;
    } else {
        alerta.innerHTML = '';
        btnGuardar.disabled = false;
    }
}

function guardarCorte() {
    const fecha = document.getElementById('fechaCorte').value;
    const observaciones = document.getElementById('observacionesCorte').value;

    Swal.fire({
        title: '¿Guardar corte?',
        text: 'Una vez guardado, no se podrá volver a guardar otro corte para esta fecha.',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Sí, guardar',
        cancelButtonText: 'Cancelar'
    }).then(result => {
        if (!result.isConfirmed) return;

        const formData = new FormData();
        formData.append('fecha', fecha);
        formData.append('observaciones', observaciones);

        fetch(`${BASE_URL}/cortes/guardar`, {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (!data.success) {
                    Swal.fire('Aviso', data.message, 'warning');
                    return;
                }

                Swal.fire({
                    icon: 'success',
                    title: 'Corte guardado',
                    text: data.message,
                    timer: 1400,
                    showConfirmButton: false
                });

                cargarResumenCorte();
                cargarHistorialCortes();
            })
            .catch(error => {
                console.error(error);
                Swal.fire('Error', 'No se pudo guardar el corte.', 'error');
            });
    });
}

function cargarHistorialCortes() {
    fetch(`${BASE_URL}/cortes/historial`)
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                document.getElementById('contenedorHistorial').innerHTML = `
                    <div class="alert alert-warning">${data.message}</div>
                `;
                return;
            }

            renderHistorial(data.data);
        })
        .catch(error => {
            console.error(error);

            document.getElementById('contenedorHistorial').innerHTML = `
                <div class="alert alert-danger">No se pudo cargar el historial.</div>
            `;
        });
}

function renderHistorial(cortes) {
    const contenedor = document.getElementById('contenedorHistorial');

    if (!cortes || cortes.length === 0) {
        contenedor.innerHTML = `
            <div class="alert alert-secondary">
                No hay cortes registrados.
            </div>
        `;
        return;
    }

    let html = `
        <div class="table-responsive">
            <table class="table table-sm table-hover align-middle">
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Usuario</th>
                        <th class="text-end">Efectivo</th>
                        <th class="text-end">Tarjeta</th>
                        <th class="text-end">Transferencia</th>
                        <th class="text-end">Ingresos</th>
                        <th class="text-end">Egresos</th>
                        <th class="text-end">Final</th>
                    </tr>
                </thead>
                <tbody>
    `;

    cortes.forEach(corte => {
        html += `
            <tr>
                <td>${corte.fecha}</td>
                <td>${escaparHtml(corte.usuario)}</td>
                <td class="text-end">$${formatoMoneda(corte.efectivo)}</td>
                <td class="text-end">$${formatoMoneda(corte.tarjeta)}</td>
                <td class="text-end">$${formatoMoneda(corte.transferencia)}</td>
                <td class="text-end">$${formatoMoneda(corte.total_ingresos)}</td>
                <td class="text-end">$${formatoMoneda(corte.total_egresos)}</td>
                <td class="text-end fw-bold">$${formatoMoneda(corte.total_final)}</td>
            </tr>
        `;
    });

    html += `
                </tbody>
            </table>
        </div>
    `;

    contenedor.innerHTML = html;
}

function formatoMoneda(valor) {
    return parseFloat(valor || 0).toFixed(2);
}

function escaparHtml(texto) {
    const div = document.createElement('div');
    div.textContent = texto ?? '';
    return div.innerHTML;
}