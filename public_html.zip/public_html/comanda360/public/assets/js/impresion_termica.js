(function () {
    'use strict';

    const PX_PER_MM = 96 / 25.4;
    const DEFAULT_PAPER_WIDTH_MM = 99;
    const DEFAULT_MIN_HEIGHT_MM = 100;
    const EXTRA_FEED_MM = 0;
    let printStarted = false;

    function getPositiveNumber(value, fallback) {
        const parsed = Number(value);
        return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
    }

    function getPaperWidth() {
        /* Máximo 99 mm para que una hoja corta no sea rotada automáticamente. */
        return Math.min(
            getPositiveNumber(document.body.dataset.paperWidth, DEFAULT_PAPER_WIDTH_MM),
            DEFAULT_PAPER_WIDTH_MM
        );
    }

    function getMinimumHeight() {
        /* La altura nunca debe ser menor al ancho. De esta manera Chrome conserva
           la lectura horizontal normal sobre el rollo y no gira el contenido 90°. */
        return Math.max(
            getPositiveNumber(document.body.dataset.minPaperHeight, DEFAULT_MIN_HEIGHT_MM),
            DEFAULT_MIN_HEIGHT_MM
        );
    }

    function calculatePageHeightMm() {
        const ticket = document.querySelector('.ticket-print');

        if (!ticket) {
            return getMinimumHeight();
        }

        const measuredPx = Math.max(
            ticket.scrollHeight,
            ticket.offsetHeight,
            ticket.getBoundingClientRect().height
        );

        const contentHeightMm = Math.ceil(measuredPx / PX_PER_MM) + EXTRA_FEED_MM;
        return Math.max(getMinimumHeight(), contentHeightMm);
    }

    function applyDynamicPageSize() {
        const paperWidth = getPaperWidth();
        const pageHeight = calculatePageHeightMm();
        let style = document.getElementById('dynamicPrintPageSize');

        if (!style) {
            style = document.createElement('style');
            style.id = 'dynamicPrintPageSize';
            document.head.appendChild(style);
        }

        style.textContent = `@page { size: ${paperWidth}mm ${pageHeight}mm; margin: 0; }`;
        document.documentElement.style.setProperty('--paper-width-mm', paperWidth);
    }

    function startPrint() {
        if (printStarted) return;

        printStarted = true;
        applyDynamicPageSize();

        window.setTimeout(function () {
            window.print();
        }, 250);
    }

    window.printThermalTicket = function () {
        printStarted = false;
        startPrint();
    };

    window.addEventListener('beforeprint', applyDynamicPageSize);

    window.addEventListener('afterprint', function () {
        window.setTimeout(function () {
            try {
                window.close();
            } catch (error) {
                console.warn('No fue posible cerrar automáticamente la ventana de impresión.', error);
            }
        }, 120);
    });

    window.addEventListener('load', function () {
        if (document.fonts && document.fonts.ready) {
            document.fonts.ready.then(startPrint).catch(startPrint);
        } else {
            startPrint();
        }
    });
}());
