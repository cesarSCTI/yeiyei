let productosGlobal = [];
let detallesPedidoActual = [];

document.addEventListener('DOMContentLoaded', function () {
    cargarProductos();
    cargarDetalle();

    const buscarProducto = document.getElementById('buscarProducto');

    if (buscarProducto) {
        buscarProducto.addEventListener('input', function () {
            renderizarProductos(this.value.trim().toLowerCase());
        });
    }

    if (window.location.hash === '#mover-mesa' && PEDIDO_ID > 0) {
        window.setTimeout(() => abrirMoverMesa(), 250);
    }
});

function cargarProductos() {
    fetch(`${BASE_URL}/pedidos/productos`)
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                mostrarErrorProductos(data.message);
                return;
            }

            productosGlobal = data.data;
            renderizarProductos('');
        })
        .catch(error => {
            console.error(error);
            mostrarErrorProductos('No se pudieron cargar los productos.');
        });
}

function renderizarProductos(filtro = '') {
    const contenedor = document.getElementById('contenedorProductos');

    let productos = productosGlobal;

    if (filtro !== '') {
        productos = productos.filter(p =>
            p.nombre.toLowerCase().includes(filtro) ||
            p.categoria.toLowerCase().includes(filtro)
        );
    }

    if (!productos || productos.length === 0) {
        contenedor.innerHTML = `
            <div class="col-12">
                <div class="alert alert-secondary">
                    No hay productos disponibles.
                </div>
            </div>
        `;
        return;
    }

    let html = '';

    productos.forEach(producto => {
        html += `
            <div class="col-12 col-sm-6 col-md-4 col-xl-3">
                <div class="card h-100 shadow-sm border-0">
                    <div class="card-body d-flex flex-column">
                        <span class="badge bg-secondary mb-2 align-self-start">
                            ${escaparHtml(producto.categoria)}
                        </span>

                        <h6 class="fw-bold">${escaparHtml(producto.nombre)}</h6>

                        <p class="text-muted small flex-grow-1">
                            ${producto.descripcion ? escaparHtml(producto.descripcion) : 'Sin descripción'}
                        </p>

                        <div class="d-flex justify-content-between align-items-center">
                            <strong>$${formatoMoneda(producto.precio)}</strong>

                            <button 
                                class="btn btn-success btn-sm"
                                onclick="agregarProducto(${producto.id}, '${escaparAtributo(producto.nombre)}', ${producto.precio})"
                            >
                                Agregar
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });

    contenedor.innerHTML = html;
}

function agregarProducto(productoId, nombre, precio) {
    Swal.fire({
        title: nombre,
        html: `
            <div class="text-start">
                <label class="form-label">Cantidad</label>
                <input id="swalCantidad" type="number" min="1" value="1" class="form-control mb-3">

                <label class="form-label">Notas</label>
                <textarea id="swalNotas" class="form-control mb-3" rows="3" placeholder="Ej. sin cebolla, término medio..."></textarea>

                <label class="form-label">Tipo de descuento</label>
                <select id="swalDescuentoTipo" class="form-select mb-3">
                    <option value="NINGUNO">Sin descuento</option>
                    <option value="PORCENTAJE">Porcentaje (%)</option>
                    <option value="MONTO">Monto fijo ($)</option>
                </select>

                <div id="contenedorDescuentoValor" class="d-none">
                    <label id="labelDescuentoValor" class="form-label">Valor del descuento</label>
                    <input id="swalDescuentoValor" type="number" min="0" step="0.01" value="0" class="form-control mb-3">
                </div>

                <div class="alert alert-light border mb-0">
                    <div class="d-flex justify-content-between">
                        <span>Subtotal:</span>
                        <strong id="previewSubtotal">$${formatoMoneda(precio)}</strong>
                    </div>
                    <div class="d-flex justify-content-between text-danger">
                        <span>Descuento:</span>
                        <strong id="previewDescuento">-$0.00</strong>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span>Total producto:</span>
                        <strong id="previewTotal">$${formatoMoneda(precio)}</strong>
                    </div>
                </div>
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: 'Agregar',
        cancelButtonText: 'Cancelar',
        didOpen: () => {
            const cantidadInput = document.getElementById('swalCantidad');
            const tipoInput = document.getElementById('swalDescuentoTipo');
            const valorInput = document.getElementById('swalDescuentoValor');

            const actualizar = () => actualizarPreviewDescuento(precio);

            cantidadInput.addEventListener('input', actualizar);
            tipoInput.addEventListener('change', () => {
                const contenedor = document.getElementById('contenedorDescuentoValor');
                const label = document.getElementById('labelDescuentoValor');

                if (tipoInput.value === 'NINGUNO') {
                    contenedor.classList.add('d-none');
                    valorInput.value = '0';
                } else {
                    contenedor.classList.remove('d-none');
                    label.textContent = tipoInput.value === 'PORCENTAJE'
                        ? 'Porcentaje de descuento'
                        : 'Monto fijo de descuento';
                }

                actualizar();
            });
            valorInput.addEventListener('input', actualizar);
            actualizar();
        },
        preConfirm: () => {
            const cantidad = parseInt(document.getElementById('swalCantidad').value || '1', 10);
            const notas = document.getElementById('swalNotas').value || '';
            const descuentoTipo = document.getElementById('swalDescuentoTipo').value;
            const descuentoValor = parseFloat(document.getElementById('swalDescuentoValor').value || 0);
            const subtotal = cantidad * parseFloat(precio);

            if (cantidad <= 0) {
                Swal.showValidationMessage('La cantidad debe ser mayor a cero.');
                return false;
            }

            if (descuentoValor < 0) {
                Swal.showValidationMessage('El descuento no puede ser negativo.');
                return false;
            }

            if (descuentoTipo === 'PORCENTAJE' && descuentoValor > 100) {
                Swal.showValidationMessage('El porcentaje no puede ser mayor a 100%.');
                return false;
            }

            if (descuentoTipo === 'MONTO' && descuentoValor > subtotal) {
                Swal.showValidationMessage('El descuento fijo no puede ser mayor al subtotal.');
                return false;
            }

            return {
                cantidad,
                notas,
                descuento_tipo: descuentoTipo,
                descuento_valor: descuentoTipo === 'NINGUNO' ? 0 : descuentoValor
            };
        }
    }).then(result => {
        if (!result.isConfirmed) return;

        const formData = new FormData();
        formData.append('pedido_id', PEDIDO_ID);
        formData.append('mesa_id', MESA_ID);
        formData.append('producto_id', productoId);
        formData.append('cantidad', result.value.cantidad);
        formData.append('notas', result.value.notas);
        formData.append('descuento_tipo', result.value.descuento_tipo);
        formData.append('descuento_valor', result.value.descuento_valor);

        fetch(`${BASE_URL}/pedidos/agregarProducto`, {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (!data.success) {
                    Swal.fire('Aviso', data.message, 'warning');
                    return;
                }

                if (data.pedido_id) {
                    PEDIDO_ID = parseInt(data.pedido_id, 10);

                    const etiquetaPedido = document.getElementById('etiquetaPedido');
                    if (etiquetaPedido) {
                        etiquetaPedido.textContent = `Pedido #${PEDIDO_ID}`;
                    }

                    const btnEnviar = document.getElementById('btnEnviarCocina');
                    if (btnEnviar) {
                        btnEnviar.disabled = false;
                    }

                    const btnCobrar = document.getElementById('btnCobrarPedido');
                    if (btnCobrar) {
                        btnCobrar.disabled = false;
                    }

                    // Mantiene la URL alineada con el pedido real sin recargar.
                    const nuevaUrl = `${BASE_URL}/pedidos/ver/${MESA_ID}`;
                    window.history.replaceState({}, '', nuevaUrl);
                }

                cargarDetalle();
            })
            .catch(error => {
                console.error(error);
                Swal.fire('Error', 'No se pudo agregar el producto.', 'error');
            });
    });
}

function actualizarPreviewDescuento(precio) {
    const cantidad = Math.max(parseInt(document.getElementById('swalCantidad')?.value || '1', 10), 1);
    const tipo = document.getElementById('swalDescuentoTipo')?.value || 'NINGUNO';
    const valor = Math.max(parseFloat(document.getElementById('swalDescuentoValor')?.value || 0), 0);
    const subtotal = cantidad * parseFloat(precio || 0);

    let descuento = 0;

    if (tipo === 'PORCENTAJE') {
        descuento = subtotal * Math.min(valor, 100) / 100;
    } else if (tipo === 'MONTO') {
        descuento = Math.min(valor, subtotal);
    }

    const total = Math.max(subtotal - descuento, 0);

    document.getElementById('previewSubtotal').textContent = `$${formatoMoneda(subtotal)}`;
    document.getElementById('previewDescuento').textContent = `-$${formatoMoneda(descuento)}`;
    document.getElementById('previewTotal').textContent = `$${formatoMoneda(total)}`;
}

function cargarDetalle() {
    if (PEDIDO_ID <= 0) {
        renderizarDetalle([]);
        return;
    }

    fetch(`${BASE_URL}/pedidos/detalle/${PEDIDO_ID}`)
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                document.getElementById('contenedorDetalle').innerHTML = `
                    <div class="alert alert-warning">${data.message}</div>
                `;
                return;
            }

            if (data.pedido_cerrado) {
                PEDIDO_ID = 0;
                renderizarDetalle([]);

                Swal.fire({
                    icon: 'info',
                    title: 'Mesa liberada',
                    text: data.message || 'El pedido ya no contiene productos activos.',
                    confirmButtonText: 'Volver a mesas'
                }).then(() => {
                    window.location.href = `${BASE_URL}/mesas`;
                });
                return;
            }

            renderizarDetalle(data.data);
        })
        .catch(error => {
            console.error(error);

            document.getElementById('contenedorDetalle').innerHTML = `
                <div class="alert alert-danger">
                    No se pudo cargar la comanda.
                </div>
            `;
        });
}

function renderizarDetalle(detalle) {
    detallesPedidoActual = Array.isArray(detalle) ? detalle : [];

    const contenedor = document.getElementById('contenedorDetalle');
    const totalPedido = document.getElementById('totalPedido');

    if (!detalle || detalle.length === 0) {
        contenedor.innerHTML = `
            <div class="alert alert-secondary">
                Aún no hay productos agregados.
            </div>
        `;
        totalPedido.innerText = '$0.00';

        const btnEnviar = document.getElementById('btnEnviarCocina');
        if (btnEnviar) btnEnviar.disabled = true;

        const btnCobrar = document.getElementById('btnCobrarPedido');
        if (btnCobrar) btnCobrar.disabled = true;

        return;
    }

    let html = '<div class="list-group">';
    let total = 0;

    detalle.forEach(item => {
        const cancelado = item.estado === 'CANCELADO';
        const subtotalOriginal = parseFloat(item.subtotal_original || item.subtotal || 0);
        const subtotalFinal = parseFloat(item.subtotal || 0);
        const descuentoImporte = parseFloat(item.descuento_importe || 0);

        if (!cancelado) {
            total += subtotalFinal;
        }

        let textoDescuento = '';
        if (item.descuento_tipo === 'PORCENTAJE' && descuentoImporte > 0) {
            textoDescuento = `${formatoMoneda(item.descuento_valor)}% (-$${formatoMoneda(descuentoImporte)})`;
        } else if (item.descuento_tipo === 'MONTO' && descuentoImporte > 0) {
            textoDescuento = `-$${formatoMoneda(descuentoImporte)}`;
        }

        html += `
            <div class="list-group-item ${cancelado ? 'opacity-50' : ''}">
                <div class="d-flex justify-content-between gap-2">
                    <strong>${item.cantidad} x ${escaparHtml(item.producto)}</strong>
                    <div class="text-end">
                        ${descuentoImporte > 0 ? `<div class="small text-muted text-decoration-line-through">$${formatoMoneda(subtotalOriginal)}</div>` : ''}
                        <span class="fw-bold">$${formatoMoneda(subtotalFinal)}</span>
                    </div>
                </div>

                ${descuentoImporte > 0 ? `
                    <div class="small text-success">
                        Descuento: ${textoDescuento}
                    </div>
                ` : ''}

                <div class="small text-muted">
                    Estado: ${item.estado}
                </div>

                ${item.notas ? `<div class="small text-primary">Nota: ${escaparHtml(item.notas)}</div>` : ''}

                ${!cancelado ? `
                    <div class="d-flex flex-wrap gap-2 mt-2">
                        <button
                            class="btn btn-outline-warning btn-sm"
                            onclick="abrirMoverProductos(${item.id})"
                        >
                            Mover producto
                        </button>

                        <button 
                            class="btn btn-outline-danger btn-sm"
                            onclick="solicitarCancelacion(${item.id}, '${escaparAtributo(item.producto)}')"
                        >
                            Solicitar cancelación
                        </button>
                    </div>
                ` : ''}
            </div>
        `;
    });

    html += '</div>';

    contenedor.innerHTML = html;
    totalPedido.innerText = `$${formatoMoneda(total)}`;
}

function enviarCocina() {
    if (PEDIDO_ID <= 0) {
        Swal.fire('Aviso', 'Agrega al menos un producto antes de enviar a cocina.', 'warning');
        return;
    }

    Swal.fire({
        title: '¿Enviar a cocina?',
        text: 'La comanda se enviará a cocina y se abrirá automáticamente para imprimir.',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Sí, enviar e imprimir',
        cancelButtonText: 'Cancelar',
        allowOutsideClick: false
    }).then(result => {
        if (!result.isConfirmed) return;

        // Abrimos la ventana dentro del clic del usuario para evitar
        // que el navegador la bloquee como ventana emergente.
        const ventanaImpresion = window.open('about:blank', 'comanda_impresion');

        if (ventanaImpresion) {
            ventanaImpresion.document.write(`
                <!doctype html>
                <html lang="es">
                <head><meta charset="utf-8"><title>Preparando comanda...</title></head>
                <body style="font-family:Arial,sans-serif;padding:20px;text-align:center;">
                    Preparando comanda...
                </body>
                </html>
            `);
            ventanaImpresion.document.close();
        }

        const formData = new FormData();
        formData.append('pedido_id', PEDIDO_ID);

        fetch(`${BASE_URL}/pedidos/enviarCocina`, {
            method: 'POST',
            body: formData,
            credentials: 'same-origin'
        })
            .then(async response => {
                const text = await response.text();
                let data;

                try {
                    data = JSON.parse(text);
                } catch (error) {
                    throw new Error(text || 'Respuesta inválida del servidor.');
                }

                if (!response.ok || !data.success) {
                    throw new Error(data.message || 'No se pudo enviar el pedido a cocina.');
                }

                return data;
            })
            .then(data => {
                const urlComanda = `${BASE_URL}/impresion/comanda/${PEDIDO_ID}?t=${Date.now()}`;

                if (ventanaImpresion && !ventanaImpresion.closed) {
                    ventanaImpresion.location.replace(urlComanda);
                } else {
                    // Respaldo en caso de que el navegador haya bloqueado la ventana.
                    window.location.href = urlComanda;
                    return;
                }

                Swal.fire({
                    icon: 'success',
                    title: 'Enviado',
                    text: data.message || 'Pedido enviado a cocina.',
                    timer: 1200,
                    showConfirmButton: false
                });
            })
            .catch(error => {
                console.error(error);

                if (ventanaImpresion && !ventanaImpresion.closed) {
                    ventanaImpresion.close();
                }

                Swal.fire({
                    icon: 'error',
                    title: 'No se pudo enviar',
                    text: error.message || 'No se pudo enviar a cocina.'
                });
            });
    });
}

function abrirMoverProductos(detalleInicialId = 0) {
    if (PEDIDO_ID <= 0 || !Array.isArray(detallesPedidoActual)) {
        Swal.fire('Aviso', 'No hay productos disponibles para mover.', 'warning');
        return;
    }

    const disponibles = detallesPedidoActual.filter(item => item.estado !== 'CANCELADO');

    if (disponibles.length === 0) {
        Swal.fire('Aviso', 'No hay productos disponibles para mover.', 'warning');
        return;
    }

    fetch(`${BASE_URL}/pedidos/mesasParaMoverProductos/${PEDIDO_ID}`, {
        credentials: 'same-origin'
    })
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                Swal.fire('Aviso', data.message, 'warning');
                return;
            }

            if (!data.data || data.data.length === 0) {
                Swal.fire('Sin mesas destino', 'No hay otra mesa libre u ocupada disponible.', 'info');
                return;
            }

            const opcionesMesas = data.data.map(mesa => {
                const estado = mesa.estado === 'LIBRE'
                    ? 'Libre'
                    : `Ocupada · Pedido #${mesa.pedido_activo_id}`;

                return `
                    <option value="${mesa.id}">
                        ${escaparHtml(mesa.nombre)} — ${estado}
                    </option>
                `;
            }).join('');

            const filas = disponibles.map(item => {
                const seleccionado = parseInt(item.id, 10) === parseInt(detalleInicialId, 10);
                return `
                    <div class="border rounded p-2 mb-2 text-start">
                        <div class="form-check">
                            <input
                                class="form-check-input mover-producto-check"
                                type="checkbox"
                                value="${item.id}"
                                id="moverDetalle${item.id}"
                                ${seleccionado ? 'checked' : ''}
                            >
                            <label class="form-check-label w-100" for="moverDetalle${item.id}">
                                <div class="d-flex justify-content-between gap-2">
                                    <strong>${escaparHtml(item.producto)}</strong>
                                    <span>$${formatoMoneda(item.subtotal)}</span>
                                </div>
                                ${item.notas ? `<div class="small text-primary">Nota: ${escaparHtml(item.notas)}</div>` : ''}
                                <div class="small text-muted">Disponible: ${item.cantidad} · Estado: ${item.estado}</div>
                            </label>
                        </div>
                        <div class="mt-2 ps-4">
                            <label class="form-label small mb-1">Cantidad a mover</label>
                            <input
                                type="number"
                                class="form-control form-control-sm mover-producto-cantidad"
                                data-detalle-id="${item.id}"
                                min="1"
                                max="${item.cantidad}"
                                value="${seleccionado ? item.cantidad : 1}"
                            >
                        </div>
                    </div>
                `;
            }).join('');

            Swal.fire({
                title: 'Mover productos a otra mesa',
                html: `
                    <div class="text-start">
                        <div class="alert alert-light border py-2">
                            Pedido #${PEDIDO_ID} · Mesa actual: <strong>${escaparHtml(data.mesa_origen)}</strong>
                        </div>

                        <label class="form-label">Mesa destino</label>
                        <select id="mesaDestinoProductos" class="form-select mb-3">
                            <option value="">Selecciona una mesa</option>
                            ${opcionesMesas}
                        </select>

                        <label class="form-label">Productos y cantidades</label>
                        <div style="max-height:340px;overflow:auto;">${filas}</div>

                        <div class="small text-muted mt-2">
                            Puedes mover una parte de una cantidad o seleccionar varios productos.
                            La cuenta y los totales de ambas mesas se recalcularán automáticamente.
                        </div>
                    </div>
                `,
                width: 700,
                showCancelButton: true,
                confirmButtonText: 'Mover productos',
                cancelButtonText: 'Cancelar',
                allowOutsideClick: false,
                preConfirm: () => {
                    const mesaDestinoId = parseInt(document.getElementById('mesaDestinoProductos').value || '0', 10);

                    if (mesaDestinoId <= 0) {
                        Swal.showValidationMessage('Selecciona la mesa destino.');
                        return false;
                    }

                    const seleccionados = Array.from(document.querySelectorAll('.mover-producto-check:checked'));

                    if (seleccionados.length === 0) {
                        Swal.showValidationMessage('Selecciona al menos un producto.');
                        return false;
                    }

                    const movimientos = [];

                    for (const check of seleccionados) {
                        const detalleId = parseInt(check.value, 10);
                        const item = disponibles.find(x => parseInt(x.id, 10) === detalleId);
                        const input = document.querySelector(`.mover-producto-cantidad[data-detalle-id="${detalleId}"]`);
                        const cantidad = parseInt(input?.value || '0', 10);

                        if (!item || cantidad <= 0 || cantidad > parseInt(item.cantidad, 10)) {
                            Swal.showValidationMessage(`Revisa la cantidad de ${item ? item.producto : 'un producto'}.`);
                            return false;
                        }

                        movimientos.push({ detalle_id: detalleId, cantidad });
                    }

                    return { mesaDestinoId, movimientos };
                }
            }).then(result => {
                if (!result.isConfirmed) return;
                confirmarMoverProductos(result.value.mesaDestinoId, result.value.movimientos);
            });
        })
        .catch(error => {
            console.error(error);
            Swal.fire('Error', 'No se pudieron consultar las mesas destino.', 'error');
        });
}

function confirmarMoverProductos(mesaDestinoId, movimientos) {
    const formData = new FormData();
    formData.append('pedido_id', PEDIDO_ID);
    formData.append('mesa_destino_id', mesaDestinoId);
    formData.append('movimientos', JSON.stringify(movimientos));

    Swal.fire({
        title: 'Moviendo productos...',
        text: 'Espera un momento.',
        allowOutsideClick: false,
        didOpen: () => Swal.showLoading()
    });

    fetch(`${BASE_URL}/pedidos/moverProductos`, {
        method: 'POST',
        body: formData,
        credentials: 'same-origin'
    })
        .then(async response => {
            const text = await response.text();
            let data;

            try {
                data = JSON.parse(text);
            } catch (error) {
                throw new Error(text || 'Respuesta inválida del servidor.');
            }

            if (!response.ok || !data.success) {
                throw new Error(data.message || 'No se pudieron mover los productos.');
            }

            return data;
        })
        .then(data => {
            Swal.fire({
                icon: 'success',
                title: 'Productos movidos',
                text: data.message,
                timer: 1400,
                showConfirmButton: false
            }).then(() => {
                if (data.data && data.data.pedido_origen_vacio) {
                    window.location.href = `${BASE_URL}/mesas`;
                    return;
                }

                cargarDetalle();
            });
        })
        .catch(error => {
            console.error(error);
            Swal.fire('No se pudo mover', error.message, 'warning');
        });
}

function abrirMoverMesa() {
    if (PEDIDO_ID <= 0) {
        Swal.fire('Aviso', 'Primero agrega un producto para crear el pedido.', 'warning');
        return;
    }

    fetch(`${BASE_URL}/pedidos/mesasDisponibles/${PEDIDO_ID}`, {
        credentials: 'same-origin'
    })
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                Swal.fire('Aviso', data.message, 'warning');
                return;
            }

            if (!data.data || data.data.length === 0) {
                Swal.fire(
                    'Sin mesas disponibles',
                    'No existe otra mesa libre para mover este pedido.',
                    'info'
                );
                return;
            }

            const opciones = data.data.map(mesa => `
                <option value="${mesa.id}">
                    ${escaparHtml(mesa.nombre)}${mesa.descripcion ? ` — ${escaparHtml(mesa.descripcion)}` : ''}
                </option>
            `).join('');

            Swal.fire({
                title: 'Mover pedido',
                html: `
                    <div class="text-start">
                        <div class="alert alert-light border">
                            Pedido #${PEDIDO_ID}<br>
                            Mesa actual: <strong>${escaparHtml(data.mesa_origen)}</strong>
                        </div>

                        <label class="form-label">Mesa destino</label>
                        <select id="mesaDestinoMovimiento" class="form-select">
                            <option value="">Selecciona una mesa libre</option>
                            ${opciones}
                        </select>

                        <div class="small text-muted mt-3">
                            Se moverá la cuenta completa con todos sus productos, notas,
                            descuentos y estados. La mesa actual quedará libre.
                        </div>
                    </div>
                `,
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Mover pedido',
                cancelButtonText: 'Cancelar',
                allowOutsideClick: false,
                preConfirm: () => {
                    const mesaDestinoId = parseInt(
                        document.getElementById('mesaDestinoMovimiento').value || '0',
                        10
                    );

                    if (mesaDestinoId <= 0) {
                        Swal.showValidationMessage('Selecciona la mesa destino.');
                        return false;
                    }

                    return mesaDestinoId;
                }
            }).then(result => {
                if (!result.isConfirmed) return;
                confirmarMoverMesa(result.value);
            });
        })
        .catch(error => {
            console.error(error);
            Swal.fire('Error', 'No se pudieron consultar las mesas disponibles.', 'error');
        });
}

function confirmarMoverMesa(mesaDestinoId) {
    const formData = new FormData();
    formData.append('pedido_id', PEDIDO_ID);
    formData.append('mesa_destino_id', mesaDestinoId);

    Swal.fire({
        title: 'Moviendo pedido...',
        text: 'Espera un momento.',
        allowOutsideClick: false,
        didOpen: () => Swal.showLoading()
    });

    fetch(`${BASE_URL}/pedidos/moverMesa`, {
        method: 'POST',
        body: formData,
        credentials: 'same-origin'
    })
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                Swal.fire('No se pudo mover', data.message, 'warning');
                return;
            }

            Swal.fire({
                icon: 'success',
                title: 'Pedido movido',
                text: data.message,
                timer: 1300,
                showConfirmButton: false
            }).then(() => {
                window.location.href = data.redirect || `${BASE_URL}/mesas`;
            });
        })
        .catch(error => {
            console.error(error);
            Swal.fire('Error', 'No se pudo mover el pedido.', 'error');
        });
}

function mostrarErrorProductos(message) {
    document.getElementById('contenedorProductos').innerHTML = `
        <div class="col-12">
            <div class="alert alert-danger">${message}</div>
        </div>
    `;
}


function abrirCobroDesdePedido() {
    if (PEDIDO_ID <= 0) {
        Swal.fire('Aviso', 'Agrega al menos un producto antes de realizar el pago.', 'warning');
        return;
    }

    const btnCobrar = document.getElementById('btnCobrarPedido');
    if (btnCobrar) btnCobrar.disabled = true;

    fetch(`${BASE_URL}/caja/ver/${PEDIDO_ID}`, {
        credentials: 'same-origin'
    })
        .then(async response => {
            const text = await response.text();
            let data;

            try {
                data = JSON.parse(text);
            } catch (error) {
                throw new Error(text || 'Respuesta inválida del servidor.');
            }

            if (!response.ok || !data.success) {
                throw new Error(data.message || 'No se pudo cargar el pedido.');
            }

            return data;
        })
        .then(data => {
            const detalleValido = Array.isArray(data.detalle)
                ? data.detalle.filter(item => item.estado !== 'CANCELADO')
                : [];

            if (detalleValido.length === 0) {
                Swal.fire('Aviso', 'Este pedido no tiene productos para cobrar.', 'warning');
                return;
            }

            mostrarModalCobroPedido(data.pedido, detalleValido);
        })
        .catch(error => {
            console.error(error);
            Swal.fire('Error', error.message || 'No se pudo cargar el pedido.', 'error');
        })
        .finally(() => {
            if (btnCobrar) btnCobrar.disabled = false;
        });
}

function mostrarModalCobroPedido(pedido, detalle) {
    let htmlDetalle = '<div class="text-start mb-3" style="max-height:220px;overflow:auto;">';

    detalle.forEach(item => {
        const subtotalOriginal = parseFloat(item.subtotal_original || item.subtotal || 0);
        const subtotalFinal = parseFloat(item.subtotal || 0);
        const descuento = parseFloat(item.descuento_importe || 0);

        htmlDetalle += `
            <div class="border-bottom py-2">
                <div class="d-flex justify-content-between gap-2">
                    <div>
                        <strong>${item.cantidad} x ${escaparHtml(item.producto)}</strong>
                        ${item.notas ? `<div class="small text-muted">Nota: ${escaparHtml(item.notas)}</div>` : ''}
                    </div>
                    <div class="text-end text-nowrap">
                        ${descuento > 0 ? `<div class="small text-muted text-decoration-line-through">$${formatoMoneda(subtotalOriginal)}</div>` : ''}
                        <strong>$${formatoMoneda(subtotalFinal)}</strong>
                    </div>
                </div>
                ${descuento > 0 ? `<div class="small text-success">Descuento producto: -$${formatoMoneda(descuento)}</div>` : ''}
            </div>
        `;
    });

    htmlDetalle += '</div>';
    const subtotal = parseFloat(pedido.total || 0);

    Swal.fire({
        title: `${escaparHtml(pedido.mesa)} | Pedido #${pedido.id}`,
        html: `
            ${htmlDetalle}

            <div class="text-start">
                <div class="border rounded p-3 mb-3 bg-light">
                    <label class="form-label fw-bold">Descuento al total</label>
                    <select id="descuentoTipoPedido" class="form-select mb-2">
                        <option value="NINGUNO">Sin descuento</option>
                        <option value="PORCENTAJE">Porcentaje (%)</option>
                        <option value="MONTO">Monto fijo ($)</option>
                    </select>
                    <label class="form-label">Valor del descuento</label>
                    <input id="descuentoValorPedido" type="number" min="0" step="0.01" class="form-control" value="0" disabled>
                </div>

                <label class="form-label">Método de pago</label>
                <select id="metodoPagoPedido" class="form-select mb-3">
                    <option value="EFECTIVO">Efectivo</option>
                    <option value="TARJETA">Tarjeta</option>
                    <option value="TRANSFERENCIA">Transferencia</option>
                    <option value="MIXTO">Mixto</option>
                </select>

                <div class="row g-2">
                    <div class="col-12">
                        <label class="form-label">Efectivo</label>
                        <input id="pagoEfectivoPedido" type="number" min="0" step="0.01" class="form-control" value="${subtotal.toFixed(2)}">
                    </div>
                    <div class="col-6">
                        <label class="form-label">Tarjeta</label>
                        <input id="pagoTarjetaPedido" type="number" min="0" step="0.01" class="form-control" value="0">
                    </div>
                    <div class="col-6">
                        <label class="form-label">Transferencia</label>
                        <input id="pagoTransferenciaPedido" type="number" min="0" step="0.01" class="form-control" value="0">
                    </div>
                </div>

                <div class="alert alert-light border mt-3 mb-0">
                    <div class="d-flex justify-content-between">
                        <span>Subtotal:</span>
                        <span>$${formatoMoneda(subtotal)}</span>
                    </div>
                    <div class="d-flex justify-content-between text-success">
                        <span>Descuento:</span>
                        <span id="descuentoImportePedido">-$0.00</span>
                    </div>
                    <div class="d-flex justify-content-between border-top pt-2 mt-2">
                        <strong>Total a cobrar:</strong>
                        <strong id="totalCobrarPedido">$${formatoMoneda(subtotal)}</strong>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span>Pagado:</span>
                        <span id="totalPagadoPedido">$${formatoMoneda(subtotal)}</span>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span>Cambio:</span>
                        <strong id="cambioPagoPedido">$0.00</strong>
                    </div>
                </div>
            </div>
        `,
        width: 650,
        showCancelButton: true,
        confirmButtonText: 'Confirmar pago',
        cancelButtonText: 'Cancelar',
        allowOutsideClick: false,
        didOpen: () => {
            const descuentoTipo = document.getElementById('descuentoTipoPedido');
            const descuentoValor = document.getElementById('descuentoValorPedido');
            const metodo = document.getElementById('metodoPagoPedido');
            const inputs = [
                document.getElementById('pagoEfectivoPedido'),
                document.getElementById('pagoTarjetaPedido'),
                document.getElementById('pagoTransferenciaPedido')
            ];

            descuentoTipo.addEventListener('change', () => {
                descuentoValor.disabled = descuentoTipo.value === 'NINGUNO';
                if (descuentoTipo.value === 'NINGUNO') descuentoValor.value = '0';
                ajustarMetodoPagoPedido(subtotal);
            });
            descuentoValor.addEventListener('input', () => ajustarMetodoPagoPedido(subtotal));
            metodo.addEventListener('change', () => ajustarMetodoPagoPedido(subtotal));
            inputs.forEach(input => input.addEventListener('input', () => calcularPagoPedido(subtotal)));
            ajustarMetodoPagoPedido(subtotal);
        },
        preConfirm: () => {
            const metodo = document.getElementById('metodoPagoPedido').value;
            const descuentoTipo = document.getElementById('descuentoTipoPedido').value;
            const descuentoValor = Math.max(parseFloat(document.getElementById('descuentoValorPedido').value || 0), 0);
            const calculo = calcularDescuentoCobroPedido(subtotal, descuentoTipo, descuentoValor);

            if (!calculo.valido) {
                Swal.showValidationMessage(calculo.mensaje);
                return false;
            }

            const efectivo = Math.max(parseFloat(document.getElementById('pagoEfectivoPedido').value || 0), 0);
            const tarjeta = Math.max(parseFloat(document.getElementById('pagoTarjetaPedido').value || 0), 0);
            const transferencia = Math.max(parseFloat(document.getElementById('pagoTransferenciaPedido').value || 0), 0);
            const pagado = efectivo + tarjeta + transferencia;

            if (pagado < calculo.total) {
                Swal.showValidationMessage(`Faltan $${formatoMoneda(calculo.total - pagado)} para completar el pago.`);
                return false;
            }

            if (metodo !== 'EFECTIVO' && Math.abs(pagado - calculo.total) > 0.009) {
                Swal.showValidationMessage('El importe pagado debe coincidir exactamente con el total a cobrar.');
                return false;
            }

            return {
                metodo,
                efectivo,
                tarjeta,
                transferencia,
                cambio: metodo === 'EFECTIVO' ? Math.max(pagado - calculo.total, 0) : 0,
                descuento_tipo: descuentoTipo,
                descuento_valor: descuentoValor
            };
        }
    }).then(result => {
        if (!result.isConfirmed) return;
        registrarCobroDesdePedido(pedido.id, result.value);
    });
}

function calcularDescuentoCobroPedido(subtotal, tipo, valor) {
    subtotal = Math.max(parseFloat(subtotal || 0), 0);
    valor = Math.max(parseFloat(valor || 0), 0);
    let importe = 0;

    if (tipo === 'PORCENTAJE') {
        if (valor > 100) return { valido: false, mensaje: 'El porcentaje no puede ser mayor a 100%.', importe: 0, total: subtotal };
        importe = subtotal * (valor / 100);
    } else if (tipo === 'MONTO') {
        if (valor > subtotal) return { valido: false, mensaje: 'El descuento no puede ser mayor al subtotal.', importe: 0, total: subtotal };
        importe = valor;
    }

    importe = Math.round(importe * 100) / 100;
    return {
        valido: true,
        mensaje: '',
        importe,
        total: Math.round(Math.max(subtotal - importe, 0) * 100) / 100
    };
}

function ajustarMetodoPagoPedido(subtotal) {
    const metodo = document.getElementById('metodoPagoPedido')?.value || 'EFECTIVO';
    const efectivo = document.getElementById('pagoEfectivoPedido');
    const tarjeta = document.getElementById('pagoTarjetaPedido');
    const transferencia = document.getElementById('pagoTransferenciaPedido');
    if (!efectivo || !tarjeta || !transferencia) return;

    const tipo = document.getElementById('descuentoTipoPedido')?.value || 'NINGUNO';
    const valor = parseFloat(document.getElementById('descuentoValorPedido')?.value || 0);
    const calculo = calcularDescuentoCobroPedido(subtotal, tipo, valor);
    const total = calculo.valido ? calculo.total : subtotal;

    efectivo.disabled = metodo === 'TARJETA' || metodo === 'TRANSFERENCIA';
    tarjeta.disabled = metodo === 'EFECTIVO' || metodo === 'TRANSFERENCIA';
    transferencia.disabled = metodo === 'EFECTIVO' || metodo === 'TARJETA';

    if (metodo === 'EFECTIVO') {
        efectivo.value = total.toFixed(2);
        tarjeta.value = '0';
        transferencia.value = '0';
    } else if (metodo === 'TARJETA') {
        efectivo.value = '0';
        tarjeta.value = total.toFixed(2);
        transferencia.value = '0';
    } else if (metodo === 'TRANSFERENCIA') {
        efectivo.value = '0';
        tarjeta.value = '0';
        transferencia.value = total.toFixed(2);
    } else {
        efectivo.disabled = false;
        tarjeta.disabled = false;
        transferencia.disabled = false;
        efectivo.value = '0';
        tarjeta.value = '0';
        transferencia.value = '0';
    }

    calcularPagoPedido(subtotal);
}

function calcularPagoPedido(subtotal) {
    const tipo = document.getElementById('descuentoTipoPedido')?.value || 'NINGUNO';
    const valor = parseFloat(document.getElementById('descuentoValorPedido')?.value || 0);
    const calculo = calcularDescuentoCobroPedido(subtotal, tipo, valor);
    const total = calculo.valido ? calculo.total : subtotal;

    const efectivo = Math.max(parseFloat(document.getElementById('pagoEfectivoPedido')?.value || 0), 0);
    const tarjeta = Math.max(parseFloat(document.getElementById('pagoTarjetaPedido')?.value || 0), 0);
    const transferencia = Math.max(parseFloat(document.getElementById('pagoTransferenciaPedido')?.value || 0), 0);
    const pagado = efectivo + tarjeta + transferencia;
    const cambio = Math.max(pagado - total, 0);

    const descuentoImporte = document.getElementById('descuentoImportePedido');
    const totalCobrar = document.getElementById('totalCobrarPedido');
    const totalPagado = document.getElementById('totalPagadoPedido');
    const cambioPago = document.getElementById('cambioPagoPedido');

    if (descuentoImporte) descuentoImporte.textContent = `-$${formatoMoneda(calculo.valido ? calculo.importe : 0)}`;
    if (totalCobrar) totalCobrar.textContent = `$${formatoMoneda(total)}`;
    if (totalPagado) totalPagado.textContent = `$${formatoMoneda(pagado)}`;
    if (cambioPago) cambioPago.textContent = `$${formatoMoneda(cambio)}`;
}

function registrarCobroDesdePedido(pedidoId, pago) {
    Swal.fire({
        title: 'Registrando pago...',
        allowOutsideClick: false,
        didOpen: () => Swal.showLoading()
    });

    const formData = new FormData();
    formData.append('pedido_id', pedidoId);
    formData.append('metodo_pago', pago.metodo);
    formData.append('efectivo', pago.efectivo);
    formData.append('tarjeta', pago.tarjeta);
    formData.append('transferencia', pago.transferencia);
    formData.append('cambio', pago.cambio);
    formData.append('descuento_tipo', pago.descuento_tipo || 'NINGUNO');
    formData.append('descuento_valor', pago.descuento_valor || 0);

    fetch(`${BASE_URL}/caja/cobrar`, {
        method: 'POST',
        body: formData,
        credentials: 'same-origin'
    })
        .then(async response => {
            const text = await response.text();
            let data;

            try {
                data = JSON.parse(text);
            } catch (error) {
                throw new Error(text || 'Respuesta inválida del servidor.');
            }

            if (!response.ok || !data.success) {
                throw new Error(data.message || 'No se pudo registrar el pago.');
            }

            return data;
        })
        .then(data => {
            Swal.fire({
                icon: 'success',
                title: 'Pago registrado',
                text: 'La mesa quedó libre. ¿Deseas imprimir el ticket?',
                showCancelButton: true,
                confirmButtonText: 'Imprimir ticket',
                cancelButtonText: 'Finalizar',
                allowOutsideClick: false
            }).then(result => {
                if (result.isConfirmed) {
                    window.open(`${BASE_URL}/impresion/ticket/${pedidoId}`, '_blank');
                }

                window.location.href = `${BASE_URL}/mesas`;
            });
        })
        .catch(error => {
            console.error(error);
            Swal.fire('Error', error.message || 'No se pudo registrar el pago.', 'error');
        });
}

function formatoMoneda(valor) {
    return parseFloat(valor || 0).toFixed(2);
}

function escaparHtml(texto) {
    const div = document.createElement('div');
    div.textContent = texto;
    return div.innerHTML;
}

function escaparAtributo(texto) {
    return String(texto)
        .replace(/\\/g, '\\\\')
        .replace(/'/g, "\\'")
        .replace(/"/g, '&quot;');
}

function solicitarCancelacion(detalleId, producto) {
    if (PEDIDO_ID <= 0) {
        Swal.fire('Aviso', 'No existe un pedido activo.', 'warning');
        return;
    }

    Swal.fire({
        title: 'Solicitar cancelación',
        html: `
            <div class="text-start">
                <p class="mb-2">
                    Producto: <strong>${escaparHtml(producto)}</strong>
                </p>

                <label class="form-label">Motivo</label>
                <textarea 
                    id="motivoCancelacion" 
                    class="form-control" 
                    rows="3" 
                    placeholder="Ej. Cliente cambió el pedido"
                ></textarea>
            </div>
        `,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Solicitar',
        cancelButtonText: 'Cancelar',
        preConfirm: () => {
            const motivo = document.getElementById('motivoCancelacion').value.trim();

            if (motivo === '') {
                Swal.showValidationMessage('Captura el motivo de cancelación.');
                return false;
            }

            return motivo;
        }
    }).then(result => {
        if (!result.isConfirmed) return;

        const formData = new FormData();
        formData.append('pedido_id', PEDIDO_ID);
        formData.append('detalle_id', detalleId);
        formData.append('motivo', result.value);

        fetch(`${BASE_URL}/cancelaciones/solicitar`, {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (!data.success) {
                    Swal.fire('Aviso', data.message, 'warning');
                    return;
                }

                if (data.whatsapp_url) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Solicitud registrada',
                        text: 'Se abrirá WhatsApp para enviar la alerta.',
                        confirmButtonText: 'Abrir WhatsApp'
                    }).then(() => {
                        window.open(data.whatsapp_url, '_blank');
                    });
                } else {
                    Swal.fire({
                        icon: 'success',
                        title: 'Solicitud registrada',
                        text: 'No hay teléfono de administrador configurado.'
                    });
                }

                cargarDetalle();
            })
            .catch(error => {
                console.error(error);
                Swal.fire('Error', 'No se pudo solicitar la cancelación.', 'error');
            });
    });
}