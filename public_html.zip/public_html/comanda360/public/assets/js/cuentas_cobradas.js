let cuentasCobradasGlobal = [];

document.addEventListener('DOMContentLoaded', function () {
    const fecha = document.getElementById('fechaCuentas');
    fecha.value = fechaLocalHoy();
    fecha.addEventListener('change', cargarCuentas);

    document.getElementById('buscarCuenta').addEventListener('input', aplicarFiltro);
    cargarCuentas();
});

function fechaLocalHoy() {
    const hoy = new Date();
    const y = hoy.getFullYear();
    const m = String(hoy.getMonth() + 1).padStart(2, '0');
    const d = String(hoy.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
}

function cargarCuentas() {
    const fecha = document.getElementById('fechaCuentas').value;
    const contenedor = document.getElementById('contenedorCuentas');

    contenedor.innerHTML = '<div class="alert alert-info">Cargando cuentas cobradas...</div>';

    fetch(`${BASE_URL}/cuentasCobradas/listar?fecha=${encodeURIComponent(fecha)}`)
        .then(validarRespuesta)
        .then(data => {
            if (!data.success) throw new Error(data.message || 'No se pudieron cargar las cuentas.');
            cuentasCobradasGlobal = Array.isArray(data.data) ? data.data : [];
            actualizarResumen(cuentasCobradasGlobal);
            aplicarFiltro();
        })
        .catch(error => {
            console.error(error);
            contenedor.innerHTML = `<div class="alert alert-danger">${escaparHtml(error.message)}</div>`;
        });
}

function aplicarFiltro() {
    const texto = (document.getElementById('buscarCuenta').value || '').trim().toLowerCase();

    const filtradas = cuentasCobradasGlobal.filter(cuenta => {
        if (!texto) return true;
        return String(cuenta.mesa || '').toLowerCase().includes(texto)
            || String(cuenta.pedido_id || '').includes(texto)
            || String(cuenta.pago_id || '').includes(texto)
            || String(cuenta.usuario_caja || '').toLowerCase().includes(texto);
    });

    renderCuentas(filtradas);
}

function actualizarResumen(cuentas) {
    let efectivo = 0;
    let tarjeta = 0;
    let transferencia = 0;
    let total = 0;

    cuentas.forEach(c => {
        efectivo += Math.max(numero(c.efectivo) - numero(c.cambio), 0);
        tarjeta += numero(c.tarjeta);
        transferencia += numero(c.transferencia);
        total += numero(c.total);
    });

    document.getElementById('resCantidad').textContent = cuentas.length;
    document.getElementById('resEfectivo').textContent = `$${moneda(efectivo)}`;
    document.getElementById('resElectronico').textContent = `$${moneda(tarjeta + transferencia)}`;
    document.getElementById('resTotal').textContent = `$${moneda(total)}`;
}

function renderCuentas(cuentas) {
    const contenedor = document.getElementById('contenedorCuentas');

    if (!cuentas.length) {
        contenedor.innerHTML = '<div class="alert alert-secondary">No se encontraron cuentas cobradas para los filtros seleccionados.</div>';
        return;
    }

    let html = `
        <div class="card shadow-sm border-0">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Hora</th>
                                <th>Mesa / Pedido</th>
                                <th>Cobró</th>
                                <th>Método</th>
                                <th class="text-end">Efectivo</th>
                                <th class="text-end">Tarjeta</th>
                                <th class="text-end">Transferencia</th>
                                <th class="text-end">Total</th>
                                <th class="text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>`;

    cuentas.forEach(c => {
        const cambios = parseInt(c.cambios_realizados || 0, 10);
        html += `
            <tr>
                <td>${hora(c.created_at)}</td>
                <td>
                    <strong>${escaparHtml(c.mesa)}</strong>
                    <div class="small text-muted">Pedido #${c.pedido_id} · Pago #${c.pago_id}</div>
                </td>
                <td>${escaparHtml(c.usuario_caja)}</td>
                <td>
                    <span class="badge bg-dark">${escaparHtml(etiquetaMetodo(c.metodo_pago))}</span>
                    ${cambios > 0 ? `<span class="badge bg-warning text-dark">${cambios} cambio(s)</span>` : ''}
                </td>
                <td class="text-end">$${moneda(Math.max(numero(c.efectivo) - numero(c.cambio), 0))}</td>
                <td class="text-end">$${moneda(c.tarjeta)}</td>
                <td class="text-end">$${moneda(c.transferencia)}</td>
                <td class="text-end fw-bold">$${moneda(c.total)}</td>
                <td class="text-center">
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-dark" onclick="verDetalle(${c.pago_id})">Detalle</button>
                        <button class="btn btn-primary" onclick="editarMetodo(${c.pago_id})">Cambiar pago</button>
                    </div>
                </td>
            </tr>`;
    });

    html += '</tbody></table></div></div></div>';
    contenedor.innerHTML = html;
}

function verDetalle(pagoId) {
    cargarDetalle(pagoId).then(data => {
        if (!data) return;

        const pago = data.pago;
        let productos = '';
        data.detalle.forEach(item => {
            productos += `
                <div class="d-flex justify-content-between border-bottom py-2 gap-2">
                    <div>
                        <strong>${item.cantidad} x ${escaparHtml(item.producto)}</strong>
                        ${item.notas ? `<div class="small text-muted">Nota: ${escaparHtml(item.notas)}</div>` : ''}
                    </div>
                    <strong>$${moneda(item.subtotal)}</strong>
                </div>`;
        });

        let historial = '<div class="alert alert-secondary py-2 mb-0">Sin modificaciones de pago.</div>';
        if (data.cambios.length) {
            historial = data.cambios.map(c => `
                <div class="border rounded p-2 mb-2 text-start">
                    <div><strong>${escaparHtml(c.metodo_anterior)}</strong> → <strong>${escaparHtml(c.metodo_nuevo)}</strong></div>
                    <div class="small">Modificó: ${escaparHtml(c.usuario_modifica)}</div>
                    <div class="small">Motivo: ${escaparHtml(c.motivo)}</div>
                    <div class="small text-muted">${escaparHtml(c.created_at)}</div>
                </div>`).join('');
        }

        Swal.fire({
            title: `${pago.mesa} | Pedido #${pago.pedido_id}`,
            html: `
                <div class="text-start">
                    <div class="mb-3">${productos}</div>
                    <div class="border rounded p-3 bg-light mb-3">
                        <div class="d-flex justify-content-between"><span>Método:</span><strong>${etiquetaMetodo(pago.metodo_pago)}</strong></div>
                        <div class="d-flex justify-content-between"><span>Subtotal:</span><span>$${moneda(pago.subtotal)}</span></div>
                        <div class="d-flex justify-content-between"><span>Descuento:</span><span>-$${moneda(pago.descuento_importe)}</span></div>
                        <div class="d-flex justify-content-between border-top pt-2 mt-2"><strong>Total:</strong><strong>$${moneda(pago.total)}</strong></div>
                    </div>
                    <h6>Historial de cambios</h6>
                    ${historial}
                </div>`,
            width: 700,
            confirmButtonText: 'Cerrar'
        });
    });
}

function editarMetodo(pagoId) {
    cargarDetalle(pagoId).then(data => {
        if (!data) return;
        const pago = data.pago;
        const total = numero(pago.total);

        Swal.fire({
            title: `Cambiar método de pago`,
            html: `
                <div class="text-start">
                    <div class="alert alert-light border">
                        <div><strong>${escaparHtml(pago.mesa)}</strong> · Pedido #${pago.pedido_id}</div>
                        <div class="d-flex justify-content-between"><span>Total cobrado:</span><strong>$${moneda(total)}</strong></div>
                    </div>

                    <label class="form-label">Nuevo método</label>
                    <select id="nuevoMetodoPago" class="form-select mb-3">
                        <option value="EFECTIVO">Efectivo</option>
                        <option value="TARJETA">Tarjeta</option>
                        <option value="TRANSFERENCIA">Transferencia</option>
                        <option value="MIXTO">Mixto</option>
                    </select>

                    <div id="camposImportes">
                        <label class="form-label">Efectivo</label>
                        <input id="nuevoEfectivo" type="number" min="0" step="0.01" class="form-control mb-2">
                        <label class="form-label">Tarjeta</label>
                        <input id="nuevaTarjeta" type="number" min="0" step="0.01" class="form-control mb-2">
                        <label class="form-label">Transferencia</label>
                        <input id="nuevaTransferencia" type="number" min="0" step="0.01" class="form-control mb-3">
                    </div>

                    <label class="form-label">Motivo del cambio</label>
                    <textarea id="motivoCambioPago" class="form-control" rows="3" placeholder="Ej. El cliente pagó con tarjeta y se registró como efectivo"></textarea>
                </div>`,
            width: 620,
            showCancelButton: true,
            confirmButtonText: 'Guardar cambio',
            cancelButtonText: 'Cancelar',
            allowOutsideClick: false,
            didOpen: () => {
                const metodo = document.getElementById('nuevoMetodoPago');
                metodo.value = pago.metodo_pago;
                metodo.addEventListener('change', () => ajustarImportesCambio(total));
                ajustarImportesCambio(total);
            },
            preConfirm: () => {
                const metodo = document.getElementById('nuevoMetodoPago').value;
                const efectivo = numero(document.getElementById('nuevoEfectivo').value);
                const tarjeta = numero(document.getElementById('nuevaTarjeta').value);
                const transferencia = numero(document.getElementById('nuevaTransferencia').value);
                const motivo = document.getElementById('motivoCambioPago').value.trim();

                if (!motivo) {
                    Swal.showValidationMessage('Captura el motivo del cambio.');
                    return false;
                }

                if (Math.abs((efectivo + tarjeta + transferencia) - total) > 0.009) {
                    Swal.showValidationMessage(`La suma debe ser exactamente $${moneda(total)}.`);
                    return false;
                }

                return { metodo, efectivo, tarjeta, transferencia, motivo };
            }
        }).then(result => {
            if (!result.isConfirmed) return;
            guardarCambioMetodo(pagoId, result.value);
        });
    });
}

function ajustarImportesCambio(total) {
    const metodo = document.getElementById('nuevoMetodoPago').value;
    const efectivo = document.getElementById('nuevoEfectivo');
    const tarjeta = document.getElementById('nuevaTarjeta');
    const transferencia = document.getElementById('nuevaTransferencia');

    efectivo.disabled = metodo !== 'MIXTO';
    tarjeta.disabled = metodo !== 'MIXTO';
    transferencia.disabled = metodo !== 'MIXTO';

    efectivo.value = metodo === 'EFECTIVO' ? total.toFixed(2) : '0.00';
    tarjeta.value = metodo === 'TARJETA' ? total.toFixed(2) : '0.00';
    transferencia.value = metodo === 'TRANSFERENCIA' ? total.toFixed(2) : '0.00';

    if (metodo === 'MIXTO') {
        efectivo.disabled = false;
        tarjeta.disabled = false;
        transferencia.disabled = false;
    }
}

function guardarCambioMetodo(pagoId, datos) {
    const formData = new FormData();
    formData.append('pago_id', pagoId);
    formData.append('metodo_pago', datos.metodo);
    formData.append('efectivo', datos.efectivo);
    formData.append('tarjeta', datos.tarjeta);
    formData.append('transferencia', datos.transferencia);
    formData.append('motivo', datos.motivo);

    fetch(`${BASE_URL}/cuentasCobradas/cambiarMetodo`, {
        method: 'POST',
        body: formData
    })
        .then(validarRespuesta)
        .then(data => {
            if (!data.success) throw new Error(data.message || 'No se pudo guardar el cambio.');
            return Swal.fire('Listo', data.message, 'success');
        })
        .then(() => cargarCuentas())
        .catch(error => {
            console.error(error);
            Swal.fire('Error', error.message, 'error');
        });
}

function cargarDetalle(pagoId) {
    return fetch(`${BASE_URL}/cuentasCobradas/detalle/${pagoId}`)
        .then(validarRespuesta)
        .then(data => {
            if (!data.success) throw new Error(data.message || 'No se pudo cargar el detalle.');
            return data.data;
        })
        .catch(error => {
            console.error(error);
            Swal.fire('Error', error.message, 'error');
            return null;
        });
}

function validarRespuesta(response) {
    return response.text().then(texto => {
        let data;
        try {
            data = JSON.parse(texto);
        } catch (e) {
            throw new Error(texto || 'El servidor devolvió una respuesta inválida.');
        }
        return data;
    });
}

function etiquetaMetodo(metodo) {
    return String(metodo || '').replace('_', ' ');
}

function hora(fecha) {
    if (!fecha) return '';
    const partes = String(fecha).split(' ');
    return partes.length > 1 ? partes[1].substring(0, 5) : fecha;
}

function numero(valor) {
    const n = parseFloat(valor || 0);
    return Number.isFinite(n) ? n : 0;
}

function moneda(valor) {
    return numero(valor).toFixed(2);
}

function escaparHtml(texto) {
    const div = document.createElement('div');
    div.textContent = texto ?? '';
    return div.innerHTML;
}
