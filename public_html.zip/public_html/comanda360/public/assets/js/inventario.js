let productosInventario = [];

document.addEventListener('DOMContentLoaded', function () {
    cargarInventario();
    cargarHistorial();
});

function cargarInventario() {
    fetch(`${BASE_URL}/inventario/productos`)
        .then(r => r.json())
        .then(data => {
            if (!data.success) {
                Swal.fire('Aviso', data.message, 'warning');
                return;
            }

            productosInventario = data.data;
            renderInventario(data.data);
        })
        .catch(error => {
            console.error(error);
            Swal.fire('Error', 'No se pudo cargar inventario.', 'error');
        });
}

function renderInventario(productos) {
    const contenedor = document.getElementById('contenedorInventario');

    let html = `
        <div class="table-responsive">
            <table class="table table-sm table-hover align-middle">
                <thead>
                    <tr>
                        <th>Producto</th>
                        <th>Categoría</th>
                        <th class="text-center">Controla stock</th>
                        <th class="text-end">Stock</th>
                        <th class="text-end">Mínimo</th>
                        <th>Estado</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody>
    `;

    productos.forEach(p => {
        const controla = parseInt(p.controla_stock) === 1;
        const stock = parseFloat(p.stock_actual || 0);
        const minimo = parseFloat(p.stock_minimo || 0);

        let estado = '<span class="badge bg-secondary">Sin control</span>';

        if (controla && stock <= minimo) {
            estado = '<span class="badge bg-danger">Stock bajo</span>';
        } else if (controla) {
            estado = '<span class="badge bg-success">Correcto</span>';
        }

        html += `
            <tr>
                <td>${escaparHtml(p.nombre)}</td>
                <td>${escaparHtml(p.categoria)}</td>
                <td class="text-center">
                    ${controla ? '<span class="badge bg-success">Sí</span>' : '<span class="badge bg-secondary">No</span>'}
                </td>
                <td class="text-end fw-bold">${formato(p.stock_actual)}</td>
                <td class="text-end">${formato(p.stock_minimo)}</td>
                <td>${estado}</td>
                <td class="text-center">
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-primary" onclick="configurarProducto(${p.id})">Config</button>
                        <button class="btn btn-success" onclick="nuevoMovimiento(${p.id}, 'ENTRADA')">Entrada</button>
                        <button class="btn btn-warning" onclick="nuevoMovimiento(${p.id}, 'SALIDA')">Salida</button>
                        <button class="btn btn-dark" onclick="nuevoMovimiento(${p.id}, 'AJUSTE')">Ajuste</button>
                    </div>
                </td>
            </tr>
        `;
    });

    html += `</tbody></table></div>`;

    contenedor.innerHTML = html;
}

function configurarProducto(id) {
    const p = productosInventario.find(x => parseInt(x.id) === parseInt(id));
    if (!p) return;

    Swal.fire({
        title: 'Configurar stock',
        html: `
            <div class="text-start">
                <p><strong>${escaparHtml(p.nombre)}</strong></p>

                <label class="form-label">Controla stock</label>
                <select id="controlaStock" class="form-select mb-3">
                    <option value="1" ${parseInt(p.controla_stock) === 1 ? 'selected' : ''}>Sí</option>
                    <option value="0" ${parseInt(p.controla_stock) === 0 ? 'selected' : ''}>No</option>
                </select>

                <label class="form-label">Stock mínimo</label>
                <input id="stockMinimo" type="number" step="0.01" class="form-control" value="${p.stock_minimo}">
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: 'Guardar',
        cancelButtonText: 'Cancelar',
        preConfirm: () => {
            return {
                controla_stock: document.getElementById('controlaStock').value,
                stock_minimo: document.getElementById('stockMinimo').value
            };
        }
    }).then(result => {
        if (!result.isConfirmed) return;

        const formData = new FormData();
        formData.append('producto_id', id);
        formData.append('controla_stock', result.value.controla_stock);
        formData.append('stock_minimo', result.value.stock_minimo);

        fetch(`${BASE_URL}/inventario/guardarConfig`, {
            method: 'POST',
            body: formData
        })
            .then(r => r.json())
            .then(data => {
                Swal.fire(data.success ? 'Listo' : 'Aviso', data.message, data.success ? 'success' : 'warning');
                cargarInventario();
            });
    });
}

function nuevoMovimiento(id, tipo) {
    const p = productosInventario.find(x => parseInt(x.id) === parseInt(id));
    if (!p) return;

    Swal.fire({
        title: `${tipo} de inventario`,
        html: `
            <div class="text-start">
                <p><strong>${escaparHtml(p.nombre)}</strong></p>
                <p class="text-muted">Stock actual: ${formato(p.stock_actual)}</p>

                <label class="form-label">${tipo === 'AJUSTE' ? 'Nuevo stock' : 'Cantidad'}</label>
                <input id="cantidadMovimiento" type="number" step="0.01" class="form-control mb-3">

                <label class="form-label">Motivo</label>
                <textarea id="motivoMovimiento" class="form-control" rows="3" placeholder="Ej. compra, merma, ajuste físico"></textarea>
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: 'Guardar',
        cancelButtonText: 'Cancelar',
        preConfirm: () => {
            const cantidad = parseFloat(document.getElementById('cantidadMovimiento').value || 0);
            const motivo = document.getElementById('motivoMovimiento').value.trim();

            if (cantidad < 0) {
                Swal.showValidationMessage('La cantidad no puede ser negativa.');
                return false;
            }

            if (tipo !== 'AJUSTE' && cantidad <= 0) {
                Swal.showValidationMessage('La cantidad debe ser mayor a cero.');
                return false;
            }

            if (!motivo) {
                Swal.showValidationMessage('Captura el motivo.');
                return false;
            }

            return { cantidad, motivo };
        }
    }).then(result => {
        if (!result.isConfirmed) return;

        const formData = new FormData();
        formData.append('producto_id', id);
        formData.append('tipo', tipo);
        formData.append('cantidad', result.value.cantidad);
        formData.append('motivo', result.value.motivo);

        fetch(`${BASE_URL}/inventario/movimiento`, {
            method: 'POST',
            body: formData
        })
            .then(r => r.json())
            .then(data => {
                Swal.fire(data.success ? 'Listo' : 'Aviso', data.message, data.success ? 'success' : 'warning');
                cargarInventario();
                cargarHistorial();
            });
    });
}

function cargarHistorial() {
    fetch(`${BASE_URL}/inventario/historial`)
        .then(r => r.json())
        .then(data => {
            if (data.success) renderHistorial(data.data);
        });
}

function renderHistorial(items) {
    const contenedor = document.getElementById('contenedorHistorial');

    if (!items || items.length === 0) {
        contenedor.innerHTML = `<div class="alert alert-secondary">Sin movimientos.</div>`;
        return;
    }

    let html = '';

    items.forEach(i => {
        html += `
            <div class="border-bottom py-2">
                <div class="d-flex justify-content-between">
                    <strong>${escaparHtml(i.producto)}</strong>
                    <span class="badge bg-dark">${i.tipo}</span>
                </div>
                <div class="small">
                    Cant: ${formato(i.cantidad)} |
                    ${formato(i.stock_anterior)} → ${formato(i.stock_nuevo)}
                </div>
                <div class="small text-muted">
                    ${escaparHtml(i.motivo)}
                </div>
                <div class="small text-muted">
                    ${i.created_at} | ${escaparHtml(i.usuario)}
                </div>
            </div>
        `;
    });

    contenedor.innerHTML = html;
}

function formato(v) {
    return parseFloat(v || 0).toFixed(2);
}

function escaparHtml(texto) {
    const div = document.createElement('div');
    div.textContent = texto ?? '';
    return div.innerHTML;
}