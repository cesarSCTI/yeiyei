document.addEventListener('DOMContentLoaded', function () {
    cargarCancelaciones();

    setInterval(function () {
        cargarCancelaciones(false);
    }, 8000);
});

function cargarCancelaciones(mostrarCarga = true) {
    const contenedor = document.getElementById('contenedorCancelaciones');

    if (!contenedor) return;

    if (mostrarCarga) {
        contenedor.innerHTML = `
            <div class="alert alert-info">Cargando cancelaciones...</div>
        `;
    }

    fetch(`${BASE_URL}/cancelaciones/listar`)
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                contenedor.innerHTML = `
                    <div class="alert alert-warning">${data.message}</div>
                `;
                return;
            }

            renderCancelaciones(data.data);
        })
        .catch(error => {
            console.error(error);

            contenedor.innerHTML = `
                <div class="alert alert-danger">
                    No se pudieron cargar las cancelaciones.
                </div>
            `;
        });
}

function renderCancelaciones(items) {
    const contenedor = document.getElementById('contenedorCancelaciones');

    if (!items || items.length === 0) {
        contenedor.innerHTML = `
            <div class="alert alert-secondary">
                No hay solicitudes de cancelación.
            </div>
        `;
        return;
    }

    let html = `
        <div class="table-responsive">
            <table class="table table-hover table-sm align-middle">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Mesa</th>
                        <th>Producto</th>
                        <th>Solicita</th>
                        <th>Motivo</th>
                        <th>Estado</th>
                        <th>Autoriza</th>
                        <th>Fecha</th>
                        <th class="text-end">Importe</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody>
    `;

    items.forEach(item => {
        const badge = badgeEstado(item.estado);

        html += `
            <tr>
                <td>#${item.id}</td>
                <td>${escaparHtml(item.mesa)}</td>
                <td>
                    <strong>${item.cantidad} x ${escaparHtml(item.producto)}</strong>
                </td>
                <td>${escaparHtml(item.solicita)}</td>
                <td>${escaparHtml(item.motivo)}</td>
                <td>
                    <span class="badge ${badge}">
                        ${item.estado}
                    </span>
                </td>
                <td>${item.autoriza ? escaparHtml(item.autoriza) : '<span class="text-muted">Pendiente</span>'}</td>
                <td>${item.created_at}</td>
                <td class="text-end">$${formatoMoneda(item.subtotal)}</td>
                <td class="text-center">
                    ${accionesCancelacion(item)}
                </td>
            </tr>
        `;
    });

    html += `
                </tbody>
            </table>
        </div>
    `;

    contenedor.innerHTML = html;
}

function accionesCancelacion(item) {
    if (item.estado !== 'SOLICITADA') {
        return '<span class="text-muted">Sin acciones</span>';
    }

    return `
        <div class="btn-group btn-group-sm">
            <button class="btn btn-success" onclick="aprobarCancelacion(${item.id})">
                Aprobar
            </button>

            <button class="btn btn-danger" onclick="rechazarCancelacion(${item.id})">
                Rechazar
            </button>
        </div>
    `;
}

function aprobarCancelacion(id) {
    Swal.fire({
        title: '¿Aprobar cancelación?',
        html: `
            <div class="text-start">
                <label class="form-label">Respuesta / comentario</label>
                <textarea id="respuestaCancelacion" class="form-control" rows="3">Cancelación aprobada.</textarea>
            </div>
        `,
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Sí, aprobar',
        cancelButtonText: 'Cancelar',
        preConfirm: () => {
            return document.getElementById('respuestaCancelacion').value || 'Cancelación aprobada.';
        }
    }).then(result => {
        if (!result.isConfirmed) return;

        const formData = new FormData();
        formData.append('id', id);
        formData.append('respuesta', result.value);

        fetch(`${BASE_URL}/cancelaciones/aprobar`, {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (!data.success) {
                    Swal.fire('Aviso', data.message, 'warning');
                    return;
                }

                Swal.fire({
                    icon: 'success',
                    title: 'Aprobada',
                    text: data.message,
                    timer: 1300,
                    showConfirmButton: false
                });

                cargarCancelaciones(false);
            })
            .catch(error => {
                console.error(error);
                Swal.fire('Error', 'No se pudo aprobar.', 'error');
            });
    });
}

function rechazarCancelacion(id) {
    Swal.fire({
        title: 'Rechazar cancelación',
        html: `
            <div class="text-start">
                <label class="form-label">Motivo del rechazo</label>
                <textarea id="respuestaCancelacion" class="form-control" rows="3" placeholder="Explica por qué se rechaza"></textarea>
            </div>
        `,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Rechazar',
        cancelButtonText: 'Cancelar',
        preConfirm: () => {
            const respuesta = document.getElementById('respuestaCancelacion').value.trim();

            if (respuesta === '') {
                Swal.showValidationMessage('Captura el motivo del rechazo.');
                return false;
            }

            return respuesta;
        }
    }).then(result => {
        if (!result.isConfirmed) return;

        const formData = new FormData();
        formData.append('id', id);
        formData.append('respuesta', result.value);

        fetch(`${BASE_URL}/cancelaciones/rechazar`, {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (!data.success) {
                    Swal.fire('Aviso', data.message, 'warning');
                    return;
                }

                Swal.fire({
                    icon: 'success',
                    title: 'Rechazada',
                    text: data.message,
                    timer: 1300,
                    showConfirmButton: false
                });

                cargarCancelaciones(false);
            })
            .catch(error => {
                console.error(error);
                Swal.fire('Error', 'No se pudo rechazar.', 'error');
            });
    });
}

function badgeEstado(estado) {
    switch (estado) {
        case 'SOLICITADA':
            return 'bg-warning text-dark';

        case 'APROBADA':
            return 'bg-success';

        case 'RECHAZADA':
            return 'bg-danger';

        default:
            return 'bg-secondary';
    }
}

function formatoMoneda(valor) {
    return parseFloat(valor || 0).toFixed(2);
}

function escaparHtml(texto) {
    const div = document.createElement('div');
    div.textContent = texto ?? '';
    return div.innerHTML;
}