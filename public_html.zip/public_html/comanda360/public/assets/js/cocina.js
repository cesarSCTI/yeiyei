document.addEventListener('DOMContentLoaded', function () {
    cargarCocina();

    setInterval(function () {
        cargarCocina(false);
    }, 5000);
});

function cargarCocina(mostrarCarga = true) {
    const contenedor = document.getElementById('contenedorCocina');

    if (!contenedor) return;

    if (mostrarCarga) {
        contenedor.innerHTML = `
            <div class="col-12">
                <div class="alert alert-info">
                    Cargando pedidos de cocina...
                </div>
            </div>
        `;
    }

    fetch(`${BASE_URL}/cocina/listar`)
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                contenedor.innerHTML = `
                    <div class="col-12">
                        <div class="alert alert-warning">
                            ${data.message}
                        </div>
                    </div>
                `;
                return;
            }

            renderizarCocina(data.data);
        })
        .catch(error => {
            console.error(error);

            contenedor.innerHTML = `
                <div class="col-12">
                    <div class="alert alert-danger">
                        No se pudieron cargar los pedidos de cocina.
                    </div>
                </div>
            `;
        });
}

function renderizarCocina(items) {
    const contenedor = document.getElementById('contenedorCocina');

    items = (items || []).filter(item => !esCategoriaBebida(item.categoria));

    if (items.length === 0) {
        contenedor.innerHTML = `
            <div class="col-12">
                <div class="alert alert-secondary">
                    No hay pedidos pendientes en cocina.
                </div>
            </div>
        `;
        return;
    }

    const pedidos = agruparPorPedido(items);

    let html = '';

    Object.keys(pedidos).forEach(pedidoId => {
        const grupo = pedidos[pedidoId];
        const primero = grupo[0];

        html += `
            <div class="col-12 col-md-6 col-xl-4">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-header bg-dark text-white">
                        <div class="d-flex justify-content-between">
                            <strong>${escaparHtml(primero.mesa)}</strong>
                            <span>Pedido #${pedidoId}</span>
                        </div>
                        <small>Mesero: ${escaparHtml(primero.mesero)}</small>
                    </div>

                    <div class="card-body">
        `;

        grupo.forEach(item => {
            const config = configEstado(item.estado);

            html += `
                <div class="border rounded p-3 mb-3 ${config.bg}">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <div class="fw-bold">
                                ${item.cantidad} x ${escaparHtml(item.producto)}
                            </div>

                            ${item.notas ? `
                                <div class="small text-primary mt-1">
                                    Nota: ${escaparHtml(item.notas)}
                                </div>
                            ` : ''}

                            <div class="small text-muted mt-1">
                                Estado: ${item.estado.replace('_', ' ')}
                            </div>
                        </div>

                        <span class="badge ${config.badge}">
                            ${config.texto}
                        </span>
                    </div>

                    <div class="d-grid gap-2 mt-3">
                        ${botonesEstado(item)}
                    </div>
                </div>
            `;
        });

        html += `
                    </div>

                    <div class="card-footer bg-white border-0 pt-0 pb-3 px-3">
                        <button
                            type="button"
                            class="btn btn-outline-dark w-100"
                            onclick="imprimirComanda(${pedidoId})"
                        >
                            Imprimir comanda
                        </button>
                    </div>
                </div>
            </div>
        `;
    });

    contenedor.innerHTML = html;
}

function agruparPorPedido(items) {
    return items.reduce((acc, item) => {
        if (!acc[item.pedido_id]) {
            acc[item.pedido_id] = [];
        }

        acc[item.pedido_id].push(item);

        return acc;
    }, {});
}

function botonesEstado(item) {
    if (item.estado === 'PENDIENTE') {
        return `
            <button class="btn btn-warning btn-sm" onclick="cambiarEstadoDetalle(${item.id}, 'EN_PREPARACION')">
                Iniciar preparación
            </button>
        `;
    }

    if (item.estado === 'EN_PREPARACION') {
        return `
            <button class="btn btn-success btn-sm" onclick="cambiarEstadoDetalle(${item.id}, 'LISTO')">
                Marcar listo
            </button>
        `;
    }

    if (item.estado === 'LISTO') {
        return `
            <button class="btn btn-primary btn-sm" onclick="cambiarEstadoDetalle(${item.id}, 'ENTREGADO')">
                Marcar entregado
            </button>
        `;
    }

    return '';
}

function cambiarEstadoDetalle(detalleId, estado) {
    const formData = new FormData();
    formData.append('detalle_id', detalleId);
    formData.append('estado', estado);

    fetch(`${BASE_URL}/cocina/cambiarEstado`, {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                Swal.fire('Aviso', data.message, 'warning');
                return;
            }

            cargarCocina(false);
        })
        .catch(error => {
            console.error(error);
            Swal.fire('Error', 'No se pudo cambiar el estado.', 'error');
        });
}

function configEstado(estado) {
    switch (estado) {
        case 'PENDIENTE':
            return {
                badge: 'bg-secondary',
                bg: 'bg-light',
                texto: 'Pendiente'
            };

        case 'EN_PREPARACION':
            return {
                badge: 'bg-warning text-dark',
                bg: 'bg-warning-subtle',
                texto: 'Preparando'
            };

        case 'LISTO':
            return {
                badge: 'bg-success',
                bg: 'bg-success-subtle',
                texto: 'Listo'
            };

        case 'ENTREGADO':
            return {
                badge: 'bg-primary',
                bg: 'bg-primary-subtle',
                texto: 'Entregado'
            };

        default:
            return {
                badge: 'bg-dark',
                bg: 'bg-light',
                texto: estado
            };
    }
}

function escaparHtml(texto) {
    const div = document.createElement('div');
    div.textContent = texto ?? '';
    return div.innerHTML;
}

function imprimirComanda(pedidoId) {
    const id = parseInt(pedidoId, 10);

    if (!Number.isInteger(id) || id <= 0) {
        Swal.fire('Aviso', 'Pedido inválido.', 'warning');
        return;
    }

    const ventana = window.open(
        `${BASE_URL}/impresion/comanda/${id}`,
        '_blank',
        'noopener,noreferrer'
    );

    if (!ventana) {
        Swal.fire({
            icon: 'warning',
            title: 'Ventana bloqueada',
            text: 'Permite las ventanas emergentes para imprimir la comanda.'
        });
    }
}



function esCategoriaBebida(categoria) {
    const valor = String(categoria || '').trim().toLowerCase();
    return ['bebida', 'bebidas', 'refresco', 'refrescos', 'jugo', 'jugos', 'agua', 'aguas'].includes(valor);
}
