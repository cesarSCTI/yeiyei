document.addEventListener('DOMContentLoaded', function(){

    cargarDashboard();

    setInterval(function(){

        cargarDashboard(false);

    },10000);

});

function cargarDashboard(mostrarCarga=true)
{
    const contenedor =
        document.getElementById('dashboardCards');

    if(!contenedor) return;

    if(mostrarCarga)
    {
        contenedor.innerHTML=`
            <div class="col-12">

                <div class="alert alert-info">

                    Cargando dashboard...

                </div>

            </div>
        `;
    }

    fetch(`${BASE_URL}/dashboard/resumen`)

    .then(r=>r.json())

    .then(data=>{

        if(!data.success)
        {
            contenedor.innerHTML=`
                <div class="alert alert-warning">

                    ${data.message}

                </div>
            `;

            return;
        }

        renderDashboard(data.data);

    })

    .catch(error=>{

        console.error(error);

    });
}

function renderDashboard(d)
{
    const total =
        parseFloat(d.total_final_dia||0);

    document.getElementById('dashboardCards').innerHTML=`

        ${card('Mesas libres',d.mesas_libres,'success')}

        ${card('Mesas ocupadas',d.mesas_ocupadas,'danger')}

        ${card('Pedidos activos',d.pedidos_activos,'dark')}

        ${card('Cocina pendiente',d.cocina_pendiente,'warning')}

        ${card('Productos listos',d.productos_listos,'primary')}

        ${card('Cancelaciones pendientes',d.cancelaciones_pendientes,'secondary')}

        ${moneyCard('Ventas día',d.ventas_dia,'success')}

        ${moneyCard('Egresos día',d.egresos_dia,'danger')}

        ${moneyCard('Total neto día',total,'dark')}
    `;
}

function card(t,v,c)
{
    return `
        <div class="col-md-6 col-xl-4">

            <div class="card border-0 shadow-sm h-100">

                <div class="card-body">

                    <small class="text-muted">

                        ${t}

                    </small>

                    <h2 class="text-${c} mt-2">

                        ${v}

                    </h2>

                </div>

            </div>

        </div>
    `;
}

function moneyCard(t,v,c)
{
    return `
        <div class="col-md-6 col-xl-4">

            <div class="card border-0 shadow-sm h-100">

                <div class="card-body">

                    <small class="text-muted">

                        ${t}

                    </small>

                    <h2 class="text-${c} mt-2">

                        $${formato(v)}

                    </h2>

                </div>

            </div>

        </div>
    `;
}

function formato(v)
{
    return parseFloat(v||0)
        .toFixed(2);
}