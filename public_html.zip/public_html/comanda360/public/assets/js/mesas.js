let mesasGlobal = [];

document.addEventListener('DOMContentLoaded', function () {
    const buscador = document.getElementById('buscarMesa');
    const filtroEstado = document.getElementById('filtroEstadoMesa');
    const btnLimpiar = document.getElementById('btnLimpiarBusqueda');

    if (buscador) {
        buscador.addEventListener('input', aplicarFiltrosMesas);
    }

    if (filtroEstado) {
        filtroEstado.addEventListener('change', aplicarFiltrosMesas);
    }

    if (btnLimpiar) {
        btnLimpiar.addEventListener('click', function () {
            if (buscador) buscador.value = '';
            if (filtroEstado) filtroEstado.value = 'TODAS';
            aplicarFiltrosMesas();
            if (buscador) buscador.focus();
        });
    }

    cargarMesas();

    setInterval(function () {
        cargarMesas(false);
    }, 5000);
});

function cargarMesas(mostrarCarga = true) {
    const contenedor = document.getElementById('contenedorMesas');

    if (!contenedor) return;

    if (mostrarCarga) {
        contenedor.innerHTML = `
            <div class="col-12">
                <div class="alert alert-info">
                    Cargando mesas...
                </div>
            </div>
        `;
    }

    fetch(`${BASE_URL}/mesas/listar`)
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                contenedor.innerHTML = `
                    <div class="col-12">
                        <div class="alert alert-warning">
                            ${data.message}
                        </div>
                    </div>
                `;
                return;
            }

            mesasGlobal = Array.isArray(data.data) ? data.data : [];
            aplicarFiltrosMesas();
        })
        .catch(error => {
            console.error(error);

            contenedor.innerHTML = `
                <div class="col-12">
                    <div class="alert alert-danger">
                        No se pudieron cargar las mesas.
                    </div>
                </div>
            `;
        });
}

function aplicarFiltrosMesas() {
    const texto = normalizarTexto(document.getElementById('buscarMesa')?.value || '');
    const estado = document.getElementById('filtroEstadoMesa')?.value || 'TODAS';

    const mesasFiltradas = mesasGlobal.filter(mesa => {
        const coincideEstado = estado === 'TODAS' || mesa.estado === estado;

        const contenido = normalizarTexto([
            mesa.id,
            mesa.nombre,
            mesa.descripcion || '',
            mesa.estado || '',
            String(mesa.estado || '').replaceAll('_', ' ')
        ].join(' '));

        const coincideTexto = texto === '' || contenido.includes(texto);

        return coincideEstado && coincideTexto;
    });

    renderizarMesas(mesasFiltradas);
    actualizarResumenBusqueda(mesasFiltradas.length, mesasGlobal.length);
}

function actualizarResumenBusqueda(mostradas, total) {
    const resumen = document.getElementById('resumenBusquedaMesas');
    if (!resumen) return;

    if (total === 0) {
        resumen.textContent = 'No hay mesas registradas.';
        return;
    }

    resumen.textContent = mostradas === total
        ? `${total} mesa${total === 1 ? '' : 's'} disponible${total === 1 ? '' : 's'} en el listado.`
        : `Mostrando ${mostradas} de ${total} mesa${total === 1 ? '' : 's'}.`;
}

function normalizarTexto(texto) {
    return String(texto ?? '')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
        .trim();
}

function renderizarMesas(mesas) {
    const contenedor = document.getElementById('contenedorMesas');

    if (!mesas || mesas.length === 0) {
        const hayMesasRegistradas = mesasGlobal.length > 0;

        contenedor.innerHTML = `
            <div class="col-12">
                <div class="alert alert-secondary mb-0">
                    ${hayMesasRegistradas
                        ? 'No se encontraron mesas con la búsqueda o el estado seleccionado.'
                        : 'No hay mesas registradas.'}
                </div>
            </div>
        `;
        return;
    }

    let html = '';

    mesas.forEach(mesa => {
        const estado = mesa.estado;
        const config = obtenerConfigEstado(estado);

        html += `
            <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <h5 class="mb-0">${escaparHtml(mesa.nombre)}</h5>
                            <span class="badge ${config.badge}">
                                ${estado.replace('_', ' ')}
                            </span>
                        </div>

                        <p class="text-muted small mb-3">
                            ${mesa.descripcion ? escaparHtml(mesa.descripcion) : 'Sin descripción'}
                        </p>

                        <div class="border rounded p-3 mb-3 ${config.bg}">
                            <div class="fw-bold">${config.titulo}</div>
                            <div class="small">${config.descripcion}</div>
                        </div>

                        ${botonesMesa(mesa)}
                    </div>
                </div>
            </div>
        `;
    });

    contenedor.innerHTML = html;
}

function obtenerConfigEstado(estado) {
    switch (estado) {
        case 'LIBRE':
            return {
                badge: 'bg-success',
                bg: 'bg-success-subtle',
                titulo: 'Mesa disponible',
                descripcion: 'Lista para abrir pedido.'
            };

        case 'OCUPADA':
            return {
                badge: 'bg-warning text-dark',
                bg: 'bg-warning-subtle',
                titulo: 'Mesa ocupada',
                descripcion: 'Pedido activo en proceso.'
            };

        case 'CUENTA_SOLICITADA':
            return {
                badge: 'bg-primary',
                bg: 'bg-primary-subtle',
                titulo: 'Cuenta solicitada',
                descripcion: 'Lista para pasar a caja.'
            };

        case 'COBRADA':
            return {
                badge: 'bg-secondary',
                bg: 'bg-secondary-subtle',
                titulo: 'Mesa cobrada',
                descripcion: 'Pendiente liberar mesa.'
            };

        default:
            return {
                badge: 'bg-dark',
                bg: 'bg-light',
                titulo: 'Estado desconocido',
                descripcion: 'Revisar estado de mesa.'
            };
    }
}

function botonesMesa(mesa) {
    if (mesa.estado === 'LIBRE') {
        return `
            <button class="btn btn-success w-100" onclick="abrirMesa(${mesa.id})">
                Abrir mesa
            </button>
        `;
    }

    if (mesa.estado === 'OCUPADA') {
        return `
            <div class="d-grid gap-2">
                <button class="btn btn-dark" onclick="verPedido(${mesa.id})">
                    Ver pedido
                </button>

                <button class="btn btn-outline-warning" onclick="moverPedidoDesdeMesa(${mesa.id})">
                    Mover a otra mesa
                </button>

                <button class="btn btn-outline-primary" onclick="solicitarCuenta(${mesa.id})">
                    Solicitar cuenta
                </button>
            </div>
        `;
    }

    if (mesa.estado === 'CUENTA_SOLICITADA') {
        return `
            <div class="d-grid gap-2">
                <button class="btn btn-primary" onclick="irCaja(${mesa.id})">
                    Ir a caja
                </button>

                <button class="btn btn-outline-secondary" onclick="regresarOcupada(${mesa.id})">
                    Regresar a ocupada
                </button>
            </div>
        `;
    }

    if (mesa.estado === 'COBRADA') {
        return `
            <button class="btn btn-secondary w-100" onclick="liberarMesa(${mesa.id})">
                Liberar mesa
            </button>
        `;
    }

    return '';
}

function abrirMesa(mesaId) {
    Swal.fire({
        title: '¿Abrir mesa?',
        text: 'Se abrirá la comanda para esta mesa.',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Sí, abrir',
        cancelButtonText: 'Cancelar'
    }).then(result => {
        if (result.isConfirmed) {
            window.location.href = `${BASE_URL}/pedidos/ver/${mesaId}`;
        }
    });
}

function solicitarCuenta(mesaId) {
    Swal.fire({
        title: '¿Solicitar cuenta?',
        text: 'La mesa pasará a caja para cobro.',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Sí, solicitar',
        cancelButtonText: 'Cancelar'
    }).then(result => {
        if (result.isConfirmed) {
            cambiarEstadoMesa(mesaId, 'CUENTA_SOLICITADA');
        }
    });
}

function regresarOcupada(mesaId) {
    cambiarEstadoMesa(mesaId, 'OCUPADA');
}

function liberarMesa(mesaId) {
    Swal.fire({
        title: '¿Liberar mesa?',
        text: 'La mesa quedará disponible.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Sí, liberar',
        cancelButtonText: 'Cancelar'
    }).then(result => {
        if (result.isConfirmed) {
            cambiarEstadoMesa(mesaId, 'LIBRE');
        }
    });
}

function cambiarEstadoMesa(mesaId, estado) {
    const formData = new FormData();
    formData.append('mesa_id', mesaId);
    formData.append('estado', estado);

    fetch(`${BASE_URL}/mesas/cambiarEstado`, {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                Swal.fire({
                    icon: 'warning',
                    title: 'No se pudo actualizar',
                    text: data.message
                });
                return;
            }

            cargarMesas(false);
        })
        .catch(error => {
            console.error(error);

            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'No se pudo actualizar la mesa.'
            });
        });
}

function verPedido(mesaId) {
    window.location.href = `${BASE_URL}/pedidos/ver/${mesaId}`;
}

function irCaja(mesaId) {
    window.location.href = `${BASE_URL}/caja`;
}

function escaparHtml(texto) {
    const div = document.createElement('div');
    div.textContent = texto;
    return div.innerHTML;
}

function moverPedidoDesdeMesa(mesaId) {
    // La pantalla del pedido contiene la selección y validación completa.
    window.location.href = `${BASE_URL}/pedidos/ver/${mesaId}#mover-mesa`;
}
