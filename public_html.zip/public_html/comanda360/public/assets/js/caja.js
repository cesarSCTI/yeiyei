document.addEventListener('DOMContentLoaded', function () {
    cargarCaja();

    setInterval(function () {
        cargarCaja(false);
    }, 8000);
});

function cargarCaja(mostrarCarga = true) {
    const contenedor = document.getElementById('contenedorCaja');

    if (!contenedor) return;

    if (mostrarCarga) {
        contenedor.innerHTML = `
            <div class="col-12">
                <div class="alert alert-info">Cargando cuentas...</div>
            </div>
        `;
    }

    fetch(`${BASE_URL}/caja/listar`)
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                contenedor.innerHTML = `<div class="col-12"><div class="alert alert-warning">${data.message}</div></div>`;
                return;
            }

            renderizarCaja(data.data);
        })
        .catch(error => {
            console.error(error);
            contenedor.innerHTML = `<div class="col-12"><div class="alert alert-danger">No se pudo cargar caja.</div></div>`;
        });
}

function renderizarCaja(pedidos) {
    const contenedor = document.getElementById('contenedorCaja');

    if (!pedidos || pedidos.length === 0) {
        contenedor.innerHTML = `
            <div class="col-12">
                <div class="alert alert-secondary">
                    No hay cuentas solicitadas.
                </div>
            </div>
        `;
        return;
    }

    let html = '';

    pedidos.forEach(pedido => {
        const detalleOriginal = Array.isArray(pedido.detalle) ? pedido.detalle : [];
        const detalle = agruparDetalleProductos(detalleOriginal);
        let htmlDetalle = '';

        if (detalle.length === 0) {
            htmlDetalle = `
                <div class="alert alert-warning py-2 mb-3">
                    Este pedido no contiene productos para cobrar.
                </div>
            `;
        } else {
            htmlDetalle = '<div class="list-group list-group-flush border rounded mb-3">';

            detalle.forEach(item => {
                const subtotalOriginal = parseFloat(item.subtotal_original || item.subtotal || 0);
                const subtotalFinal = parseFloat(item.subtotal || 0);
                const descuento = parseFloat(item.descuento_importe || 0);

                htmlDetalle += `
                    <div class="list-group-item px-2 py-2">
                        <div class="d-flex justify-content-between align-items-start gap-2">
                            <div>
                                <strong>${item.cantidad} x ${escaparHtml(item.producto)}</strong>
                                ${item.notas ? `<div class="small text-muted">Nota: ${escaparHtml(item.notas)}</div>` : ''}
                                ${descuento > 0 ? `<div class="small text-success">Descuento: -$${formatoMoneda(descuento)}</div>` : ''}
                            </div>
                            <div class="text-end text-nowrap">
                                ${descuento > 0 ? `<div class="small text-muted text-decoration-line-through">$${formatoMoneda(subtotalOriginal)}</div>` : ''}
                                <strong>$${formatoMoneda(subtotalFinal)}</strong>
                            </div>
                        </div>
                    </div>
                `;
            });

            htmlDetalle += '</div>';
        }

        html += `
            <div class="col-12 col-md-6 col-xl-4">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-header bg-dark text-white">
                        <div class="d-flex justify-content-between">
                            <strong>${escaparHtml(pedido.mesa)}</strong>
                            <span>Pedido #${pedido.id}</span>
                        </div>
                        <small>Mesero: ${escaparHtml(pedido.mesero)}</small>
                    </div>

                    <div class="card-body d-flex flex-column">
                        <h6 class="mb-2">Productos</h6>

                        ${htmlDetalle}

                        <div class="d-flex justify-content-between align-items-center mt-auto mb-3 border-top pt-3">
                            <strong>Total</strong>
                            <h3 class="mb-0">$${formatoMoneda(pedido.total)}</h3>
                        </div>

                        <div class="d-grid gap-2">
                            <button class="btn btn-outline-dark" onclick="imprimirPrecuenta(${pedido.id})" ${detalle.length === 0 ? 'disabled' : ''}>
                                Imprimir precuenta
                            </button>

                            <button class="btn btn-success" onclick="abrirCobro(${pedido.id})" ${detalle.length === 0 ? 'disabled' : ''}>
                                Cobrar
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });

    contenedor.innerHTML = html;
}

function abrirCobro(pedidoId) {
    fetch(`${BASE_URL}/caja/ver/${pedidoId}`)
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                Swal.fire('Aviso', data.message, 'warning');
                return;
            }

            mostrarModalCobro(data.pedido, data.detalle);
        })
        .catch(error => {
            console.error(error);
            Swal.fire('Error', 'No se pudo cargar el pedido.', 'error');
        });
}

function mostrarModalCobro(pedido, detalle) {
    const detalleAgrupado = agruparDetalleProductos(detalle);
    let htmlDetalle = '<div class="text-start mb-3">';

    detalleAgrupado.forEach(item => {
        if (item.estado === 'CANCELADO') return;

        const subtotalOriginal = parseFloat(item.subtotal_original || item.subtotal || 0);
        const subtotalFinal = parseFloat(item.subtotal || 0);
        const descuento = parseFloat(item.descuento_importe || 0);

        htmlDetalle += `
            <div class="border-bottom py-2">
                <div class="d-flex justify-content-between gap-2">
                    <span>${item.cantidad} x ${escaparHtml(item.producto)}</span>
                    <div class="text-end">
                        ${descuento > 0 ? `<div class="small text-muted text-decoration-line-through">$${formatoMoneda(subtotalOriginal)}</div>` : ''}
                        <strong>$${formatoMoneda(subtotalFinal)}</strong>
                    </div>
                </div>
                ${descuento > 0 ? `<div class="small text-success">Descuento producto: -$${formatoMoneda(descuento)}</div>` : ''}
            </div>
        `;
    });

    htmlDetalle += '</div>';
    const subtotalPedido = parseFloat(pedido.total || 0);

    Swal.fire({
        title: `${pedido.mesa} | Pedido #${pedido.id}`,
        html: `
            ${htmlDetalle}

            <div class="text-start">
                <div class="border rounded p-3 mb-3 bg-light">
                    <label class="form-label fw-bold">Descuento al total</label>
                    <select id="descuentoTipoPago" class="form-select mb-2">
                        <option value="NINGUNO">Sin descuento</option>
                        <option value="PORCENTAJE">Porcentaje (%)</option>
                        <option value="MONTO">Monto fijo ($)</option>
                    </select>

                    <label class="form-label">Valor del descuento</label>
                    <input id="descuentoValorPago" type="number" min="0" step="0.01" class="form-control" value="0" disabled>
                </div>

                <label class="form-label">Método de pago</label>
                <select id="metodoPago" class="form-select mb-3">
                    <option value="EFECTIVO">Efectivo</option>
                    <option value="TARJETA">Tarjeta</option>
                    <option value="TRANSFERENCIA">Transferencia</option>
                    <option value="MIXTO">Mixto</option>
                </select>

                <label class="form-label">Efectivo</label>
                <input id="pagoEfectivo" type="number" step="0.01" min="0" class="form-control mb-2" value="${subtotalPedido.toFixed(2)}">

                <label class="form-label">Tarjeta</label>
                <input id="pagoTarjeta" type="number" step="0.01" min="0" class="form-control mb-2" value="0">

                <label class="form-label">Transferencia</label>
                <input id="pagoTransferencia" type="number" step="0.01" min="0" class="form-control mb-2" value="0">

                <div class="alert alert-light border mt-3">
                    <div class="d-flex justify-content-between">
                        <span>Subtotal:</span>
                        <span>$${formatoMoneda(subtotalPedido)}</span>
                    </div>
                    <div class="d-flex justify-content-between text-success">
                        <span>Descuento:</span>
                        <span id="descuentoImportePago">-$0.00</span>
                    </div>
                    <div class="d-flex justify-content-between border-top pt-2 mt-2">
                        <strong>Total a cobrar:</strong>
                        <strong id="totalCobrarPago">$${formatoMoneda(subtotalPedido)}</strong>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span>Pagado:</span>
                        <span id="totalPagado">$${formatoMoneda(subtotalPedido)}</span>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span>Cambio:</span>
                        <span id="cambioPago">$0.00</span>
                    </div>
                </div>
            </div>
        `,
        width: 650,
        showCancelButton: true,
        confirmButtonText: 'Confirmar cobro',
        cancelButtonText: 'Cancelar',
        allowOutsideClick: false,
        didOpen: () => {
            const descuentoTipo = document.getElementById('descuentoTipoPago');
            const descuentoValor = document.getElementById('descuentoValorPago');
            const metodo = document.getElementById('metodoPago');
            const inputsPago = [
                document.getElementById('pagoEfectivo'),
                document.getElementById('pagoTarjeta'),
                document.getElementById('pagoTransferencia')
            ];

            descuentoTipo.addEventListener('change', () => {
                descuentoValor.disabled = descuentoTipo.value === 'NINGUNO';
                if (descuentoTipo.value === 'NINGUNO') descuentoValor.value = '0';
                ajustarMetodoPago(subtotalPedido);
            });
            descuentoValor.addEventListener('input', () => ajustarMetodoPago(subtotalPedido));
            metodo.addEventListener('change', () => ajustarMetodoPago(subtotalPedido));
            inputsPago.forEach(input => input.addEventListener('input', () => calcularPago(subtotalPedido)));

            ajustarMetodoPago(subtotalPedido);
        },
        preConfirm: () => {
            const metodo = document.getElementById('metodoPago').value;
            const descuentoTipo = document.getElementById('descuentoTipoPago').value;
            const descuentoValor = Math.max(parseFloat(document.getElementById('descuentoValorPago').value || 0), 0);
            const calculo = calcularDescuentoTotal(subtotalPedido, descuentoTipo, descuentoValor);

            if (!calculo.valido) {
                Swal.showValidationMessage(calculo.mensaje);
                return false;
            }

            const efectivo = Math.max(parseFloat(document.getElementById('pagoEfectivo').value || 0), 0);
            const tarjeta = Math.max(parseFloat(document.getElementById('pagoTarjeta').value || 0), 0);
            const transferencia = Math.max(parseFloat(document.getElementById('pagoTransferencia').value || 0), 0);
            const pagado = efectivo + tarjeta + transferencia;
            const totalCobrar = calculo.total;

            if (pagado < totalCobrar) {
                Swal.showValidationMessage(`Faltan $${formatoMoneda(totalCobrar - pagado)} para completar el pago.`);
                return false;
            }

            if (metodo !== 'EFECTIVO' && Math.abs(pagado - totalCobrar) > 0.009) {
                Swal.showValidationMessage('El importe pagado debe coincidir exactamente con el total a cobrar.');
                return false;
            }

            return {
                metodo,
                efectivo,
                tarjeta,
                transferencia,
                cambio: metodo === 'EFECTIVO' ? Math.max(pagado - totalCobrar, 0) : 0,
                descuento_tipo: descuentoTipo,
                descuento_valor: descuentoValor
            };
        }
    }).then(result => {
        if (!result.isConfirmed) return;
        registrarCobro(pedido.id, result.value);
    });
}

function calcularDescuentoTotal(subtotal, tipo, valor) {
    subtotal = Math.max(parseFloat(subtotal || 0), 0);
    valor = Math.max(parseFloat(valor || 0), 0);
    let importe = 0;

    if (tipo === 'PORCENTAJE') {
        if (valor > 100) {
            return { valido: false, mensaje: 'El porcentaje no puede ser mayor a 100%.', importe: 0, total: subtotal };
        }
        importe = subtotal * (valor / 100);
    } else if (tipo === 'MONTO') {
        if (valor > subtotal) {
            return { valido: false, mensaje: 'El descuento no puede ser mayor al subtotal.', importe: 0, total: subtotal };
        }
        importe = valor;
    }

    importe = Math.round(importe * 100) / 100;
    const total = Math.round(Math.max(subtotal - importe, 0) * 100) / 100;
    return { valido: true, mensaje: '', importe, total };
}

function ajustarMetodoPago(subtotal) {
    const metodo = document.getElementById('metodoPago')?.value || 'EFECTIVO';
    const efectivo = document.getElementById('pagoEfectivo');
    const tarjeta = document.getElementById('pagoTarjeta');
    const transferencia = document.getElementById('pagoTransferencia');
    if (!efectivo || !tarjeta || !transferencia) return;

    const tipo = document.getElementById('descuentoTipoPago')?.value || 'NINGUNO';
    const valor = parseFloat(document.getElementById('descuentoValorPago')?.value || 0);
    const calculo = calcularDescuentoTotal(subtotal, tipo, valor);
    const total = calculo.valido ? calculo.total : subtotal;

    efectivo.disabled = metodo === 'TARJETA' || metodo === 'TRANSFERENCIA';
    tarjeta.disabled = metodo === 'EFECTIVO' || metodo === 'TRANSFERENCIA';
    transferencia.disabled = metodo === 'EFECTIVO' || metodo === 'TARJETA';

    if (metodo === 'EFECTIVO') {
        efectivo.value = total.toFixed(2);
        tarjeta.value = '0';
        transferencia.value = '0';
    } else if (metodo === 'TARJETA') {
        efectivo.value = '0';
        tarjeta.value = total.toFixed(2);
        transferencia.value = '0';
    } else if (metodo === 'TRANSFERENCIA') {
        efectivo.value = '0';
        tarjeta.value = '0';
        transferencia.value = total.toFixed(2);
    } else {
        efectivo.disabled = false;
        tarjeta.disabled = false;
        transferencia.disabled = false;
        efectivo.value = '0';
        tarjeta.value = '0';
        transferencia.value = '0';
    }

    calcularPago(subtotal);
}

function calcularPago(subtotal) {
    const tipo = document.getElementById('descuentoTipoPago')?.value || 'NINGUNO';
    const valor = parseFloat(document.getElementById('descuentoValorPago')?.value || 0);
    const calculo = calcularDescuentoTotal(subtotal, tipo, valor);
    const total = calculo.valido ? calculo.total : subtotal;

    const efectivo = Math.max(parseFloat(document.getElementById('pagoEfectivo')?.value || 0), 0);
    const tarjeta = Math.max(parseFloat(document.getElementById('pagoTarjeta')?.value || 0), 0);
    const transferencia = Math.max(parseFloat(document.getElementById('pagoTransferencia')?.value || 0), 0);
    const pagado = efectivo + tarjeta + transferencia;
    const cambio = Math.max(pagado - total, 0);

    const descuentoImporte = document.getElementById('descuentoImportePago');
    const totalCobrar = document.getElementById('totalCobrarPago');
    const totalPagado = document.getElementById('totalPagado');
    const cambioPago = document.getElementById('cambioPago');

    if (descuentoImporte) descuentoImporte.innerText = `-$${formatoMoneda(calculo.valido ? calculo.importe : 0)}`;
    if (totalCobrar) totalCobrar.innerText = `$${formatoMoneda(total)}`;
    if (totalPagado) totalPagado.innerText = `$${formatoMoneda(pagado)}`;
    if (cambioPago) cambioPago.innerText = `$${formatoMoneda(cambio)}`;
}

function registrarCobro(pedidoId, pago) {
    const formData = new FormData();
    formData.append('pedido_id', pedidoId);
    formData.append('metodo_pago', pago.metodo);
    formData.append('efectivo', pago.efectivo);
    formData.append('tarjeta', pago.tarjeta);
    formData.append('transferencia', pago.transferencia);
    formData.append('cambio', pago.cambio);
    formData.append('descuento_tipo', pago.descuento_tipo || 'NINGUNO');
    formData.append('descuento_valor', pago.descuento_valor || 0);

    fetch(`${BASE_URL}/caja/cobrar`, {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                Swal.fire('Aviso', data.message, 'warning');
                return;
            }

            Swal.fire({
                icon: 'success',
                title: 'Cobro registrado',
                text: '¿Deseas imprimir el ticket final?',
                showCancelButton: true,
                confirmButtonText: 'Imprimir ticket',
                cancelButtonText: 'No imprimir'
            }).then(result => {
                if (result.isConfirmed) {
                    window.open(`${BASE_URL}/impresion/ticket/${pedidoId}`, '_blank');
                }

                cargarCaja(false);
            });

            cargarCaja(false);
        })
        .catch(error => {
            console.error(error);
            Swal.fire('Error', 'No se pudo registrar el cobro.', 'error');
        });
}

function agruparDetalleProductos(detalle) {
    const grupos = new Map();

    (Array.isArray(detalle) ? detalle : []).forEach(item => {
        if (item.estado === 'CANCELADO') return;

        const notas = String(item.notas || '').trim();
        const descuentoTipo = String(item.descuento_tipo || 'NINGUNO');
        const descuentoValor = parseFloat(item.descuento_valor || 0);
        const precioUnitario = parseFloat(item.precio_unitario || 0);

        // Solo se agrupan productos con la misma presentación económica,
        // las mismas notas y el mismo descuento.
        const clave = [
            item.producto_id,
            precioUnitario.toFixed(4),
            notas.toLowerCase(),
            descuentoTipo,
            descuentoValor.toFixed(4)
        ].join('|');

        const cantidad = parseFloat(item.cantidad || 0);
        const subtotalOriginal = parseFloat(item.subtotal_original || item.subtotal || 0);
        const descuentoImporte = parseFloat(item.descuento_importe || 0);
        const subtotal = parseFloat(item.subtotal || 0);

        if (!grupos.has(clave)) {
            grupos.set(clave, {
                ...item,
                cantidad: 0,
                subtotal_original: 0,
                descuento_importe: 0,
                subtotal: 0,
                notas
            });
        }

        const grupo = grupos.get(clave);
        grupo.cantidad += cantidad;
        grupo.subtotal_original += subtotalOriginal;
        grupo.descuento_importe += descuentoImporte;
        grupo.subtotal += subtotal;
    });

    return Array.from(grupos.values());
}

function formatoMoneda(valor) {
    return parseFloat(valor || 0).toFixed(2);
}

function escaparHtml(texto) {
    const div = document.createElement('div');
    div.textContent = texto ?? '';
    return div.innerHTML;
}

function imprimirPrecuenta(pedidoId) {
    window.open(`${BASE_URL}/impresion/precuenta/${pedidoId}`, '_blank');
}