let productosGlobal = [];
let categoriasGlobal = [];

document.addEventListener('DOMContentLoaded', function () {
    cargarCategorias();
    cargarProductos();
});

function cargarCategorias() {
    fetch(`${BASE_URL}/productos/categorias`)
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                categoriasGlobal = data.data;
            }
        });
}

function cargarProductos() {
    fetch(`${BASE_URL}/productos/listar`)
        .then(r => r.json())
        .then(data => {
            if (!data.success) {
                Swal.fire('Aviso', data.message, 'warning');
                return;
            }

            productosGlobal = data.data;
            renderProductos(data.data);
        })
        .catch(error => {
            console.error(error);
            Swal.fire('Error', 'No se pudieron cargar los productos.', 'error');
        });
}

function renderProductos(productos) {
    const contenedor = document.getElementById('contenedorProductos');

    if (!productos || productos.length === 0) {
        contenedor.innerHTML = `
            <div class="alert alert-secondary">
                No hay productos registrados.
            </div>
        `;
        return;
    }

    let html = `
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-sm table-hover align-middle">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Producto</th>
                                <th>Categoría</th>
                                <th class="text-end">Precio</th>
                                <th class="text-center">Stock</th>
                                <th class="text-end">Mínimo</th>
                                <th>Disponible</th>
                                <th>Activo</th>
                                <th class="text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
    `;

    productos.forEach(p => {
        html += `
            <tr>
                <td>${p.id}</td>
                <td>
                    <strong>${escaparHtml(p.nombre)}</strong>
                    <div class="small text-muted">
                        ${p.descripcion ? escaparHtml(p.descripcion) : 'Sin descripción'}
                    </div>
                </td>
                <td>${escaparHtml(p.categoria)}</td>
                <td class="text-end">$${formato(p.precio)}</td>
                <td class="text-center">
                    ${parseInt(p.controla_stock) === 1 ? '<span class="badge bg-success">Sí</span>' : '<span class="badge bg-secondary">No</span>'}
                </td>
                <td class="text-end">${formato(p.stock_minimo)}</td>
                <td>
                    <span class="badge ${parseInt(p.disponible) === 1 ? 'bg-success' : 'bg-warning text-dark'}">
                        ${parseInt(p.disponible) === 1 ? 'Disponible' : 'No disponible'}
                    </span>
                </td>
                <td>
                    <span class="badge ${parseInt(p.activo) === 1 ? 'bg-success' : 'bg-secondary'}">
                        ${parseInt(p.activo) === 1 ? 'Activo' : 'Inactivo'}
                    </span>
                </td>
                <td class="text-center">
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-primary" onclick="editarProducto(${p.id})">Editar</button>

                        <button class="btn ${parseInt(p.disponible) === 1 ? 'btn-outline-warning' : 'btn-outline-success'}"
                            onclick="cambiarDisponible(${p.id}, ${parseInt(p.disponible) === 1 ? 0 : 1})">
                            ${parseInt(p.disponible) === 1 ? 'No disp.' : 'Disponible'}
                        </button>

                        <button class="btn ${parseInt(p.activo) === 1 ? 'btn-outline-danger' : 'btn-outline-success'}"
                            onclick="cambiarActivo(${p.id}, ${parseInt(p.activo) === 1 ? 0 : 1})">
                            ${parseInt(p.activo) === 1 ? 'Desactivar' : 'Activar'}
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });

    html += `
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    `;

    contenedor.innerHTML = html;
}

function nuevoProducto() {
    abrirModalProducto(null);
}

function editarProducto(id) {
    const producto = productosGlobal.find(p => parseInt(p.id) === parseInt(id));
    abrirModalProducto(producto);
}

function abrirModalProducto(producto) {
    const editar = !!producto;

    Swal.fire({
        title: editar ? 'Editar producto' : 'Nuevo producto',
        html: `
            <div class="text-start">
                <input type="hidden" id="productoId" value="${editar ? producto.id : 0}">

                <label class="form-label">Categoría</label>
                <select id="categoriaProducto" class="form-select mb-2">
                    ${categoriasGlobal.map(c => `
                        <option value="${c.id}" ${editar && parseInt(producto.categoria_id) === parseInt(c.id) ? 'selected' : ''}>
                            ${c.nombre}
                        </option>
                    `).join('')}
                </select>

                <label class="form-label">Nombre</label>
                <input id="nombreProducto" class="form-control mb-2" value="${editar ? escaparAtributo(producto.nombre) : ''}">

                <label class="form-label">Descripción</label>
                <textarea id="descripcionProducto" class="form-control mb-2" rows="2">${editar && producto.descripcion ? escaparHtml(producto.descripcion) : ''}</textarea>

                <label class="form-label">Precio</label>
                <input id="precioProducto" type="number" step="0.01" class="form-control mb-2" value="${editar ? producto.precio : '0.00'}">

                <div class="row">
                    <div class="col-6">
                        <label class="form-label">Disponible</label>
                        <select id="disponibleProducto" class="form-select mb-2">
                            <option value="1" ${editar && parseInt(producto.disponible) === 1 ? 'selected' : ''}>Sí</option>
                            <option value="0" ${editar && parseInt(producto.disponible) === 0 ? 'selected' : ''}>No</option>
                        </select>
                    </div>

                    <div class="col-6">
                        <label class="form-label">Activo</label>
                        <select id="activoProducto" class="form-select mb-2">
                            <option value="1" ${!editar || parseInt(producto.activo) === 1 ? 'selected' : ''}>Sí</option>
                            <option value="0" ${editar && parseInt(producto.activo) === 0 ? 'selected' : ''}>No</option>
                        </select>
                    </div>
                </div>

                <label class="form-label">Controla stock</label>
                <select id="controlaStockProducto" class="form-select mb-2">
                    <option value="0" ${!editar || parseInt(producto.controla_stock) === 0 ? 'selected' : ''}>No</option>
                    <option value="1" ${editar && parseInt(producto.controla_stock) === 1 ? 'selected' : ''}>Sí</option>
                </select>

                <label class="form-label">Stock mínimo</label>
                <input id="stockMinimoProducto" type="number" step="0.01" class="form-control" value="${editar ? producto.stock_minimo : '0.00'}">
            </div>
        `,
        width: 650,
        showCancelButton: true,
        confirmButtonText: 'Guardar',
        cancelButtonText: 'Cancelar',
        preConfirm: () => {
            const data = {
                id: document.getElementById('productoId').value,
                categoria_id: document.getElementById('categoriaProducto').value,
                nombre: document.getElementById('nombreProducto').value.trim(),
                descripcion: document.getElementById('descripcionProducto').value.trim(),
                precio: document.getElementById('precioProducto').value,
                disponible: document.getElementById('disponibleProducto').value,
                activo: document.getElementById('activoProducto').value,
                controla_stock: document.getElementById('controlaStockProducto').value,
                stock_minimo: document.getElementById('stockMinimoProducto').value
            };

            if (!data.categoria_id || !data.nombre) {
                Swal.showValidationMessage('Captura categoría y nombre.');
                return false;
            }

            if (parseFloat(data.precio) < 0) {
                Swal.showValidationMessage('El precio no puede ser negativo.');
                return false;
            }

            return data;
        }
    }).then(result => {
        if (!result.isConfirmed) return;
        guardarProducto(result.value);
    });
}

function guardarProducto(data) {
    const formData = new FormData();

    Object.keys(data).forEach(k => formData.append(k, data[k]));

    fetch(`${BASE_URL}/productos/guardar`, {
        method: 'POST',
        body: formData
    })
        .then(r => r.json())
        .then(data => {
            Swal.fire(data.success ? 'Listo' : 'Aviso', data.message, data.success ? 'success' : 'warning');
            cargarProductos();
        })
        .catch(error => {
            console.error(error);
            Swal.fire('Error', 'No se pudo guardar.', 'error');
        });
}

function nuevaCategoria() {
    Swal.fire({
        title: 'Nueva categoría',
        input: 'text',
        inputPlaceholder: 'Ej. Tacos, Bebidas, Postres',
        showCancelButton: true,
        confirmButtonText: 'Guardar',
        cancelButtonText: 'Cancelar',
        inputValidator: value => {
            if (!value.trim()) return 'Captura el nombre de la categoría.';
        }
    }).then(result => {
        if (!result.isConfirmed) return;

        const formData = new FormData();
        formData.append('nombre', result.value.trim());

        fetch(`${BASE_URL}/productos/guardarCategoria`, {
            method: 'POST',
            body: formData
        })
            .then(r => r.json())
            .then(data => {
                Swal.fire(data.success ? 'Listo' : 'Aviso', data.message, data.success ? 'success' : 'warning');
                cargarCategorias();
            });
    });
}

function cambiarDisponible(id, disponible) {
    const formData = new FormData();
    formData.append('id', id);
    formData.append('disponible', disponible);

    fetch(`${BASE_URL}/productos/disponible`, {
        method: 'POST',
        body: formData
    })
        .then(r => r.json())
        .then(data => {
            Swal.fire(data.success ? 'Listo' : 'Aviso', data.message, data.success ? 'success' : 'warning');
            cargarProductos();
        });
}

function cambiarActivo(id, activo) {
    const formData = new FormData();
    formData.append('id', id);
    formData.append('activo', activo);

    fetch(`${BASE_URL}/productos/estado`, {
        method: 'POST',
        body: formData
    })
        .then(r => r.json())
        .then(data => {
            Swal.fire(data.success ? 'Listo' : 'Aviso', data.message, data.success ? 'success' : 'warning');
            cargarProductos();
        });
}

function formato(v) {
    return parseFloat(v || 0).toFixed(2);
}

function escaparHtml(texto) {
    const div = document.createElement('div');
    div.textContent = texto ?? '';
    return div.innerHTML;
}

function escaparAtributo(texto) {
    return String(texto ?? '')
        .replace(/\\/g, '\\\\')
        .replace(/'/g, "\\'")
        .replace(/"/g, '&quot;');
}