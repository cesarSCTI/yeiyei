let rolesGlobal = [];
let usuariosGlobal = [];

const DIAS_SEMANA = [
    { valor: 1, nombre: 'Lunes' },
    { valor: 2, nombre: 'Martes' },
    { valor: 3, nombre: 'Miércoles' },
    { valor: 4, nombre: 'Jueves' },
    { valor: 5, nombre: 'Viernes' },
    { valor: 6, nombre: 'Sábado' },
    { valor: 0, nombre: 'Domingo' }
];

document.addEventListener('DOMContentLoaded', function () {
    Promise.all([cargarRoles(), cargarUsuarios()]).catch(error => {
        console.error(error);
    });
});

function cargarRoles() {
    return fetch(`${BASE_URL}/usuarios/roles`)
        .then(r => r.json())
        .then(data => {
            if (data.success) rolesGlobal = data.data;
        });
}

function cargarUsuarios() {
    return fetch(`${BASE_URL}/usuarios/listar`)
        .then(r => r.json())
        .then(data => {
            if (!data.success) {
                Swal.fire('Aviso', data.message, 'warning');
                return;
            }

            usuariosGlobal = data.data;
            renderUsuarios(data.data);
        })
        .catch(error => {
            console.error(error);
            Swal.fire('Error', 'No se pudieron cargar los usuarios.', 'error');
        });
}

function renderUsuarios(usuarios) {
    const contenedor = document.getElementById('contenedorUsuarios');

    if (!usuarios || usuarios.length === 0) {
        contenedor.innerHTML = `<div class="alert alert-secondary">No hay usuarios registrados.</div>`;
        return;
    }

    let html = `
        <div class="table-responsive">
            <table class="table table-sm table-hover align-middle">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Usuario</th>
                        <th>Rol</th>
                        <th>Teléfono</th>
                        <th>Días de descanso</th>
                        <th>Estado</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody>
    `;

    usuarios.forEach(u => {
        const dias = obtenerDiasUsuario(u);
        const textoDias = u.rol === 'ADMINISTRADOR'
            ? '<span class="badge bg-info text-dark">No aplica</span>'
            : dias.length > 0
                ? dias.map(d => `<span class="badge bg-secondary me-1 mb-1">${nombreDia(d)}</span>`).join('')
                : '<span class="text-muted">Sin descanso asignado</span>';

        html += `
            <tr>
                <td>${u.id}</td>
                <td>${escaparHtml(u.nombre)}</td>
                <td>${escaparHtml(u.usuario)}</td>
                <td><span class="badge bg-dark">${escaparHtml(u.rol)}</span></td>
                <td>${u.telefono ? escaparHtml(u.telefono) : '<span class="text-muted">Sin teléfono</span>'}</td>
                <td>${textoDias}</td>
                <td>
                    <span class="badge ${parseInt(u.activo) === 1 ? 'bg-success' : 'bg-secondary'}">
                        ${parseInt(u.activo) === 1 ? 'Activo' : 'Inactivo'}
                    </span>
                </td>
                <td class="text-center">
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-primary" onclick="editarUsuario(${u.id})">Editar</button>
                        <button class="btn btn-warning" onclick="cambiarPassword(${u.id})">Password</button>
                        <button class="btn ${parseInt(u.activo) === 1 ? 'btn-outline-danger' : 'btn-outline-success'}"
                            onclick="cambiarEstado(${u.id}, ${parseInt(u.activo) === 1 ? 0 : 1})">
                            ${parseInt(u.activo) === 1 ? 'Desactivar' : 'Activar'}
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });

    html += `</tbody></table></div>`;
    contenedor.innerHTML = html;
}

function nuevoUsuario() {
    abrirModalUsuario(null);
}

function editarUsuario(id) {
    const usuario = usuariosGlobal.find(u => parseInt(u.id) === parseInt(id));
    abrirModalUsuario(usuario);
}

function abrirModalUsuario(usuario) {
    const esEditar = !!usuario;
    const diasSeleccionados = esEditar ? obtenerDiasUsuario(usuario) : [];

    Swal.fire({
        title: esEditar ? 'Editar usuario' : 'Nuevo usuario',
        html: `
            <div class="text-start">
                <input type="hidden" id="usuarioId" value="${esEditar ? usuario.id : 0}">

                <label class="form-label">Nombre</label>
                <input id="nombreUsuario" class="form-control mb-2" value="${esEditar ? escaparAtributo(usuario.nombre) : ''}">

                <label class="form-label">Usuario</label>
                <input id="loginUsuario" class="form-control mb-2" value="${esEditar ? escaparAtributo(usuario.usuario) : ''}">

                <label class="form-label">Rol</label>
                <select id="rolUsuario" class="form-select mb-2" onchange="actualizarVisibilidadDescansos()">
                    ${rolesGlobal.map(r => `
                        <option value="${r.id}" data-rol="${escaparAtributo(r.nombre)}" ${esEditar && parseInt(usuario.rol_id) === parseInt(r.id) ? 'selected' : ''}>
                            ${escaparHtml(r.nombre)}
                        </option>
                    `).join('')}
                </select>

                <label class="form-label">Teléfono WhatsApp</label>
                <input id="telefonoUsuario" class="form-control mb-3" placeholder="Ej. 523323864412" value="${esEditar && usuario.telefono ? escaparAtributo(usuario.telefono) : ''}">

                <div id="bloqueDiasDescanso" class="border rounded p-3 mb-3">
                    <label class="form-label fw-bold mb-2">Días de descanso</label>
                    <div class="small text-muted mb-2">
                        En los días marcados, el usuario no podrá iniciar sesión.
                    </div>
                    <div class="row g-2">
                        ${DIAS_SEMANA.map(dia => `
                            <div class="col-6 col-sm-4">
                                <div class="form-check">
                                    <input class="form-check-input dia-descanso" type="checkbox" value="${dia.valor}" id="diaDescanso${dia.valor}"
                                        ${diasSeleccionados.includes(dia.valor) ? 'checked' : ''}>
                                    <label class="form-check-label" for="diaDescanso${dia.valor}">${dia.nombre}</label>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <div id="avisoAdminDescanso" class="alert alert-info py-2 d-none">
                    El rol ADMINISTRADOR puede ingresar todos los días. Los descansos no aplican.
                </div>

                ${!esEditar ? `
                    <label class="form-label">Contraseña</label>
                    <input id="passwordUsuario" type="password" class="form-control mb-2">
                ` : ''}
            </div>
        `,
        width: 680,
        showCancelButton: true,
        confirmButtonText: 'Guardar',
        cancelButtonText: 'Cancelar',
        didOpen: () => actualizarVisibilidadDescansos(),
        preConfirm: () => {
            const rolSelect = document.getElementById('rolUsuario');
            const rolNombre = rolSelect.options[rolSelect.selectedIndex]?.dataset.rol || '';
            const diasDescanso = rolNombre === 'ADMINISTRADOR'
                ? []
                : Array.from(document.querySelectorAll('.dia-descanso:checked')).map(x => parseInt(x.value, 10));

            const data = {
                id: document.getElementById('usuarioId').value,
                nombre: document.getElementById('nombreUsuario').value.trim(),
                usuario: document.getElementById('loginUsuario').value.trim(),
                rol_id: rolSelect.value,
                telefono: document.getElementById('telefonoUsuario').value.trim(),
                password: esEditar ? '' : document.getElementById('passwordUsuario').value.trim(),
                dias_descanso: JSON.stringify(diasDescanso)
            };

            if (!data.nombre || !data.usuario || !data.rol_id) {
                Swal.showValidationMessage('Captura nombre, usuario y rol.');
                return false;
            }

            if (!esEditar && !data.password) {
                Swal.showValidationMessage('Captura contraseña.');
                return false;
            }

            return data;
        }
    }).then(result => {
        if (!result.isConfirmed) return;
        guardarUsuario(result.value);
    });
}

function actualizarVisibilidadDescansos() {
    const rolSelect = document.getElementById('rolUsuario');
    const bloque = document.getElementById('bloqueDiasDescanso');
    const aviso = document.getElementById('avisoAdminDescanso');

    if (!rolSelect || !bloque || !aviso) return;

    const rolNombre = rolSelect.options[rolSelect.selectedIndex]?.dataset.rol || '';
    const esAdmin = rolNombre === 'ADMINISTRADOR';

    bloque.classList.toggle('d-none', esAdmin);
    aviso.classList.toggle('d-none', !esAdmin);

    if (esAdmin) {
        document.querySelectorAll('.dia-descanso').forEach(input => input.checked = false);
    }
}

function guardarUsuario(data) {
    const formData = new FormData();
    Object.keys(data).forEach(k => formData.append(k, data[k]));

    fetch(`${BASE_URL}/usuarios/guardar`, {
        method: 'POST',
        body: formData
    })
        .then(r => r.json())
        .then(data => {
            if (!data.success) {
                Swal.fire('Aviso', data.message, 'warning');
                return;
            }

            Swal.fire('Listo', data.message, 'success');
            cargarUsuarios();
        })
        .catch(error => {
            console.error(error);
            Swal.fire('Error', 'No se pudo guardar.', 'error');
        });
}

function cambiarPassword(id) {
    Swal.fire({
        title: 'Cambiar contraseña',
        input: 'password',
        inputPlaceholder: 'Nueva contraseña',
        showCancelButton: true,
        confirmButtonText: 'Actualizar',
        cancelButtonText: 'Cancelar',
        inputValidator: value => {
            if (!value) return 'Captura la nueva contraseña.';
        }
    }).then(result => {
        if (!result.isConfirmed) return;

        const formData = new FormData();
        formData.append('id', id);
        formData.append('password', result.value);

        fetch(`${BASE_URL}/usuarios/password`, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                Swal.fire(data.success ? 'Listo' : 'Aviso', data.message, data.success ? 'success' : 'warning');
            });
    });
}

function cambiarEstado(id, activo) {
    const texto = activo === 1 ? 'activar' : 'desactivar';

    Swal.fire({
        title: `¿Deseas ${texto} este usuario?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Sí',
        cancelButtonText: 'Cancelar'
    }).then(result => {
        if (!result.isConfirmed) return;

        const formData = new FormData();
        formData.append('id', id);
        formData.append('activo', activo);

        fetch(`${BASE_URL}/usuarios/estado`, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                Swal.fire(data.success ? 'Listo' : 'Aviso', data.message, data.success ? 'success' : 'warning');
                cargarUsuarios();
            });
    });
}

function obtenerDiasUsuario(usuario) {
    if (!usuario || usuario.dias_descanso === null || usuario.dias_descanso === '') return [];
    return String(usuario.dias_descanso)
        .split(',')
        .map(v => parseInt(v, 10))
        .filter(v => Number.isInteger(v) && v >= 0 && v <= 6);
}

function nombreDia(valor) {
    return DIAS_SEMANA.find(d => d.valor === parseInt(valor, 10))?.nombre || '';
}

function escaparHtml(texto) {
    const div = document.createElement('div');
    div.textContent = texto ?? '';
    return div.innerHTML;
}

function escaparAtributo(texto) {
    return String(texto ?? '')
        .replace(/\\/g, '\\\\')
        .replace(/'/g, "\\'")
        .replace(/"/g, '&quot;');
}
