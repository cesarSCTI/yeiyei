<?php

class Egreso extends Model
{
    public function registrar($usuarioId, $concepto, $monto, $descripcion, $fecha)
    {
        $sql = "INSERT INTO egresos
                (usuario_id, concepto, monto, descripcion, fecha)
                VALUES (?, ?, ?, ?, ?)";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            $usuarioId,
            $concepto,
            $monto,
            $descripcion,
            $fecha
        ]);
    }

    public function listarPorFecha($fecha)
    {
        $sql = "SELECT
                    e.*,
                    u.nombre AS usuario
                FROM egresos e
                INNER JOIN usuarios u ON u.id = e.usuario_id
                WHERE e.fecha = ?
                ORDER BY e.id DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$fecha]);

        return $stmt->fetchAll();
    }

    public function totalPorFecha($fecha)
    {
        $sql = "SELECT IFNULL(SUM(monto), 0) AS total
                FROM egresos
                WHERE fecha = ?";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$fecha]);

        $row = $stmt->fetch();

        return $row ? floatval($row['total']) : 0;
    }
}