<?php

class PedidoDetalle extends Model
{
    public function listarPorPedido($pedidoId)
    {
        $sql = "SELECT 
                    pd.id,
                    pd.pedido_id,
                    pd.producto_id,
                    pd.cantidad,
                    pd.precio_unitario,
                    pd.subtotal_original,
                    pd.descuento_tipo,
                    pd.descuento_valor,
                    pd.descuento_importe,
                    pd.subtotal,
                    pd.notas,
                    pd.estado,
                    p.nombre AS producto,
                    c.nombre AS categoria
                FROM pedido_detalle pd
                INNER JOIN productos p ON p.id = pd.producto_id
                INNER JOIN categorias c ON c.id = p.categoria_id
                WHERE pd.pedido_id = ?
                AND pd.estado <> 'CANCELADO'
                ORDER BY pd.id DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$pedidoId]);

        return $stmt->fetchAll();
    }

    public function agregar(
        $pedidoId,
        $productoId,
        $cantidad,
        $precioUnitario,
        $notas = null,
        $descuentoTipo = 'NINGUNO',
        $descuentoValor = 0
    ) {
        $subtotalOriginal = round($cantidad * $precioUnitario, 2);
        $descuentoValor = round((float)$descuentoValor, 2);
        $descuentoImporte = 0.00;

        if ($descuentoTipo === 'PORCENTAJE') {
            $descuentoImporte = round($subtotalOriginal * ($descuentoValor / 100), 2);
        } elseif ($descuentoTipo === 'MONTO') {
            $descuentoImporte = min($descuentoValor, $subtotalOriginal);
        } else {
            $descuentoTipo = 'NINGUNO';
            $descuentoValor = 0.00;
        }

        $subtotalFinal = max(round($subtotalOriginal - $descuentoImporte, 2), 0);

        $sql = "INSERT INTO pedido_detalle
                (pedido_id, producto_id, cantidad, precio_unitario,
                 subtotal_original, descuento_tipo, descuento_valor,
                 descuento_importe, subtotal, notas, estado)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDIENTE')";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            $pedidoId,
            $productoId,
            $cantidad,
            $precioUnitario,
            $subtotalOriginal,
            $descuentoTipo,
            $descuentoValor,
            $descuentoImporte,
            $subtotalFinal,
            $notas
        ]);
    }

    public function listarCocina()
    {
        $sql = "SELECT 
                    pd.id,
                    pd.pedido_id,
                    pd.producto_id,
                    pd.cantidad,
                    pd.notas,
                    pd.estado,
                    pd.created_at,
                    p.nombre AS producto,
                    c.nombre AS categoria,
                    pe.id AS pedido_id,
                    pe.estado AS pedido_estado,
                    m.nombre AS mesa,
                    u.nombre AS mesero
                FROM pedido_detalle pd
                INNER JOIN productos p ON p.id = pd.producto_id
                INNER JOIN categorias c ON c.id = p.categoria_id
                INNER JOIN pedidos pe ON pe.id = pd.pedido_id
                INNER JOIN mesas m ON m.id = pe.mesa_id
                INNER JOIN usuarios u ON u.id = pe.usuario_mesero_id
                WHERE pe.estado IN ('ENVIADO_COCINA','EN_PREPARACION','LISTO','ENTREGADO')
                AND pd.estado NOT IN ('CANCELADO','ENTREGADO')
                AND LOWER(TRIM(c.nombre)) NOT IN ('bebida','bebidas','refresco','refrescos','jugo','jugos','agua','aguas')
                ORDER BY pe.id ASC, pd.created_at ASC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    /**
     * Detalle exclusivo para la comanda de cocina.
     * Excluye bebidas para que refrescos, jugos y aguas no se impriman
     * en la impresora de cocina, pero sigan apareciendo en cuenta y ticket.
     */
    public function listarParaComandaCocina($pedidoId)
    {
        $sql = "SELECT
                    pd.id,
                    pd.pedido_id,
                    pd.producto_id,
                    pd.cantidad,
                    pd.precio_unitario,
                    pd.subtotal_original,
                    pd.descuento_tipo,
                    pd.descuento_valor,
                    pd.descuento_importe,
                    pd.subtotal,
                    pd.notas,
                    pd.estado,
                    p.nombre AS producto,
                    c.nombre AS categoria
                FROM pedido_detalle pd
                INNER JOIN productos p ON p.id = pd.producto_id
                INNER JOIN categorias c ON c.id = p.categoria_id
                WHERE pd.pedido_id = ?
                  AND pd.estado NOT IN ('CANCELADO', 'ENTREGADO')
                  AND LOWER(TRIM(c.nombre)) NOT IN ('bebida','bebidas','refresco','refrescos','jugo','jugos','agua','aguas')
                ORDER BY pd.id ASC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$pedidoId]);

        return $stmt->fetchAll();
    }

    public function cambiarEstado($detalleId, $estado)
    {
        $sql = "UPDATE pedido_detalle
                SET estado = ?
                WHERE id = ?";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([$estado, $detalleId]);
    }


    /**
     * Devuelve en una sola consulta los productos de varios pedidos.
     * Se usa en Caja para mostrar el detalle antes de cobrar sin hacer
     * una petición adicional por cada tarjeta.
     */
    public function listarParaPedidos(array $pedidoIds)
    {
        $pedidoIds = array_values(array_filter(array_map('intval', $pedidoIds), function ($id) {
            return $id > 0;
        }));

        if (empty($pedidoIds)) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($pedidoIds), '?'));

        $sql = "SELECT
                    pd.id,
                    pd.pedido_id,
                    pd.producto_id,
                    pd.cantidad,
                    pd.precio_unitario,
                    pd.subtotal_original,
                    pd.descuento_tipo,
                    pd.descuento_valor,
                    pd.descuento_importe,
                    pd.subtotal,
                    pd.notas,
                    pd.estado,
                    p.nombre AS producto
                FROM pedido_detalle pd
                INNER JOIN productos p ON p.id = pd.producto_id
                WHERE pd.pedido_id IN ($placeholders)
                  AND pd.estado <> 'CANCELADO'
                ORDER BY pd.pedido_id ASC, pd.id ASC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($pedidoIds);

        $agrupados = [];

        foreach ($stmt->fetchAll() as $item) {
            $pedidoId = (int)$item['pedido_id'];

            if (!isset($agrupados[$pedidoId])) {
                $agrupados[$pedidoId] = [];
            }

            $agrupados[$pedidoId][] = $item;
        }

        return $agrupados;
    }
}
