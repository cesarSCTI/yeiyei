<?php

class Pedido extends Model
{
    public function obtenerActivoPorMesa($mesaId)
    {
        $sql = "SELECT *
                FROM pedidos
                WHERE mesa_id = ?
                AND estado NOT IN ('COBRADO','CANCELADO')
                ORDER BY id DESC
                LIMIT 1";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$mesaId]);

        return $stmt->fetch();
    }

    public function crear($mesaId, $usuarioMeseroId, $clienteNombre = null)
    {
        $sql = "INSERT INTO pedidos
                (mesa_id, usuario_mesero_id, cliente_nombre, estado, total)
                VALUES (?, ?, ?, 'ABIERTO', 0.00)";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            $mesaId,
            $usuarioMeseroId,
            $clienteNombre
        ]);

        return $this->db->lastInsertId();
    }

    /**
     * Crea el pedido solamente al agregar el primer producto.
     * La mesa permanece LIBRE si el usuario entra y regresa sin consumir.
     */
    public function agregarProductoEnMesa(
        $mesaId,
        $usuarioMeseroId,
        $productoId,
        $cantidad,
        $precioUnitario,
        $notas = null,
        $descuentoTipo = 'NINGUNO',
        $descuentoValor = 0
    ) {
        $subtotalOriginal = round($cantidad * $precioUnitario, 2);
        $descuentoValor = round((float)$descuentoValor, 2);
        $descuentoImporte = 0.00;

        if ($descuentoTipo === 'PORCENTAJE') {
            $descuentoImporte = round($subtotalOriginal * ($descuentoValor / 100), 2);
        } elseif ($descuentoTipo === 'MONTO') {
            $descuentoImporte = min($descuentoValor, $subtotalOriginal);
        } else {
            $descuentoTipo = 'NINGUNO';
            $descuentoValor = 0.00;
        }

        $subtotalFinal = max(round($subtotalOriginal - $descuentoImporte, 2), 0);

        $this->db->beginTransaction();

        try {
            // Bloquea la mesa mientras se resuelve/crea el pedido activo.
            $stmtMesa = $this->db->prepare(
                "SELECT id, activo
                 FROM mesas
                 WHERE id = ?
                 FOR UPDATE"
            );
            $stmtMesa->execute([$mesaId]);
            $mesa = $stmtMesa->fetch();

            if (!$mesa || (int)$mesa['activo'] !== 1) {
                throw new RuntimeException('Mesa no disponible.');
            }

            $stmtPedido = $this->db->prepare(
                "SELECT id
                 FROM pedidos
                 WHERE mesa_id = ?
                 AND estado NOT IN ('COBRADO','CANCELADO')
                 ORDER BY id DESC
                 LIMIT 1
                 FOR UPDATE"
            );
            $stmtPedido->execute([$mesaId]);
            $pedido = $stmtPedido->fetch();

            if ($pedido) {
                $pedidoId = (int)$pedido['id'];
            } else {
                $stmtCrear = $this->db->prepare(
                    "INSERT INTO pedidos
                     (mesa_id, usuario_mesero_id, cliente_nombre, estado, total)
                     VALUES (?, ?, NULL, 'ABIERTO', 0.00)"
                );
                $stmtCrear->execute([$mesaId, $usuarioMeseroId]);
                $pedidoId = (int)$this->db->lastInsertId();
            }

            $stmtDetalle = $this->db->prepare(
                "INSERT INTO pedido_detalle
                 (pedido_id, producto_id, cantidad, precio_unitario,
                  subtotal_original, descuento_tipo, descuento_valor,
                  descuento_importe, subtotal, notas, estado)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDIENTE')"
            );

            $stmtDetalle->execute([
                $pedidoId,
                $productoId,
                $cantidad,
                $precioUnitario,
                $subtotalOriginal,
                $descuentoTipo,
                $descuentoValor,
                $descuentoImporte,
                $subtotalFinal,
                $notas
            ]);

            $stmtTotal = $this->db->prepare(
                "UPDATE pedidos p
                 SET total = (
                     SELECT IFNULL(SUM(subtotal), 0)
                     FROM pedido_detalle
                     WHERE pedido_id = p.id
                     AND estado <> 'CANCELADO'
                 )
                 WHERE p.id = ?"
            );
            $stmtTotal->execute([$pedidoId]);

            $stmtOcupar = $this->db->prepare(
                "UPDATE mesas SET estado = 'OCUPADA' WHERE id = ?"
            );
            $stmtOcupar->execute([$mesaId]);

            $this->db->commit();

            return [
                'pedido_id' => $pedidoId,
                'detalle_id' => (int)$this->db->lastInsertId()
            ];
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            return false;
        }
    }

    public function contarDetalles($pedidoId)
    {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) AS total
             FROM pedido_detalle
             WHERE pedido_id = ?"
        );
        $stmt->execute([$pedidoId]);
        $row = $stmt->fetch();

        return (int)($row['total'] ?? 0);
    }

    public function contarDetallesActivos($pedidoId)
    {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) AS total
             FROM pedido_detalle
             WHERE pedido_id = ?
             AND estado <> 'CANCELADO'"
        );
        $stmt->execute([$pedidoId]);
        $row = $stmt->fetch();

        return (int)($row['total'] ?? 0);
    }

    /**
     * Limpia pedidos vacíos heredados de la versión anterior.
     * Solo toma pedidos con al menos 5 minutos de antigüedad para evitar
     * interferir con usuarios que todavía tengan una versión anterior abierta.
     */
    public function liberarPedidosVaciosAntiguos()
    {
        $this->db->beginTransaction();

        try {
            $sql = "SELECT p.id, p.mesa_id
                    FROM pedidos p
                    LEFT JOIN pedido_detalle pd
                        ON pd.pedido_id = p.id
                        AND pd.estado <> 'CANCELADO'
                    WHERE p.estado NOT IN ('COBRADO','CANCELADO')
                    AND p.created_at < (NOW() - INTERVAL 1 MINUTE)
                    GROUP BY p.id, p.mesa_id
                    HAVING COUNT(pd.id) = 0";

            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            $vacios = $stmt->fetchAll();

            foreach ($vacios as $vacio) {
                $stmtCancelar = $this->db->prepare(
                    "UPDATE pedidos
                     SET estado = 'CANCELADO', fecha_cierre = NOW()
                     WHERE id = ?"
                );
                $stmtCancelar->execute([$vacio['id']]);

                $stmtMesa = $this->db->prepare(
                    "UPDATE mesas m
                     SET m.estado = 'LIBRE'
                     WHERE m.id = ?
                     AND NOT EXISTS (
                         SELECT 1
                         FROM pedidos p2
                         WHERE p2.mesa_id = m.id
                         AND p2.estado NOT IN ('COBRADO','CANCELADO')
                     )"
                );
                $stmtMesa->execute([$vacio['mesa_id']]);
            }

            $this->db->commit();
            return true;
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            return false;
        }
    }

    public function actualizarTotal($pedidoId)
    {
        if ($pedidoId <= 0) {
            return true;
        }

        $sql = "UPDATE pedidos p
                SET total = (
                    SELECT IFNULL(SUM(subtotal), 0)
                    FROM pedido_detalle
                    WHERE pedido_id = p.id
                    AND estado <> 'CANCELADO'
                )
                WHERE p.id = ?";

        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$pedidoId]);
    }

    public function cambiarEstado($pedidoId, $estado)
    {
        $sql = "UPDATE pedidos
                SET estado = ?
                WHERE id = ?";

        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$estado, $pedidoId]);
    }

    public function obtenerPorId($pedidoId)
    {
        $sql = "SELECT 
                    p.*,
                    m.nombre AS mesa,
                    u.nombre AS mesero
                FROM pedidos p
                INNER JOIN mesas m ON m.id = p.mesa_id
                INNER JOIN usuarios u ON u.id = p.usuario_mesero_id
                WHERE p.id = ?
                LIMIT 1";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$pedidoId]);

        return $stmt->fetch();
    }

    public function listarMesasDisponiblesParaMover($mesaOrigenId)
    {
        $sql = "SELECT m.id, m.nombre, m.descripcion
                FROM mesas m
                WHERE m.activo = 1
                AND m.estado = 'LIBRE'
                AND m.id <> ?
                AND NOT EXISTS (
                    SELECT 1
                    FROM pedidos p
                    WHERE p.mesa_id = m.id
                    AND p.estado NOT IN ('COBRADO','CANCELADO')
                )
                ORDER BY m.id ASC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$mesaOrigenId]);

        return $stmt->fetchAll();
    }

    /**
     * Mueve el pedido activo completo de una mesa a otra.
     * Los detalles no se actualizan porque dependen del pedido, no de la mesa.
     */
    public function moverAMesa($pedidoId, $mesaDestinoId, $usuarioId)
    {
        $this->db->beginTransaction();

        try {
            $stmtPedido = $this->db->prepare(
                "SELECT p.id, p.mesa_id, p.estado, mo.nombre AS mesa_origen,
                        mo.estado AS estado_mesa_origen
                 FROM pedidos p
                 INNER JOIN mesas mo ON mo.id = p.mesa_id
                 WHERE p.id = ?
                 AND p.estado NOT IN ('COBRADO','CANCELADO')
                 FOR UPDATE"
            );
            $stmtPedido->execute([$pedidoId]);
            $pedido = $stmtPedido->fetch();

            if (!$pedido) {
                throw new RuntimeException('El pedido no existe o ya no está activo.');
            }

            $mesaOrigenId = (int)$pedido['mesa_id'];

            if ($mesaOrigenId === (int)$mesaDestinoId) {
                throw new RuntimeException('La mesa destino debe ser diferente.');
            }

            $stmtDestino = $this->db->prepare(
                "SELECT id, nombre, activo, estado
                 FROM mesas
                 WHERE id = ?
                 FOR UPDATE"
            );
            $stmtDestino->execute([$mesaDestinoId]);
            $destino = $stmtDestino->fetch();

            if (!$destino || (int)$destino['activo'] !== 1) {
                throw new RuntimeException('La mesa destino no está disponible.');
            }

            if ($destino['estado'] !== 'LIBRE') {
                throw new RuntimeException('La mesa destino ya no está libre.');
            }

            $stmtPedidoDestino = $this->db->prepare(
                "SELECT id
                 FROM pedidos
                 WHERE mesa_id = ?
                 AND estado NOT IN ('COBRADO','CANCELADO')
                 LIMIT 1
                 FOR UPDATE"
            );
            $stmtPedidoDestino->execute([$mesaDestinoId]);

            if ($stmtPedidoDestino->fetch()) {
                throw new RuntimeException('La mesa destino ya tiene un pedido activo.');
            }

            $stmtMover = $this->db->prepare(
                "UPDATE pedidos
                 SET mesa_id = ?
                 WHERE id = ?"
            );
            $stmtMover->execute([$mesaDestinoId, $pedidoId]);

            $estadoDestino = $pedido['estado_mesa_origen'] === 'CUENTA_SOLICITADA'
                ? 'CUENTA_SOLICITADA'
                : 'OCUPADA';

            $stmtOcupar = $this->db->prepare(
                "UPDATE mesas
                 SET estado = ?
                 WHERE id = ?"
            );
            $stmtOcupar->execute([$estadoDestino, $mesaDestinoId]);

            $stmtLiberar = $this->db->prepare(
                "UPDATE mesas
                 SET estado = 'LIBRE'
                 WHERE id = ?"
            );
            $stmtLiberar->execute([$mesaOrigenId]);

            // Historial de control. Si la tabla existe, el movimiento queda auditado.
            $stmtHistorial = $this->db->prepare(
                "INSERT INTO historial_movimientos
                 (usuario_id, modulo, accion, descripcion, referencia_id)
                 VALUES (?, 'PEDIDOS', 'MOVER_MESA', ?, ?)"
            );
            $descripcion = 'Pedido #' . $pedidoId
                . ' movido de ' . $pedido['mesa_origen']
                . ' a ' . $destino['nombre'];
            $stmtHistorial->execute([$usuarioId, $descripcion, $pedidoId]);

            $this->db->commit();

            return [
                'pedido_id' => (int)$pedidoId,
                'mesa_origen_id' => $mesaOrigenId,
                'mesa_destino_id' => (int)$mesaDestinoId,
                'mesa_destino' => $destino['nombre']
            ];
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            return [
                'error' => $e->getMessage()
            ];
        }
    }

    public function listarMesasParaMoverProductos($mesaOrigenId)
    {
        $sql = "SELECT
                    m.id,
                    m.nombre,
                    m.descripcion,
                    m.estado,
                    p.id AS pedido_activo_id,
                    p.total AS pedido_total
                FROM mesas m
                LEFT JOIN pedidos p
                    ON p.id = (
                        SELECT p2.id
                        FROM pedidos p2
                        WHERE p2.mesa_id = m.id
                          AND p2.estado NOT IN ('COBRADO','CANCELADO')
                        ORDER BY p2.id DESC
                        LIMIT 1
                    )
                WHERE m.activo = 1
                  AND m.id <> ?
                  AND m.estado IN ('LIBRE','OCUPADA')
                ORDER BY m.id ASC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$mesaOrigenId]);

        return $stmt->fetchAll();
    }

    /**
     * Mueve uno o varios renglones, incluso cantidades parciales, a otra mesa.
     * Si la mesa destino está libre crea un pedido; si está ocupada agrega al
     * pedido activo. Inventario no se altera porque no existe una venta nueva.
     */
    public function moverProductosAMesa($pedidoOrigenId, $mesaDestinoId, array $movimientos, $usuarioId)
    {
        $this->db->beginTransaction();

        try {
            $stmtOrigen = $this->db->prepare(
                "SELECT p.id, p.mesa_id, p.estado, m.nombre AS mesa_origen
                 FROM pedidos p
                 INNER JOIN mesas m ON m.id = p.mesa_id
                 WHERE p.id = ?
                   AND p.estado NOT IN ('COBRADO','CANCELADO')
                 FOR UPDATE"
            );
            $stmtOrigen->execute([$pedidoOrigenId]);
            $pedidoOrigen = $stmtOrigen->fetch();

            if (!$pedidoOrigen) {
                throw new RuntimeException('El pedido origen no existe o ya fue cerrado.');
            }

            $mesaOrigenId = (int)$pedidoOrigen['mesa_id'];
            if ($mesaOrigenId === (int)$mesaDestinoId) {
                throw new RuntimeException('Selecciona una mesa destino diferente.');
            }

            $stmtMesaDestino = $this->db->prepare(
                "SELECT id, nombre, activo, estado
                 FROM mesas
                 WHERE id = ?
                 FOR UPDATE"
            );
            $stmtMesaDestino->execute([$mesaDestinoId]);
            $mesaDestino = $stmtMesaDestino->fetch();

            if (!$mesaDestino || (int)$mesaDestino['activo'] !== 1) {
                throw new RuntimeException('La mesa destino no está disponible.');
            }

            if (!in_array($mesaDestino['estado'], ['LIBRE', 'OCUPADA'], true)) {
                throw new RuntimeException('La mesa destino ya solicitó cuenta o no está disponible.');
            }

            $stmtPedidoDestino = $this->db->prepare(
                "SELECT id, estado
                 FROM pedidos
                 WHERE mesa_id = ?
                   AND estado NOT IN ('COBRADO','CANCELADO')
                 ORDER BY id DESC
                 LIMIT 1
                 FOR UPDATE"
            );
            $stmtPedidoDestino->execute([$mesaDestinoId]);
            $pedidoDestino = $stmtPedidoDestino->fetch();

            if ($mesaDestino['estado'] === 'OCUPADA' && !$pedidoDestino) {
                throw new RuntimeException('La mesa destino figura ocupada pero no tiene un pedido activo.');
            }

            if ($pedidoDestino) {
                $pedidoDestinoId = (int)$pedidoDestino['id'];
            } else {
                $stmtCrear = $this->db->prepare(
                    "INSERT INTO pedidos
                     (mesa_id, usuario_mesero_id, cliente_nombre, estado, total)
                     VALUES (?, ?, NULL, 'ABIERTO', 0.00)"
                );
                $stmtCrear->execute([$mesaDestinoId, $usuarioId]);
                $pedidoDestinoId = (int)$this->db->lastInsertId();
            }

            $ids = array_keys($movimientos);
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $params = array_merge([$pedidoOrigenId], $ids);

            $stmtDetalles = $this->db->prepare(
                "SELECT *
                 FROM pedido_detalle
                 WHERE pedido_id = ?
                   AND id IN ($placeholders)
                   AND estado <> 'CANCELADO'
                 FOR UPDATE"
            );
            $stmtDetalles->execute($params);
            $detalles = $stmtDetalles->fetchAll();

            if (count($detalles) !== count($ids)) {
                throw new RuntimeException('Uno o más productos ya no están disponibles para mover.');
            }

            $cantidadTotalMovida = 0;
            $descripcionItems = [];
            $requiereCocina = false;

            foreach ($detalles as $detalle) {
                $detalleId = (int)$detalle['id'];
                $cantidadOriginal = (int)$detalle['cantidad'];
                $cantidadMover = (int)$movimientos[$detalleId];

                if ($cantidadMover <= 0 || $cantidadMover > $cantidadOriginal) {
                    throw new RuntimeException('La cantidad seleccionada para mover no es válida.');
                }

                $cantidadTotalMovida += $cantidadMover;
                $descripcionItems[] = $cantidadMover . ' unidad(es) del detalle #' . $detalleId;

                if ($detalle['estado'] !== 'PENDIENTE') {
                    $requiereCocina = true;
                }

                if ($cantidadMover === $cantidadOriginal) {
                    $stmtMoverCompleto = $this->db->prepare(
                        "UPDATE pedido_detalle
                         SET pedido_id = ?
                         WHERE id = ?"
                    );
                    $stmtMoverCompleto->execute([$pedidoDestinoId, $detalleId]);
                    continue;
                }

                $factor = $cantidadMover / $cantidadOriginal;
                $originalMover = round((float)$detalle['subtotal_original'] * $factor, 2);
                $descuentoMover = round((float)$detalle['descuento_importe'] * $factor, 2);
                $subtotalMover = round((float)$detalle['subtotal'] * $factor, 2);

                $originalRestante = round((float)$detalle['subtotal_original'] - $originalMover, 2);
                $descuentoRestante = round((float)$detalle['descuento_importe'] - $descuentoMover, 2);
                $subtotalRestante = round((float)$detalle['subtotal'] - $subtotalMover, 2);
                $cantidadRestante = $cantidadOriginal - $cantidadMover;

                $tipoDescuento = $detalle['descuento_tipo'];
                $valorMover = (float)$detalle['descuento_valor'];
                $valorRestante = (float)$detalle['descuento_valor'];

                if ($tipoDescuento === 'MONTO') {
                    $valorMover = $descuentoMover;
                    $valorRestante = $descuentoRestante;
                }

                $stmtReducir = $this->db->prepare(
                    "UPDATE pedido_detalle
                     SET cantidad = ?,
                         subtotal_original = ?,
                         descuento_valor = ?,
                         descuento_importe = ?,
                         subtotal = ?
                     WHERE id = ?"
                );
                $stmtReducir->execute([
                    $cantidadRestante,
                    $originalRestante,
                    $valorRestante,
                    $descuentoRestante,
                    $subtotalRestante,
                    $detalleId
                ]);

                $stmtInsertar = $this->db->prepare(
                    "INSERT INTO pedido_detalle
                     (pedido_id, producto_id, cantidad, precio_unitario,
                      subtotal_original, descuento_tipo, descuento_valor,
                      descuento_importe, subtotal, notas, estado)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                );
                $stmtInsertar->execute([
                    $pedidoDestinoId,
                    $detalle['producto_id'],
                    $cantidadMover,
                    $detalle['precio_unitario'],
                    $originalMover,
                    $tipoDescuento,
                    $valorMover,
                    $descuentoMover,
                    $subtotalMover,
                    $detalle['notas'],
                    $detalle['estado']
                ]);
            }

            $stmtRecalcular = $this->db->prepare(
                "UPDATE pedidos p
                 SET total = (
                     SELECT IFNULL(SUM(pd.subtotal), 0)
                     FROM pedido_detalle pd
                     WHERE pd.pedido_id = p.id
                       AND pd.estado <> 'CANCELADO'
                 )
                 WHERE p.id IN (?, ?)"
            );
            $stmtRecalcular->execute([$pedidoOrigenId, $pedidoDestinoId]);

            $stmtRestantes = $this->db->prepare(
                "SELECT COUNT(*) AS total
                 FROM pedido_detalle
                 WHERE pedido_id = ?
                   AND estado <> 'CANCELADO'"
            );
            $stmtRestantes->execute([$pedidoOrigenId]);
            $restantes = (int)($stmtRestantes->fetch()['total'] ?? 0);

            if ($restantes === 0) {
                $stmtCerrarOrigen = $this->db->prepare(
                    "UPDATE pedidos SET estado = 'CANCELADO', total = 0 WHERE id = ?"
                );
                $stmtCerrarOrigen->execute([$pedidoOrigenId]);

                $stmtLiberar = $this->db->prepare(
                    "UPDATE mesas SET estado = 'LIBRE' WHERE id = ?"
                );
                $stmtLiberar->execute([$mesaOrigenId]);
            }

            $stmtOcupar = $this->db->prepare(
                "UPDATE mesas SET estado = 'OCUPADA' WHERE id = ?"
            );
            $stmtOcupar->execute([$mesaDestinoId]);

            if ($requiereCocina) {
                $stmtEstadoDestino = $this->db->prepare(
                    "UPDATE pedidos
                     SET estado = CASE
                         WHEN estado = 'ABIERTO' THEN 'ENVIADO_COCINA'
                         ELSE estado
                     END
                     WHERE id = ?"
                );
                $stmtEstadoDestino->execute([$pedidoDestinoId]);
            }

            $stmtHistorial = $this->db->prepare(
                "INSERT INTO historial_movimientos
                 (usuario_id, modulo, accion, descripcion, referencia_id)
                 VALUES (?, 'PEDIDOS', 'MOVER_PRODUCTOS', ?, ?)"
            );
            $descripcion = 'Productos movidos del pedido #' . $pedidoOrigenId
                . ' (' . $pedidoOrigen['mesa_origen'] . ') al pedido #' . $pedidoDestinoId
                . ' (' . $mesaDestino['nombre'] . '): ' . implode(', ', $descripcionItems);
            $stmtHistorial->execute([$usuarioId, $descripcion, $pedidoOrigenId]);

            $this->db->commit();

            return [
                'pedido_origen_id' => (int)$pedidoOrigenId,
                'pedido_destino_id' => $pedidoDestinoId,
                'mesa_origen_id' => $mesaOrigenId,
                'mesa_destino_id' => (int)$mesaDestinoId,
                'mesa_destino' => $mesaDestino['nombre'],
                'cantidad_movida' => $cantidadTotalMovida,
                'pedido_origen_vacio' => $restantes === 0
            ];
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            return ['error' => $e->getMessage()];
        }
    }

    public function listarParaCaja()
    {
        $sql = "SELECT 
                    p.id,
                    p.mesa_id,
                    p.total,
                    p.estado,
                    p.created_at,
                    m.nombre AS mesa,
                    u.nombre AS mesero
                FROM pedidos p
                INNER JOIN mesas m ON m.id = p.mesa_id
                INNER JOIN usuarios u ON u.id = p.usuario_mesero_id
                WHERE p.estado NOT IN ('COBRADO','CANCELADO')
                AND m.estado = 'CUENTA_SOLICITADA'
                ORDER BY p.id ASC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll();
    }
}
