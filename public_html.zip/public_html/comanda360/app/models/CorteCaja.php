<?php

class CorteCaja extends Model
{
    public function resumenDia($fecha)
    {
        /*
         * El campo efectivo registra el dinero recibido. Cuando existe cambio,
         * este debe restarse para obtener el efectivo real que permanece en caja.
         * El total de ingresos se calcula con los métodos de pago netos para que
         * siempre sea consistente con efectivo + tarjeta + transferencia.
         */
        $sql = "SELECT
                    IFNULL(SUM(GREATEST(efectivo - cambio, 0)), 0) AS efectivo,
                    IFNULL(SUM(tarjeta), 0) AS tarjeta,
                    IFNULL(SUM(transferencia), 0) AS transferencia,
                    IFNULL(SUM(
                        GREATEST(efectivo - cambio, 0)
                        + tarjeta
                        + transferencia
                    ), 0) AS total_ingresos
                FROM pagos
                WHERE DATE(created_at) = ?";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$fecha]);

        return $stmt->fetch();
    }

    public function totalEgresosDia($fecha)
    {
        $sql = "SELECT IFNULL(SUM(monto), 0) AS total_egresos
                FROM egresos
                WHERE fecha = ?";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$fecha]);

        $row = $stmt->fetch();

        return $row ? $row['total_egresos'] : 0;
    }

    public function guardar($usuarioId, $fecha, $efectivo, $tarjeta, $transferencia, $totalIngresos, $totalEgresos, $totalFinal, $observaciones)
    {
        $sql = "INSERT INTO cortes_caja
                (usuario_id, fecha, efectivo, tarjeta, transferencia, total_ingresos, total_egresos, total_final, observaciones)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            $usuarioId,
            $fecha,
            $efectivo,
            $tarjeta,
            $transferencia,
            $totalIngresos,
            $totalEgresos,
            $totalFinal,
            $observaciones
        ]);
    }

    public function existeCorteFecha($fecha)
    {
        $sql = "SELECT id
                FROM cortes_caja
                WHERE fecha = ?
                LIMIT 1";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$fecha]);

        return $stmt->fetch();
    }

    public function historial()
    {
        $sql = "SELECT
                    c.*,
                    u.nombre AS usuario
                FROM cortes_caja c
                INNER JOIN usuarios u ON u.id = c.usuario_id
                ORDER BY c.fecha DESC, c.id DESC
                LIMIT 30";

        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll();
    }
}
