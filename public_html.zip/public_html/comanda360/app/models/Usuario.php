<?php

class Usuario extends Model
{
    public function obtenerPorUsuario($usuario)
    {
        $sql = "SELECT 
                    u.*,
                    r.nombre AS rol
                FROM usuarios u
                INNER JOIN roles r ON r.id = u.rol_id
                WHERE u.usuario = ?
                LIMIT 1";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$usuario]);

        return $stmt->fetch();
    }

    public function esDiaDescanso($usuarioId, $diaSemana)
    {
        $sql = "SELECT id
                FROM usuario_dias_descanso
                WHERE usuario_id = ?
                  AND dia_semana = ?
                LIMIT 1";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$usuarioId, $diaSemana]);

        return (bool) $stmt->fetch();
    }
}
