<?php

class Inventario extends Model
{
    public function listarProductos()
    {
        $sql = "SELECT 
                    p.id,
                    p.nombre,
                    p.precio,
                    p.controla_stock,
                    p.stock_actual,
                    p.stock_minimo,
                    c.nombre AS categoria
                FROM productos p
                INNER JOIN categorias c ON c.id = p.categoria_id
                WHERE p.activo = 1
                ORDER BY c.nombre ASC, p.nombre ASC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function movimiento($productoId, $usuarioId, $tipo, $cantidad, $motivo, $referencia = null)
    {
        $this->db->beginTransaction();

        try {
            $stmt = $this->db->prepare("SELECT stock_actual FROM productos WHERE id = ? FOR UPDATE");
            $stmt->execute([$productoId]);
            $producto = $stmt->fetch();

            if (!$producto) {
                $this->db->rollBack();
                return false;
            }

            $stockAnterior = floatval($producto['stock_actual']);
            $cantidad = floatval($cantidad);

            if ($tipo === 'ENTRADA') {
                $stockNuevo = $stockAnterior + $cantidad;
            } elseif ($tipo === 'SALIDA') {
                $stockNuevo = $stockAnterior - $cantidad;
            } else {
                $stockNuevo = $cantidad;
            }

            if ($stockNuevo < 0) {
                $this->db->rollBack();
                return false;
            }

            $stmtUpdate = $this->db->prepare("
                UPDATE productos
                SET stock_actual = ?
                WHERE id = ?
            ");
            $stmtUpdate->execute([$stockNuevo, $productoId]);

            $stmtMov = $this->db->prepare("
                INSERT INTO inventario_movimientos
                (producto_id, usuario_id, tipo, cantidad, stock_anterior, stock_nuevo, motivo, referencia)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmtMov->execute([
                $productoId,
                $usuarioId,
                $tipo,
                $cantidad,
                $stockAnterior,
                $stockNuevo,
                $motivo,
                $referencia
            ]);

            $this->db->commit();
            return true;

        } catch (Exception $e) {
            $this->db->rollBack();
            return false;
        }
    }

    public function actualizarConfig($productoId, $controlaStock, $stockMinimo)
    {
        $sql = "UPDATE productos
                SET controla_stock = ?, stock_minimo = ?
                WHERE id = ?";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            $controlaStock,
            $stockMinimo,
            $productoId
        ]);
    }

    public function historial($productoId = 0)
    {
        $params = [];

        $where = "";

        if ($productoId > 0) {
            $where = "WHERE im.producto_id = ?";
            $params[] = $productoId;
        }

        $sql = "SELECT
                    im.*,
                    p.nombre AS producto,
                    u.nombre AS usuario
                FROM inventario_movimientos im
                INNER JOIN productos p ON p.id = im.producto_id
                INNER JOIN usuarios u ON u.id = im.usuario_id
                $where
                ORDER BY im.id DESC
                LIMIT 100";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);

        return $stmt->fetchAll();
    }

    public function descontarPorPedido($pedidoId, $usuarioId)
    {
        $sql = "SELECT
                    pd.producto_id,
                    SUM(pd.cantidad) AS cantidad
                FROM pedido_detalle pd
                INNER JOIN productos p ON p.id = pd.producto_id
                WHERE pd.pedido_id = ?
                AND pd.estado <> 'CANCELADO'
                AND p.controla_stock = 1
                GROUP BY pd.producto_id";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$pedidoId]);

        $items = $stmt->fetchAll();

        foreach ($items as $item) {
            $this->movimiento(
                $item['producto_id'],
                $usuarioId,
                'SALIDA',
                $item['cantidad'],
                'Venta / cobro de pedido',
                'PEDIDO_' . $pedidoId
            );
        }

        return true;
    }
}