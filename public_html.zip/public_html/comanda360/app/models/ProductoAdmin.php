<?php

class ProductoAdmin extends Model
{
    public function listar()
    {
        $sql = "SELECT 
                    p.*,
                    c.nombre AS categoria
                FROM productos p
                INNER JOIN categorias c ON c.id = p.categoria_id
                ORDER BY c.nombre ASC, p.nombre ASC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function categorias()
    {
        $sql = "SELECT *
                FROM categorias
                ORDER BY nombre ASC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function crearCategoria($nombre)
    {
        $sql = "INSERT INTO categorias (nombre, activo)
                VALUES (?, 1)";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([$nombre]);
    }

    public function guardar($id, $categoriaId, $nombre, $descripcion, $precio, $disponible, $activo, $controlaStock, $stockMinimo)
    {
        if ($id > 0) {
            $sql = "UPDATE productos
                    SET categoria_id = ?,
                        nombre = ?,
                        descripcion = ?,
                        precio = ?,
                        disponible = ?,
                        activo = ?,
                        controla_stock = ?,
                        stock_minimo = ?
                    WHERE id = ?";

            $stmt = $this->db->prepare($sql);

            return $stmt->execute([
                $categoriaId,
                $nombre,
                $descripcion,
                $precio,
                $disponible,
                $activo,
                $controlaStock,
                $stockMinimo,
                $id
            ]);
        }

        $sql = "INSERT INTO productos
                (categoria_id, nombre, descripcion, precio, disponible, activo, controla_stock, stock_actual, stock_minimo)
                VALUES (?, ?, ?, ?, ?, ?, ?, 0.00, ?)";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            $categoriaId,
            $nombre,
            $descripcion,
            $precio,
            $disponible,
            $activo,
            $controlaStock,
            $stockMinimo
        ]);
    }

    public function cambiarEstado($id, $activo)
    {
        $sql = "UPDATE productos
                SET activo = ?
                WHERE id = ?";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([$activo, $id]);
    }

    public function cambiarDisponibilidad($id, $disponible)
    {
        $sql = "UPDATE productos
                SET disponible = ?
                WHERE id = ?";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([$disponible, $id]);
    }
}