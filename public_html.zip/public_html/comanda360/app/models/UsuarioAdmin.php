<?php

class UsuarioAdmin extends Model
{
    public function listar()
    {
        $sql = "SELECT
                    u.*,
                    r.nombre AS rol,
                    COALESCE(GROUP_CONCAT(udd.dia_semana ORDER BY udd.dia_semana SEPARATOR ','), '') AS dias_descanso
                FROM usuarios u
                INNER JOIN roles r ON r.id = u.rol_id
                LEFT JOIN usuario_dias_descanso udd ON udd.usuario_id = u.id
                GROUP BY u.id, r.nombre
                ORDER BY u.id DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function roles()
    {
        $stmt = $this->db->prepare("SELECT id, nombre FROM roles WHERE activo = 1 ORDER BY nombre");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function crear($rolId, $nombre, $usuario, $password, $telefono, $diasDescanso = [])
    {
        $this->db->beginTransaction();

        try {
            $hash = password_hash($password, PASSWORD_DEFAULT);

            $sql = "INSERT INTO usuarios
                    (rol_id, nombre, usuario, password, telefono, activo)
                    VALUES (?, ?, ?, ?, ?, 1)";

            $stmt = $this->db->prepare($sql);
            $stmt->execute([$rolId, $nombre, $usuario, $hash, $telefono]);

            $usuarioId = (int) $this->db->lastInsertId();
            $this->guardarDiasDescansoInterno($usuarioId, $diasDescanso);

            $this->db->commit();
            return true;
        } catch (Throwable $e) {
            $this->db->rollBack();
            return false;
        }
    }

    public function actualizar($id, $rolId, $nombre, $usuario, $telefono, $diasDescanso = [])
    {
        $this->db->beginTransaction();

        try {
            $sql = "UPDATE usuarios
                    SET rol_id = ?, nombre = ?, usuario = ?, telefono = ?
                    WHERE id = ?";

            $stmt = $this->db->prepare($sql);
            $stmt->execute([$rolId, $nombre, $usuario, $telefono, $id]);

            $this->guardarDiasDescansoInterno($id, $diasDescanso);

            $this->db->commit();
            return true;
        } catch (Throwable $e) {
            $this->db->rollBack();
            return false;
        }
    }

    private function guardarDiasDescansoInterno($usuarioId, $diasDescanso)
    {
        $delete = $this->db->prepare("DELETE FROM usuario_dias_descanso WHERE usuario_id = ?");
        $delete->execute([$usuarioId]);

        if (empty($diasDescanso)) {
            return;
        }

        $insert = $this->db->prepare(
            "INSERT INTO usuario_dias_descanso (usuario_id, dia_semana) VALUES (?, ?)"
        );

        foreach ($diasDescanso as $dia) {
            $dia = (int) $dia;
            if ($dia >= 0 && $dia <= 6) {
                $insert->execute([$usuarioId, $dia]);
            }
        }
    }

    public function cambiarPassword($id, $password)
    {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $sql = "UPDATE usuarios SET password = ? WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$hash, $id]);
    }

    public function cambiarEstado($id, $activo)
    {
        $sql = "UPDATE usuarios SET activo = ? WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$activo, $id]);
    }
}
