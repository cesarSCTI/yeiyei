<?php

class CuentaCobrada extends Model
{
    public function listarPorFecha($fecha)
    {
        $sql = "SELECT
                    pg.id AS pago_id,
                    pg.pedido_id,
                    pg.usuario_caja_id,
                    pg.metodo_pago,
                    pg.subtotal,
                    pg.descuento_tipo,
                    pg.descuento_valor,
                    pg.descuento_importe,
                    pg.total,
                    pg.efectivo,
                    pg.tarjeta,
                    pg.transferencia,
                    pg.cambio,
                    pg.created_at,
                    p.mesa_id,
                    m.nombre AS mesa,
                    uc.nombre AS usuario_caja,
                    um.nombre AS mesero,
                    (
                        SELECT COUNT(*)
                        FROM pedido_detalle pd
                        WHERE pd.pedido_id = p.id
                          AND pd.estado <> 'CANCELADO'
                    ) AS productos_lineas,
                    (
                        SELECT COUNT(*)
                        FROM pago_cambios pc
                        WHERE pc.pago_id = pg.id
                    ) AS cambios_realizados
                FROM pagos pg
                INNER JOIN pedidos p ON p.id = pg.pedido_id
                INNER JOIN mesas m ON m.id = p.mesa_id
                INNER JOIN usuarios uc ON uc.id = pg.usuario_caja_id
                INNER JOIN usuarios um ON um.id = p.usuario_mesero_id
                WHERE DATE(pg.created_at) = ?
                ORDER BY pg.created_at DESC, pg.id DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$fecha]);

        return $stmt->fetchAll();
    }

    public function obtenerDetalle($pagoId)
    {
        $sqlPago = "SELECT
                        pg.*,
                        p.mesa_id,
                        m.nombre AS mesa,
                        uc.nombre AS usuario_caja,
                        um.nombre AS mesero
                    FROM pagos pg
                    INNER JOIN pedidos p ON p.id = pg.pedido_id
                    INNER JOIN mesas m ON m.id = p.mesa_id
                    INNER JOIN usuarios uc ON uc.id = pg.usuario_caja_id
                    INNER JOIN usuarios um ON um.id = p.usuario_mesero_id
                    WHERE pg.id = ?
                    LIMIT 1";

        $stmtPago = $this->db->prepare($sqlPago);
        $stmtPago->execute([$pagoId]);
        $pago = $stmtPago->fetch();

        if (!$pago) {
            return null;
        }

        $sqlDetalle = "SELECT
                           pd.id,
                           pd.cantidad,
                           pd.precio_unitario,
                           pd.subtotal_original,
                           pd.descuento_tipo,
                           pd.descuento_valor,
                           pd.descuento_importe,
                           pd.subtotal,
                           pd.notas,
                           pd.estado,
                           pr.nombre AS producto
                       FROM pedido_detalle pd
                       INNER JOIN productos pr ON pr.id = pd.producto_id
                       WHERE pd.pedido_id = ?
                         AND pd.estado <> 'CANCELADO'
                       ORDER BY pd.id ASC";

        $stmtDetalle = $this->db->prepare($sqlDetalle);
        $stmtDetalle->execute([$pago['pedido_id']]);

        $sqlCambios = "SELECT
                           pc.*,
                           u.nombre AS usuario_modifica
                       FROM pago_cambios pc
                       INNER JOIN usuarios u ON u.id = pc.usuario_id
                       WHERE pc.pago_id = ?
                       ORDER BY pc.id DESC";

        $stmtCambios = $this->db->prepare($sqlCambios);
        $stmtCambios->execute([$pagoId]);

        return [
            'pago' => $pago,
            'detalle' => $stmtDetalle->fetchAll(),
            'cambios' => $stmtCambios->fetchAll()
        ];
    }

    public function cambiarMetodoPago(
        $pagoId,
        $usuarioId,
        $metodoNuevo,
        $efectivoNuevo,
        $tarjetaNueva,
        $transferenciaNueva,
        $motivo
    ) {
        $this->db->beginTransaction();

        try {
            $sqlPago = "SELECT *
                        FROM pagos
                        WHERE id = ?
                        LIMIT 1
                        FOR UPDATE";

            $stmtPago = $this->db->prepare($sqlPago);
            $stmtPago->execute([$pagoId]);
            $pago = $stmtPago->fetch();

            if (!$pago) {
                throw new RuntimeException('El pago no existe.');
            }

            $total = round((float)$pago['total'], 2);
            $efectivoNuevo = round(max((float)$efectivoNuevo, 0), 2);
            $tarjetaNueva = round(max((float)$tarjetaNueva, 0), 2);
            $transferenciaNueva = round(max((float)$transferenciaNueva, 0), 2);

            if ($metodoNuevo === 'EFECTIVO') {
                $efectivoNuevo = $total;
                $tarjetaNueva = 0.00;
                $transferenciaNueva = 0.00;
            } elseif ($metodoNuevo === 'TARJETA') {
                $efectivoNuevo = 0.00;
                $tarjetaNueva = $total;
                $transferenciaNueva = 0.00;
            } elseif ($metodoNuevo === 'TRANSFERENCIA') {
                $efectivoNuevo = 0.00;
                $tarjetaNueva = 0.00;
                $transferenciaNueva = $total;
            }

            $totalNuevo = round($efectivoNuevo + $tarjetaNueva + $transferenciaNueva, 2);

            if (abs($totalNuevo - $total) > 0.009) {
                throw new RuntimeException('La suma de los métodos de pago debe coincidir con el total cobrado.');
            }

            // En una corrección histórica se registran importes netos; no se genera cambio.
            $cambioNuevo = 0.00;

            $sqlUpdate = "UPDATE pagos
                          SET metodo_pago = ?,
                              efectivo = ?,
                              tarjeta = ?,
                              transferencia = ?,
                              cambio = ?
                          WHERE id = ?";

            $stmtUpdate = $this->db->prepare($sqlUpdate);
            $stmtUpdate->execute([
                $metodoNuevo,
                $efectivoNuevo,
                $tarjetaNueva,
                $transferenciaNueva,
                $cambioNuevo,
                $pagoId
            ]);

            $sqlAuditoria = "INSERT INTO pago_cambios
                             (
                                 pago_id,
                                 pedido_id,
                                 usuario_id,
                                 motivo,
                                 metodo_anterior,
                                 metodo_nuevo,
                                 efectivo_anterior,
                                 tarjeta_anterior,
                                 transferencia_anterior,
                                 cambio_anterior,
                                 efectivo_nuevo,
                                 tarjeta_nueva,
                                 transferencia_nueva,
                                 cambio_nuevo,
                                 total
                             )
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            $stmtAuditoria = $this->db->prepare($sqlAuditoria);
            $stmtAuditoria->execute([
                $pagoId,
                $pago['pedido_id'],
                $usuarioId,
                $motivo,
                $pago['metodo_pago'],
                $metodoNuevo,
                $pago['efectivo'],
                $pago['tarjeta'],
                $pago['transferencia'],
                $pago['cambio'],
                $efectivoNuevo,
                $tarjetaNueva,
                $transferenciaNueva,
                $cambioNuevo,
                $total
            ]);

            // También deja una referencia breve en el historial general existente.
            $descripcion = 'Pago #' . $pagoId
                . ' del pedido #' . $pago['pedido_id']
                . ' cambió de ' . $pago['metodo_pago']
                . ' a ' . $metodoNuevo
                . '. Motivo: ' . $motivo;

            $stmtHistorial = $this->db->prepare(
                "INSERT INTO historial_movimientos
                 (usuario_id, modulo, accion, descripcion, referencia_id)
                 VALUES (?, 'CAJA', 'CAMBIAR_METODO_PAGO', ?, ?)"
            );
            $stmtHistorial->execute([$usuarioId, $descripcion, $pagoId]);

            $fechaPago = substr($pago['created_at'], 0, 10);
            $this->actualizarCorteGuardado($fechaPago);

            $this->db->commit();

            return [
                'success' => true,
                'fecha' => $fechaPago,
                'total' => $total,
                'metodo' => $metodoNuevo
            ];
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    private function actualizarCorteGuardado($fecha)
    {
        $sqlResumen = "SELECT
                           IFNULL(SUM(GREATEST(efectivo - cambio, 0)), 0) AS efectivo,
                           IFNULL(SUM(tarjeta), 0) AS tarjeta,
                           IFNULL(SUM(transferencia), 0) AS transferencia,
                           IFNULL(SUM(
                               GREATEST(efectivo - cambio, 0)
                               + tarjeta
                               + transferencia
                           ), 0) AS total_ingresos
                       FROM pagos
                       WHERE DATE(created_at) = ?";

        $stmtResumen = $this->db->prepare($sqlResumen);
        $stmtResumen->execute([$fecha]);
        $resumen = $stmtResumen->fetch();

        $stmtEgresos = $this->db->prepare(
            "SELECT IFNULL(SUM(monto), 0) AS total_egresos
             FROM egresos
             WHERE fecha = ?"
        );
        $stmtEgresos->execute([$fecha]);
        $egresos = $stmtEgresos->fetch();

        $totalEgresos = (float)($egresos['total_egresos'] ?? 0);
        $totalFinal = (float)$resumen['total_ingresos'] - $totalEgresos;

        $sqlCorte = "UPDATE cortes_caja
                     SET efectivo = ?,
                         tarjeta = ?,
                         transferencia = ?,
                         total_ingresos = ?,
                         total_egresos = ?,
                         total_final = ?
                     WHERE fecha = ?";

        $stmtCorte = $this->db->prepare($sqlCorte);
        $stmtCorte->execute([
            $resumen['efectivo'],
            $resumen['tarjeta'],
            $resumen['transferencia'],
            $resumen['total_ingresos'],
            $totalEgresos,
            $totalFinal,
            $fecha
        ]);
    }
}
