<?php

class MesaAdmin extends Model
{
    public function listar()
    {
        $sql = "SELECT *
                FROM mesas
                ORDER BY id ASC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function guardar($id, $nombre, $descripcion)
    {
        if ($id > 0) {
            $sql = "UPDATE mesas
                    SET nombre = ?, descripcion = ?
                    WHERE id = ?";

            $stmt = $this->db->prepare($sql);
            return $stmt->execute([$nombre, $descripcion, $id]);
        }

        $sql = "INSERT INTO mesas
                (nombre, descripcion, estado, activo)
                VALUES (?, ?, 'LIBRE', 1)";

        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$nombre, $descripcion]);
    }

    public function cambiarActivo($id, $activo)
    {
        $sql = "UPDATE mesas
                SET activo = ?
                WHERE id = ?";

        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$activo, $id]);
    }
}