<?php

class Dashboard extends Model
{
    public function resumen()
    {
        $sql = "SELECT
                (SELECT COUNT(*) FROM mesas WHERE estado='LIBRE') AS mesas_libres,

                (SELECT COUNT(*) FROM mesas
                 WHERE estado IN ('OCUPADA','CUENTA_SOLICITADA'))
                 AS mesas_ocupadas,

                (SELECT COUNT(*) FROM pedidos
                 WHERE estado NOT IN ('COBRADO','CANCELADO'))
                 AS pedidos_activos,

                (SELECT COUNT(*) FROM pedidos
                 WHERE estado='ENVIADO_COCINA')
                 AS cocina_pendiente,

                (SELECT COUNT(*)
                 FROM pedido_detalle
                 WHERE estado='LISTO')
                 AS productos_listos,

                (SELECT COUNT(*)
                 FROM cancelaciones
                 WHERE estado='SOLICITADA')
                 AS cancelaciones_pendientes,

                (SELECT IFNULL(SUM(total),0)
                 FROM pagos
                 WHERE DATE(created_at)=CURDATE())
                 AS ventas_dia,

                (SELECT IFNULL(SUM(monto),0)
                 FROM egresos
                 WHERE fecha=CURDATE())
                 AS egresos_dia
                ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute();

        return $stmt->fetch();
    }
}