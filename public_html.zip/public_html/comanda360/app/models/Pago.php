<?php

class Pago extends Model
{
    public function registrar(
        $pedidoId,
        $usuarioCajaId,
        $metodoPago,
        $subtotal,
        $descuentoTipo,
        $descuentoValor,
        $descuentoImporte,
        $total,
        $efectivo,
        $tarjeta,
        $transferencia,
        $cambio
    ) {
        $sql = "INSERT INTO pagos
                (
                    pedido_id,
                    usuario_caja_id,
                    metodo_pago,
                    subtotal,
                    descuento_tipo,
                    descuento_valor,
                    descuento_importe,
                    total,
                    efectivo,
                    tarjeta,
                    transferencia,
                    cambio
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            $pedidoId,
            $usuarioCajaId,
            $metodoPago,
            $subtotal,
            $descuentoTipo,
            $descuentoValor,
            $descuentoImporte,
            $total,
            $efectivo,
            $tarjeta,
            $transferencia,
            $cambio
        ]);
    }

    public function obtenerPorPedido($pedidoId)
    {
        $sql = "SELECT *
                FROM pagos
                WHERE pedido_id = ?
                ORDER BY id DESC
                LIMIT 1";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$pedidoId]);

        return $stmt->fetch();
    }
}
