<?php

class Mesa extends Model
{
    public function listarActivas()
    {
        $sql = "SELECT 
                    id,
                    nombre,
                    descripcion,
                    estado
                FROM mesas
                WHERE activo = 1
                ORDER BY id ASC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function obtenerPorId($id)
    {
        $sql = "SELECT *
                FROM mesas
                WHERE id = ?
                LIMIT 1";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id]);

        return $stmt->fetch();
    }

    public function cambiarEstado($id, $estado)
    {
        $sql = "UPDATE mesas 
                SET estado = ?
                WHERE id = ?";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([$estado, $id]);
    }
}