<?php

class Cancelacion extends Model
{
    public function solicitar($pedidoId, $detalleId, $usuarioSolicitaId, $motivo)
    {
        $sql = "INSERT INTO cancelaciones
                (pedido_id, pedido_detalle_id, usuario_solicita_id, motivo, estado)
                VALUES (?, ?, ?, ?, 'SOLICITADA')";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            $pedidoId,
            $detalleId,
            $usuarioSolicitaId,
            $motivo
        ]);

        return $this->db->lastInsertId();
    }

    public function obtenerDetalleSolicitud($cancelacionId)
    {
        $sql = "SELECT
                    c.*,
                    m.nombre AS mesa,
                    p.id AS pedido_id,
                    pd.cantidad,
                    pd.subtotal,
                    pr.nombre AS producto,
                    u.nombre AS empleado,
                    ua.telefono AS telefono_admin
                FROM cancelaciones c
                INNER JOIN pedidos p ON p.id = c.pedido_id
                INNER JOIN mesas m ON m.id = p.mesa_id
                INNER JOIN pedido_detalle pd ON pd.id = c.pedido_detalle_id
                INNER JOIN productos pr ON pr.id = pd.producto_id
                INNER JOIN usuarios u ON u.id = c.usuario_solicita_id
                LEFT JOIN usuarios ua ON ua.rol_id = 1 AND ua.activo = 1
                WHERE c.id = ?
                LIMIT 1";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$cancelacionId]);

        return $stmt->fetch();
    }

    public function listar()
    {
        $sql = "SELECT
                    c.*,
                    m.nombre AS mesa,
                    pd.cantidad,
                    pd.subtotal,
                    pr.nombre AS producto,
                    us.nombre AS solicita,
                    ua.nombre AS autoriza
                FROM cancelaciones c
                INNER JOIN pedidos p ON p.id = c.pedido_id
                INNER JOIN mesas m ON m.id = p.mesa_id
                INNER JOIN pedido_detalle pd ON pd.id = c.pedido_detalle_id
                INNER JOIN productos pr ON pr.id = pd.producto_id
                INNER JOIN usuarios us ON us.id = c.usuario_solicita_id
                LEFT JOIN usuarios ua ON ua.id = c.usuario_autoriza_id
                ORDER BY c.id DESC
                LIMIT 100";

        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function aprobar($cancelacionId, $usuarioAutorizaId, $respuesta)
    {
        $this->db->beginTransaction();

        try {
            $sql = "SELECT c.pedido_id, c.pedido_detalle_id, p.mesa_id
                    FROM cancelaciones c
                    INNER JOIN pedidos p ON p.id = c.pedido_id
                    WHERE c.id = ?
                    AND c.estado = 'SOLICITADA'
                    LIMIT 1
                    FOR UPDATE";

            $stmt = $this->db->prepare($sql);
            $stmt->execute([$cancelacionId]);
            $cancelacion = $stmt->fetch();

            if (!$cancelacion) {
                throw new RuntimeException('La solicitud ya no está disponible.');
            }

            $sqlDetalle = "UPDATE pedido_detalle
                           SET estado = 'CANCELADO'
                           WHERE id = ?
                           AND pedido_id = ?";

            $stmtDetalle = $this->db->prepare($sqlDetalle);
            $stmtDetalle->execute([
                $cancelacion['pedido_detalle_id'],
                $cancelacion['pedido_id']
            ]);

            $sqlPedido = "UPDATE pedidos p
                          SET total = (
                              SELECT IFNULL(SUM(subtotal), 0)
                              FROM pedido_detalle
                              WHERE pedido_id = p.id
                              AND estado <> 'CANCELADO'
                          )
                          WHERE p.id = ?";

            $stmtPedido = $this->db->prepare($sqlPedido);
            $stmtPedido->execute([$cancelacion['pedido_id']]);

            $sqlActivos = "SELECT COUNT(*) AS total
                           FROM pedido_detalle
                           WHERE pedido_id = ?
                           AND estado <> 'CANCELADO'";

            $stmtActivos = $this->db->prepare($sqlActivos);
            $stmtActivos->execute([$cancelacion['pedido_id']]);
            $activos = (int)($stmtActivos->fetch()['total'] ?? 0);

            // Si se canceló el último producto, se cierra el pedido y se libera la mesa.
            if ($activos === 0) {
                $stmtCerrar = $this->db->prepare(
                    "UPDATE pedidos
                     SET estado = 'CANCELADO', total = 0, fecha_cierre = NOW()
                     WHERE id = ?"
                );
                $stmtCerrar->execute([$cancelacion['pedido_id']]);

                $stmtMesa = $this->db->prepare(
                    "UPDATE mesas m
                     SET m.estado = 'LIBRE'
                     WHERE m.id = ?
                     AND NOT EXISTS (
                         SELECT 1
                         FROM pedidos p2
                         WHERE p2.mesa_id = m.id
                         AND p2.estado NOT IN ('COBRADO','CANCELADO')
                     )"
                );
                $stmtMesa->execute([$cancelacion['mesa_id']]);
            }

            $sqlCancelacion = "UPDATE cancelaciones
                               SET estado = 'APROBADA',
                                   usuario_autoriza_id = ?,
                                   respuesta = ?,
                                   fecha_respuesta = NOW()
                               WHERE id = ?";

            $stmtCancelacion = $this->db->prepare($sqlCancelacion);
            $stmtCancelacion->execute([
                $usuarioAutorizaId,
                $respuesta,
                $cancelacionId
            ]);

            $this->db->commit();
            return true;

        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            return false;
        }
    }

    public function rechazar($cancelacionId, $usuarioAutorizaId, $respuesta)
    {
        $sql = "UPDATE cancelaciones
                SET estado = 'RECHAZADA',
                    usuario_autoriza_id = ?,
                    respuesta = ?,
                    fecha_respuesta = NOW()
                WHERE id = ?
                AND estado = 'SOLICITADA'";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            $usuarioAutorizaId,
            $respuesta,
            $cancelacionId
        ]);
    }

    public function marcarWhatsappEnviado($cancelacionId)
    {
        $sql = "UPDATE cancelaciones
                SET whatsapp_enviado = 1,
                    whatsapp_fecha = NOW()
                WHERE id = ?";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([$cancelacionId]);
    }
}