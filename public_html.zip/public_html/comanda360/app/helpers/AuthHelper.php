<?php

class AuthHelper
{
    public static function check()
    {
        return isset($_SESSION['usuario']);
    }

    public static function user()
    {
        return $_SESSION['usuario'] ?? null;
    }

    public static function role()
    {
        return $_SESSION['usuario']['rol'] ?? null;
    }

    public static function requireLogin()
    {
        if (!self::check()) {
            header("Location: " . BASE_URL . "/auth/login");
            exit;
        }
    }

    public static function requireRole($rolesPermitidos = [])
    {
        self::requireLogin();

        $rolUsuario = self::role();

        if (!in_array($rolUsuario, $rolesPermitidos)) {
            http_response_code(403);
            die("Acceso no autorizado");
        }
    }

    public static function can($rolesPermitidos = [])
    {
        if (!self::check()) {
            return false;
        }

        return in_array(self::role(), $rolesPermitidos);
    }
}