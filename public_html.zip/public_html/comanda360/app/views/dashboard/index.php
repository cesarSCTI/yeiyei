<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Comanda360 | Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <script>
        const BASE_URL = "<?= BASE_URL ?>";
    </script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<nav class="navbar navbar-dark bg-dark">
    <div class="container-fluid">
        <span class="navbar-brand">Comanda360</span>

        <a href="<?= BASE_URL ?>/auth/logout" class="btn btn-outline-light btn-sm">
            Salir
        </a>
    </div>
</nav>

<div class="container-fluid py-4">

    <div class="mb-3">
        <h4 class="mb-1">Dashboard</h4>
        <p class="text-muted mb-0">
            Bienvenido, <?= htmlspecialchars($_SESSION['usuario']['nombre']) ?> |
            Rol: <?= htmlspecialchars($_SESSION['usuario']['rol']) ?>
        </p>
    </div>
        <div class="d-flex flex-wrap gap-2 mb-4">
        <?php if (AuthHelper::can(['ADMINISTRADOR','SUPERVISOR','MESERO'])): ?>
            <a href="<?= BASE_URL ?>/mesas" class="btn btn-dark btn-sm">Mesas</a>
        <?php endif; ?>

        <?php if (AuthHelper::can(['ADMINISTRADOR','SUPERVISOR','COCINA'])): ?>
            <a href="<?= BASE_URL ?>/cocina" class="btn btn-warning btn-sm">Cocina</a>
        <?php endif; ?>

        <?php if (AuthHelper::can(['ADMINISTRADOR','SUPERVISOR','CAJA','MESERO'])): ?>
            <a href="<?= BASE_URL ?>/caja" class="btn btn-success btn-sm">Caja</a>
        <?php endif; ?>

        <?php if (AuthHelper::can(['ADMINISTRADOR','SUPERVISOR','CAJA'])): ?>
            <a href="<?= BASE_URL ?>/cortes" class="btn btn-primary btn-sm">Corte de Caja</a>
            <a href="<?= BASE_URL ?>/egresos" class="btn btn-danger btn-sm">Egresos</a>
        <?php endif; ?>

        <?php if (AuthHelper::can(['ADMINISTRADOR','SUPERVISOR'])): ?>
            <a href="<?= BASE_URL ?>/cancelaciones" class="btn btn-outline-danger btn-sm">Cancelaciones</a>
            <a href="<?= BASE_URL ?>/cuentasCobradas" class="btn btn-outline-primary btn-sm">Cuentas cobradas</a>
        <?php endif; ?>

        <?php if (AuthHelper::can(['ADMINISTRADOR'])): ?>
            <a href="<?= BASE_URL ?>/usuarios" class="btn btn-outline-dark btn-sm">Usuarios</a>
            <a href="<?= BASE_URL ?>/productos" class="btn btn-outline-success btn-sm">Productos</a>
            <a href="<?= BASE_URL ?>/inventario" class="btn btn-outline-primary btn-sm">Inventario</a>
            <a href="<?= BASE_URL ?>/mesasAdmin" class="btn btn-outline-secondary btn-sm">Administrar Mesas</a>
        <?php endif; ?>               
    </div>

    <div id="dashboardCards" class="row g-3">
        <div class="col-12">
            <div class="alert alert-info">
                Cargando dashboard...
            </div>
        </div>
    </div>

</div>

<script src="<?= BASE_URL ?>/assets/js/dashboard.js"></script>

</body>
</html>