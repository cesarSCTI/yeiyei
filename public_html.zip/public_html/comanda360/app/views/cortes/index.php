<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Comanda360 | Corte de Caja</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <script>
        const BASE_URL = "<?= BASE_URL ?>";
    </script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<nav class="navbar navbar-dark bg-dark">
    <div class="container-fluid">
        <a href="<?= BASE_URL ?>/dashboard" class="navbar-brand text-decoration-none">
            Comanda360
        </a>

        <div class="d-flex gap-2">
            <a href="<?= BASE_URL ?>/mesas" class="btn btn-outline-light btn-sm">Mesas</a>
            <a href="<?= BASE_URL ?>/caja" class="btn btn-outline-light btn-sm">Caja</a>
            <a href="<?= BASE_URL ?>/dashboard" class="btn btn-outline-light btn-sm">Dashboard</a>
            <a href="<?= BASE_URL ?>/auth/logout" class="btn btn-outline-light btn-sm">Salir</a>
        </div>
    </div>
</nav>

<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h4 class="mb-1">Corte de Caja</h4>
            <p class="text-muted mb-0">Resumen de ingresos, egresos y total final.</p>
        </div>

        <div class="d-flex gap-2">
            <input type="date" id="fechaCorte" class="form-control form-control-sm">
            <button class="btn btn-dark btn-sm" onclick="cargarResumenCorte()">Actualizar</button>
        </div>
    </div>

    <div id="alertaCorte"></div>

    <div class="row g-3 mb-4">

        <div class="col-12 col-md-4 col-xl-2">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <small class="text-muted">Efectivo</small>
                    <h4 id="resEfectivo">$0.00</h4>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-4 col-xl-2">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <small class="text-muted">Tarjeta</small>
                    <h4 id="resTarjeta">$0.00</h4>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-4 col-xl-2">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <small class="text-muted">Transferencia</small>
                    <h4 id="resTransferencia">$0.00</h4>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-4 col-xl-2">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <small class="text-muted">Ingresos</small>
                    <h4 id="resIngresos">$0.00</h4>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-4 col-xl-2">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <small class="text-muted">Egresos</small>
                    <h4 id="resEgresos">$0.00</h4>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-4 col-xl-2">
            <div class="card shadow-sm border-0 bg-dark text-white">
                <div class="card-body">
                    <small>Total Final</small>
                    <h4 id="resFinal">$0.00</h4>
                </div>
            </div>
        </div>

    </div>

    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body">
            <h5>Guardar corte</h5>

            <div class="mb-3">
                <label class="form-label">Observaciones</label>
                <textarea id="observacionesCorte" class="form-control" rows="3"></textarea>
            </div>

            <button id="btnGuardarCorte" class="btn btn-success" onclick="guardarCorte()">
                Guardar corte del día
            </button>
        </div>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-body">
            <h5>Historial reciente</h5>

            <div id="contenedorHistorial">
                <div class="alert alert-info">Cargando historial...</div>
            </div>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?= BASE_URL ?>/assets/js/cortes.js?v=20260806-1"></script>

</body>
</html>