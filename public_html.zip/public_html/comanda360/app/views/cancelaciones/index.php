<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Comanda360 | Cancelaciones</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <script>
        const BASE_URL = "<?= BASE_URL ?>";
    </script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<nav class="navbar navbar-dark bg-dark">
    <div class="container-fluid">
        <a href="<?= BASE_URL ?>/dashboard" class="navbar-brand text-decoration-none">
            Comanda360
        </a>

        <div class="d-flex gap-2">
            <a href="<?= BASE_URL ?>/mesas" class="btn btn-outline-light btn-sm">Mesas</a>
            <a href="<?= BASE_URL ?>/caja" class="btn btn-outline-light btn-sm">Caja</a>
            <a href="<?= BASE_URL ?>/dashboard" class="btn btn-outline-light btn-sm">Dashboard</a>
            <a href="<?= BASE_URL ?>/auth/logout" class="btn btn-outline-light btn-sm">Salir</a>
        </div>
    </div>
</nav>

<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h4 class="mb-1">Cancelaciones</h4>
            <p class="text-muted mb-0">
                Solicitudes de cancelación y autorización.
            </p>
        </div>

        <button class="btn btn-dark btn-sm" onclick="cargarCancelaciones()">
            Actualizar
        </button>
    </div>

    <div id="contenedorCancelaciones">
        <div class="alert alert-info">Cargando cancelaciones...</div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?= BASE_URL ?>/assets/js/cancelaciones.js"></script>

</body>
</html>