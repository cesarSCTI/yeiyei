<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">

    <title>Comanda360 | Mesas</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <script>
        const BASE_URL = "<?= BASE_URL ?>";
    </script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<nav class="navbar navbar-dark bg-dark">
    <div class="container-fluid">

        <a href="<?= BASE_URL ?>/dashboard" class="navbar-brand text-decoration-none">
            Comanda360
        </a>

        <div class="d-flex gap-2">
            <a href="<?= BASE_URL ?>/dashboard" class="btn btn-outline-light btn-sm">
                Dashboard
            </a>

            <a href="<?= BASE_URL ?>/auth/logout" class="btn btn-outline-light btn-sm">
                Salir
            </a>
        </div>

    </div>
</nav>

<div class="container py-4">

    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h4 class="mb-1">Mesas</h4>
            <p class="text-muted mb-0">
                Control operativo de mesas en tiempo casi real.
            </p>
        </div>

        <button class="btn btn-dark btn-sm" onclick="cargarMesas()">
            Actualizar
        </button>
    </div>

    <div class="card border-0 shadow-sm mb-3">
        <div class="card-body py-3">
            <div class="row g-2 align-items-center">
                <div class="col-12 col-lg-7">
                    <label for="buscarMesa" class="form-label small text-muted mb-1">Buscar mesa</label>
                    <div class="input-group">
                        <span class="input-group-text">🔎</span>
                        <input
                            type="search"
                            id="buscarMesa"
                            class="form-control"
                            placeholder="Ej. Mesa 18, libre, ocupada..."
                            autocomplete="off"
                        >
                        <button
                            type="button"
                            id="btnLimpiarBusqueda"
                            class="btn btn-outline-secondary"
                            title="Limpiar búsqueda"
                            aria-label="Limpiar búsqueda"
                        >
                            Limpiar
                        </button>
                    </div>
                </div>

                <div class="col-12 col-lg-5">
                    <label for="filtroEstadoMesa" class="form-label small text-muted mb-1">Estado</label>
                    <select id="filtroEstadoMesa" class="form-select">
                        <option value="TODAS">Todas las mesas</option>
                        <option value="LIBRE">Libres</option>
                        <option value="OCUPADA">Ocupadas</option>
                        <option value="CUENTA_SOLICITADA">Cuenta solicitada</option>
                    </select>
                </div>
            </div>

            <div id="resumenBusquedaMesas" class="small text-muted mt-2" aria-live="polite"></div>
        </div>
    </div>

    <div id="contenedorMesas" class="row g-3">
        <div class="col-12">
            <div class="alert alert-info">
                Cargando mesas...
            </div>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?= BASE_URL ?>/assets/js/mesas.js?v=20260806-2305"></script>

</body>
</html>