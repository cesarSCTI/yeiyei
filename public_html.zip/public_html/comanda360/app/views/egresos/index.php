<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Comanda360 | Egresos</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <script>
        const BASE_URL = "<?= BASE_URL ?>";
    </script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<nav class="navbar navbar-dark bg-dark">
    <div class="container-fluid">
        <a href="<?= BASE_URL ?>/dashboard" class="navbar-brand text-decoration-none">
            Comanda360
        </a>

        <div class="d-flex gap-2">
            <a href="<?= BASE_URL ?>/cortes" class="btn btn-outline-light btn-sm">Corte</a>
            <a href="<?= BASE_URL ?>/caja" class="btn btn-outline-light btn-sm">Caja</a>
            <a href="<?= BASE_URL ?>/dashboard" class="btn btn-outline-light btn-sm">Dashboard</a>
            <a href="<?= BASE_URL ?>/auth/logout" class="btn btn-outline-light btn-sm">Salir</a>
        </div>
    </div>
</nav>

<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h4 class="mb-1">Egresos</h4>
            <p class="text-muted mb-0">Registro de salidas de dinero.</p>
        </div>

        <div class="d-flex gap-2">
            <input type="date" id="fechaEgreso" class="form-control form-control-sm">
            <button class="btn btn-dark btn-sm" onclick="cargarEgresos()">Actualizar</button>
        </div>
    </div>

    <div class="row g-3">

        <div class="col-lg-4">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <h5>Nuevo egreso</h5>

                    <form id="formEgreso">

                        <div class="mb-3">
                            <label class="form-label">Concepto</label>
                            <input type="text" name="concepto" id="concepto" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Monto</label>
                            <input type="number" step="0.01" name="monto" id="monto" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Descripción</label>
                            <textarea name="descripcion" id="descripcion" class="form-control" rows="3"></textarea>
                        </div>

                        <button class="btn btn-success w-100" type="submit">
                            Guardar egreso
                        </button>

                    </form>
                </div>
            </div>

            <div class="card shadow-sm border-0 mt-3 bg-dark text-white">
                <div class="card-body">
                    <small>Total egresos del día</small>
                    <h3 id="totalEgresos">$0.00</h3>
                </div>
            </div>
        </div>

        <div class="col-lg-8">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <h5>Listado de egresos</h5>

                    <div id="contenedorEgresos">
                        <div class="alert alert-info">
                            Cargando egresos...
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?= BASE_URL ?>/assets/js/egresos.js"></script>

</body>
</html>