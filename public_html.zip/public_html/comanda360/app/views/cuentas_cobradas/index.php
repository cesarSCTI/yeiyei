<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Comanda360 | Cuentas cobradas</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <script>
        const BASE_URL = "<?= BASE_URL ?>";
    </script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark">
    <div class="container-fluid">
        <a href="<?= BASE_URL ?>/dashboard" class="navbar-brand text-decoration-none">Comanda360</a>
        <div class="d-flex gap-2">
            <a href="<?= BASE_URL ?>/cortes" class="btn btn-outline-light btn-sm">Corte de Caja</a>
            <a href="<?= BASE_URL ?>/dashboard" class="btn btn-outline-light btn-sm">Dashboard</a>
            <a href="<?= BASE_URL ?>/auth/logout" class="btn btn-outline-light btn-sm">Salir</a>
        </div>
    </div>
</nav>

<div class="container-fluid py-4">
    <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-end gap-3 mb-3">
        <div>
            <h4 class="mb-1">Cuentas cobradas</h4>
            <p class="text-muted mb-0">Consulta por día y mesa, con corrección auditada del método de pago.</p>
        </div>

        <div class="d-flex flex-wrap gap-2">
            <div>
                <label for="fechaCuentas" class="form-label small mb-1">Fecha</label>
                <input type="date" id="fechaCuentas" class="form-control form-control-sm">
            </div>
            <div>
                <label for="buscarCuenta" class="form-label small mb-1">Buscar mesa o pedido</label>
                <input type="search" id="buscarCuenta" class="form-control form-control-sm" placeholder="Ej. Mesa 8 o 780">
            </div>
            <div class="align-self-end">
                <button class="btn btn-dark btn-sm" type="button" onclick="cargarCuentas()">Actualizar</button>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-6 col-lg-3">
            <div class="card shadow-sm border-0 h-100"><div class="card-body">
                <small class="text-muted">Cuentas cobradas</small>
                <h4 id="resCantidad" class="mb-0">0</h4>
            </div></div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="card shadow-sm border-0 h-100"><div class="card-body">
                <small class="text-muted">Efectivo neto</small>
                <h4 id="resEfectivo" class="mb-0">$0.00</h4>
            </div></div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="card shadow-sm border-0 h-100"><div class="card-body">
                <small class="text-muted">Tarjeta + transferencia</small>
                <h4 id="resElectronico" class="mb-0">$0.00</h4>
            </div></div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="card shadow-sm border-0 bg-dark text-white h-100"><div class="card-body">
                <small>Total cobrado</small>
                <h4 id="resTotal" class="mb-0">$0.00</h4>
            </div></div>
        </div>
    </div>

    <div id="contenedorCuentas">
        <div class="alert alert-info">Cargando cuentas cobradas...</div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?= BASE_URL ?>/assets/js/cuentas_cobradas.js?v=2026080701"></script>
</body>
</html>
