<?php
$agruparDetalleImpresion = static function (array $items): array {
    $grupos = [];

    foreach ($items as $item) {
        if (($item['estado'] ?? '') === 'CANCELADO') {
            continue;
        }

        $notas = trim((string)($item['notas'] ?? ''));
        $descuentoTipo = (string)($item['descuento_tipo'] ?? 'NINGUNO');
        $descuentoValor = (float)($item['descuento_valor'] ?? 0);
        $precioUnitario = (float)($item['precio_unitario'] ?? 0);

        $clave = implode('|', [
            (int)($item['producto_id'] ?? 0),
            number_format($precioUnitario, 4, '.', ''),
            strtolower($notas),
            $descuentoTipo,
            number_format($descuentoValor, 4, '.', '')
        ]);

        if (!isset($grupos[$clave])) {
            $grupos[$clave] = $item;
            $grupos[$clave]['cantidad'] = 0;
            $grupos[$clave]['subtotal_original'] = 0.00;
            $grupos[$clave]['descuento_importe'] = 0.00;
            $grupos[$clave]['subtotal'] = 0.00;
            $grupos[$clave]['notas'] = $notas;
        }

        $grupos[$clave]['cantidad'] += (float)($item['cantidad'] ?? 0);
        $grupos[$clave]['subtotal_original'] += (float)($item['subtotal_original'] ?? $item['subtotal'] ?? 0);
        $grupos[$clave]['descuento_importe'] += (float)($item['descuento_importe'] ?? 0);
        $grupos[$clave]['subtotal'] += (float)($item['subtotal'] ?? 0);
    }

    return array_values($grupos);
};

$detalleAgrupado = $agruparDetalleImpresion($detalle ?? []);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ticket de Venta #<?= (int)$pedido['id'] ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/impresion_termica.css?v=20260806-descuento-total-1">
</head>
<body data-paper-width="99" data-min-paper-height="100">
    <main class="ticket-print">
        <div class="center title">COMANDA360</div>
        <div class="center subtitle">TICKET DE VENTA</div>

        <div class="separator"></div>

        <section class="meta">
            <div><strong>FOLIO:</strong> #<?= (int)$pedido['id'] ?></div>
            <div><strong>MESA:</strong> <?= htmlspecialchars($pedido['mesa']) ?></div>
            <div><strong>MESERO:</strong> <?= htmlspecialchars($pedido['mesero']) ?></div>
            <div><strong>FECHA:</strong> <?= date('d/m/Y H:i') ?></div>
        </section>

        <div class="separator"></div>

        <?php foreach ($detalleAgrupado as $item): ?>
            <?php if ($item['estado'] !== 'CANCELADO'): ?>
                <?php
                    $original = (float)($item['subtotal_original'] ?? $item['subtotal']);
                    $final = (float)$item['subtotal'];
                    $descuento = (float)($item['descuento_importe'] ?? 0);
                ?>
                <section class="item">
                    <div class="item-main">
                        <div class="item-name">
                            <?= (int)$item['cantidad'] ?> x <?= htmlspecialchars($item['producto']) ?>
                        </div>
                        <div class="item-price">$<?= number_format($final, 2) ?></div>
                    </div>

                    <?php if ($descuento > 0): ?>
                        <div class="original">Antes: $<?= number_format($original, 2) ?></div>
                        <div class="discount">Descuento: -$<?= number_format($descuento, 2) ?></div>
                    <?php endif; ?>
                </section>
            <?php endif; ?>
        <?php endforeach; ?>

        <div class="separator"></div>
        <?php
            $subtotalPago = (float)($pago['subtotal'] ?? $pedido['total']);
            $descuentoTotal = (float)($pago['descuento_importe'] ?? 0);
            $totalPagado = (float)($pago['total'] ?? $pedido['total']);
        ?>
        <?php if ($descuentoTotal > 0): ?>
            <div class="summary-row">
                <div>SUBTOTAL</div>
                <div>$<?= number_format($subtotalPago, 2) ?></div>
            </div>
            <div class="summary-row discount">
                <div>DESCUENTO TOTAL</div>
                <div>-$<?= number_format($descuentoTotal, 2) ?></div>
            </div>
        <?php endif; ?>
        <div class="total-row">
            <div>TOTAL PAGADO</div>
            <div>$<?= number_format($totalPagado, 2) ?></div>
        </div>
        <?php if (!empty($pago)): ?>
            <div class="summary-row">
                <div>MÉTODO</div>
                <div><?= htmlspecialchars($pago['metodo_pago']) ?></div>
            </div>
        <?php endif; ?>
        <div class="separator"></div>
        <div class="footer-message">¡Gracias por su compra!</div>
    </main>

    <div class="screen-tools">
        <button type="button" onclick="printThermalTicket()">Imprimir</button>
        <button type="button" onclick="window.close()">Cerrar</button>
    </div>

    <script src="<?= BASE_URL ?>/assets/js/impresion_termica.js?v=20260726-orientacion-estable-1"></script>
</body>
</html>
