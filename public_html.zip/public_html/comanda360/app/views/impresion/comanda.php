<?php
$agruparDetalleImpresion = static function (array $items): array {
    $grupos = [];

    foreach ($items as $item) {
        if (($item['estado'] ?? '') === 'CANCELADO') {
            continue;
        }

        $categoria = mb_strtolower(trim((string)($item['categoria'] ?? '')), 'UTF-8');
        if (in_array($categoria, ['bebida', 'bebidas', 'refresco', 'refrescos', 'jugo', 'jugos', 'agua', 'aguas'], true)) {
            continue;
        }

        $notas = trim((string)($item['notas'] ?? ''));
        $descuentoTipo = (string)($item['descuento_tipo'] ?? 'NINGUNO');
        $descuentoValor = (float)($item['descuento_valor'] ?? 0);
        $precioUnitario = (float)($item['precio_unitario'] ?? 0);

        $clave = implode('|', [
            (int)($item['producto_id'] ?? 0),
            number_format($precioUnitario, 4, '.', ''),
            strtolower($notas),
            $descuentoTipo,
            number_format($descuentoValor, 4, '.', '')
        ]);

        if (!isset($grupos[$clave])) {
            $grupos[$clave] = $item;
            $grupos[$clave]['cantidad'] = 0;
            $grupos[$clave]['subtotal_original'] = 0.00;
            $grupos[$clave]['descuento_importe'] = 0.00;
            $grupos[$clave]['subtotal'] = 0.00;
            $grupos[$clave]['notas'] = $notas;
        }

        $grupos[$clave]['cantidad'] += (float)($item['cantidad'] ?? 0);
        $grupos[$clave]['subtotal_original'] += (float)($item['subtotal_original'] ?? $item['subtotal'] ?? 0);
        $grupos[$clave]['descuento_importe'] += (float)($item['descuento_importe'] ?? 0);
        $grupos[$clave]['subtotal'] += (float)($item['subtotal'] ?? 0);
    }

    return array_values($grupos);
};

$detalleAgrupado = $agruparDetalleImpresion($detalle ?? []);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Comanda Cocina #<?= (int)$pedido['id'] ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/impresion_termica.css?v=20260726-no-entregados-1">
</head>
<body data-paper-width="99" data-min-paper-height="100">
    <main class="ticket-print">
        <div class="center title">COMANDA360</div>
        <div class="center subtitle">COMANDA DE COCINA</div>

        <div class="separator"></div>

        <section class="meta">
            <div><strong>MESA:</strong> <?= htmlspecialchars($pedido['mesa']) ?></div>
            <div><strong>PEDIDO:</strong> #<?= (int)$pedido['id'] ?></div>
            <div><strong>MESERO:</strong> <?= htmlspecialchars($pedido['mesero']) ?></div>
            <div><strong>FECHA:</strong> <?= date('d/m/Y H:i') ?></div>
        </section>

        <div class="separator"></div>

        <?php $impresos = 0; ?>
        <?php foreach ($detalleAgrupado as $item): ?>
            <?php if ($item['estado'] !== 'CANCELADO'): ?>
                <?php $impresos++; ?>
                <section class="item">
                    <div class="item-main">
                        <div class="item-name">
                            <?= (int)$item['cantidad'] ?> x <?= htmlspecialchars($item['producto']) ?>
                        </div>
                    </div>

                    <?php if (!empty($item['notas'])): ?>
                        <div class="note">NOTA: <?= htmlspecialchars($item['notas']) ?></div>
                    <?php endif; ?>
                </section>
            <?php endif; ?>
        <?php endforeach; ?>

        <?php if ($impresos === 0): ?>
            <div class="center bold">SIN PRODUCTOS PARA IMPRIMIR</div>
        <?php endif; ?>

        <div class="separator"></div>
        <div class="footer-message bold">PREPARAR PEDIDO</div>
    </main>

    <div class="screen-tools">
        <button type="button" onclick="printThermalTicket()">Imprimir</button>
        <button type="button" onclick="window.close()">Cerrar</button>
    </div>

    <script src="<?= BASE_URL ?>/assets/js/impresion_termica.js?v=20260726-no-entregados-1"></script>
</body>
</html>
