<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">

    <title>Comanda360 | Login</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <script>
        const BASE_URL = "<?= BASE_URL ?>";
    </script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container">

    <div class="row justify-content-center mt-5">

        <div class="col-md-4">

            <div class="card shadow">

                <div class="card-body">

                    <h3 class="text-center mb-4">
                        Comanda360
                    </h3>

                    <form id="formLogin" autocomplete="off">

                        <div class="mb-3">
                            <label class="form-label">Usuario</label>

                            <input
                                type="text"
                                name="usuario"
                                id="usuario"
                                class="form-control"
                                required
                                autofocus
                            >
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Contraseña</label>

                            <input
                                type="password"
                                name="password"
                                id="password"
                                class="form-control"
                                required
                            >
                        </div>

                        <button
                            class="btn btn-dark w-100"
                            type="submit"
                            id="btnLogin"
                        >
                            Ingresar
                        </button>

                    </form>

                </div>

            </div>

        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?= BASE_URL ?>/assets/js/auth.js"></script>

</body>
</html>