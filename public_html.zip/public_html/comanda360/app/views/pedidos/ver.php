<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Comanda360 | Pedido</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <script>
        const BASE_URL = "<?= BASE_URL ?>";
        let PEDIDO_ID = <?= $pedido ? (int)$pedido['id'] : 0 ?>;
        const MESA_ID = <?= (int)$mesa['id'] ?>;
    </script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<nav class="navbar navbar-dark bg-dark">
    <div class="container-fluid">
        <a href="<?= BASE_URL ?>/mesas" class="navbar-brand text-decoration-none">Comanda360</a>

        <div class="d-flex gap-2">
            <a href="<?= BASE_URL ?>/mesas" class="btn btn-outline-light btn-sm">Mesas</a>
            <a href="<?= BASE_URL ?>/auth/logout" class="btn btn-outline-light btn-sm">Salir</a>
        </div>
    </div>
</nav>

<div class="container-fluid py-3">
    <div class="row g-3">
        <div class="col-lg-8">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h4 class="mb-0"><?= htmlspecialchars($mesa['nombre']) ?></h4>
                            <small class="text-muted" id="etiquetaPedido">
                                <?= $pedido ? 'Pedido #' . (int)$pedido['id'] : 'Nuevo pedido · la mesa se ocupará al agregar el primer producto' ?>
                            </small>
                        </div>

                        <a href="<?= BASE_URL ?>/mesas" class="btn btn-outline-secondary btn-sm">Regresar</a>
                    </div>

                    <div class="mb-3">
                        <input
                            type="text"
                            id="buscarProducto"
                            class="form-control"
                            placeholder="Buscar producto..."
                        >
                    </div>

                    <div id="contenedorProductos" class="row g-3">
                        <div class="col-12">
                            <div class="alert alert-info">Cargando productos...</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card shadow-sm border-0 sticky-top" style="top: 15px;">
                <div class="card-body">
                    <h5 class="mb-3">Comanda actual</h5>

                    <div id="contenedorDetalle">
                        <div class="alert alert-info">Cargando comanda...</div>
                    </div>

                    <hr>

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5>Total</h5>
                        <h4 id="totalPedido">$0.00</h4>
                    </div>

                    <?php if ($pedido): ?>
                        <button
                            id="btnMoverMesa"
                            class="btn btn-outline-warning w-100 mb-2"
                            onclick="abrirMoverMesa()"
                        >
                            Mover pedido a otra mesa
                        </button>
                    <?php endif; ?>

                    <button
                        id="btnEnviarCocina"
                        class="btn btn-dark w-100 mb-2"
                        onclick="enviarCocina()"
                        <?= $pedido ? '' : 'disabled' ?>
                    >
                        Enviar a cocina
                    </button>

                    <button
                        id="btnCobrarPedido"
                        class="btn btn-success w-100 mb-2"
                        onclick="abrirCobroDesdePedido()"
                        <?= $pedido ? '' : 'disabled' ?>
                    >
                        Realizar pago
                    </button>

                    <a href="<?= BASE_URL ?>/mesas" class="btn btn-outline-secondary w-100">
                        Volver a mesas
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?= BASE_URL ?>/assets/js/pedidos.js?v=20260806-descuento-total-1"></script>

</body>
</html>
