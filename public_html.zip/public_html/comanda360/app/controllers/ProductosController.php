<?php

require_once "../app/models/ProductoAdmin.php";

class ProductosController extends Controller
{
    public function index()
    {
        AuthHelper::requireRole(['ADMINISTRADOR']);

        $this->view('productos/index');
    }

    public function listar()
    {
        AuthHelper::requireRole(['ADMINISTRADOR']);

        header('Content-Type: application/json; charset=utf-8');

        $model = new ProductoAdmin();

        echo json_encode([
            'success' => true,
            'data' => $model->listar()
        ]);
    }

    public function categorias()
    {
        AuthHelper::requireRole(['ADMINISTRADOR']);

        header('Content-Type: application/json; charset=utf-8');

        $model = new ProductoAdmin();

        echo json_encode([
            'success' => true,
            'data' => $model->categorias()
        ]);
    }

    public function guardarCategoria()
    {
        AuthHelper::requireRole(['ADMINISTRADOR']);

        header('Content-Type: application/json; charset=utf-8');

        $nombre = trim($_POST['nombre'] ?? '');

        if ($nombre === '') {
            echo json_encode([
                'success' => false,
                'message' => 'Captura el nombre de la categoría.'
            ]);
            return;
        }

        $model = new ProductoAdmin();
        $ok = $model->crearCategoria($nombre);

        echo json_encode([
            'success' => $ok,
            'message' => $ok ? 'Categoría creada correctamente.' : 'No se pudo crear la categoría.'
        ]);
    }

    public function guardar()
    {
        AuthHelper::requireRole(['ADMINISTRADOR']);

        header('Content-Type: application/json; charset=utf-8');

        $id = intval($_POST['id'] ?? 0);
        $categoriaId = intval($_POST['categoria_id'] ?? 0);
        $nombre = trim($_POST['nombre'] ?? '');
        $descripcion = trim($_POST['descripcion'] ?? '');
        $precio = floatval($_POST['precio'] ?? 0);
        $disponible = intval($_POST['disponible'] ?? 1);
        $activo = intval($_POST['activo'] ?? 1);
        $controlaStock = intval($_POST['controla_stock'] ?? 0);
        $stockMinimo = floatval($_POST['stock_minimo'] ?? 0);

        if ($categoriaId <= 0 || $nombre === '' || $precio < 0) {
            echo json_encode([
                'success' => false,
                'message' => 'Datos incompletos o inválidos.'
            ]);
            return;
        }

        $model = new ProductoAdmin();

        $ok = $model->guardar(
            $id,
            $categoriaId,
            $nombre,
            $descripcion !== '' ? $descripcion : null,
            $precio,
            $disponible,
            $activo,
            $controlaStock,
            $stockMinimo
        );

        echo json_encode([
            'success' => $ok,
            'message' => $ok ? 'Producto guardado correctamente.' : 'No se pudo guardar el producto.'
        ]);
    }

    public function estado()
    {
        AuthHelper::requireRole(['ADMINISTRADOR']);

        header('Content-Type: application/json; charset=utf-8');

        $id = intval($_POST['id'] ?? 0);
        $activo = intval($_POST['activo'] ?? 0);

        if ($id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Producto inválido.']);
            return;
        }

        $model = new ProductoAdmin();
        $ok = $model->cambiarEstado($id, $activo);

        echo json_encode([
            'success' => $ok,
            'message' => $ok ? 'Estado actualizado.' : 'No se pudo actualizar.'
        ]);
    }

    public function disponible()
    {
        AuthHelper::requireRole(['ADMINISTRADOR']);

        header('Content-Type: application/json; charset=utf-8');

        $id = intval($_POST['id'] ?? 0);
        $disponible = intval($_POST['disponible'] ?? 0);

        if ($id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Producto inválido.']);
            return;
        }

        $model = new ProductoAdmin();
        $ok = $model->cambiarDisponibilidad($id, $disponible);

        echo json_encode([
            'success' => $ok,
            'message' => $ok ? 'Disponibilidad actualizada.' : 'No se pudo actualizar.'
        ]);
    }
}