<?php

require_once "../app/models/MesaAdmin.php";

class MesasAdminController extends Controller
{
    public function index()
    {
        AuthHelper::requireRole(['ADMINISTRADOR']);

        $this->view('mesas_admin/index');
    }

    public function listar()
    {
        header('Content-Type: application/json; charset=utf-8');

        AuthHelper::requireRole(['ADMINISTRADOR']);

        $model = new MesaAdmin();

        echo json_encode([
            'success' => true,
            'data' => $model->listar()
        ]);
    }

    public function guardar()
    {
        header('Content-Type: application/json; charset=utf-8');

        AuthHelper::requireRole(['ADMINISTRADOR']);

        $id = intval($_POST['id'] ?? 0);
        $nombre = trim($_POST['nombre'] ?? '');
        $descripcion = trim($_POST['descripcion'] ?? '');

        if ($nombre === '') {
            echo json_encode([
                'success' => false,
                'message' => 'Captura el nombre de la mesa.'
            ]);
            return;
        }

        $model = new MesaAdmin();

        $ok = $model->guardar(
            $id,
            $nombre,
            $descripcion !== '' ? $descripcion : null
        );

        echo json_encode([
            'success' => $ok,
            'message' => $ok ? 'Mesa guardada correctamente.' : 'No se pudo guardar la mesa.'
        ]);
    }

    public function activo()
    {
        header('Content-Type: application/json; charset=utf-8');

        AuthHelper::requireRole(['ADMINISTRADOR']);

        $id = intval($_POST['id'] ?? 0);
        $activo = intval($_POST['activo'] ?? 0);

        if ($id <= 0) {
            echo json_encode([
                'success' => false,
                'message' => 'Mesa inválida.'
            ]);
            return;
        }

        $model = new MesaAdmin();

        $ok = $model->cambiarActivo($id, $activo);

        echo json_encode([
            'success' => $ok,
            'message' => $ok ? 'Estado actualizado.' : 'No se pudo actualizar.'
        ]);
    }
}