<?php

require_once "../app/models/PedidoDetalle.php";

class CocinaController extends Controller
{
    public function index()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','COCINA']);

        $this->view('cocina/index');
    }

    public function listar()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','COCINA']);

        header('Content-Type: application/json; charset=utf-8');
        $detalleModel = new PedidoDetalle();

        echo json_encode([
            'success' => true,
            'data' => $detalleModel->listarCocina()
        ]);
    }

    public function cambiarEstado()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','COCINA']);

        header('Content-Type: application/json; charset=utf-8');
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                'success' => false,
                'message' => 'Método no permitido.'
            ]);
            return;
        }

        $detalleId = intval($_POST['detalle_id'] ?? 0);
        $estado = trim($_POST['estado'] ?? '');

        $estadosPermitidos = [
            'PENDIENTE',
            'EN_PREPARACION',
            'LISTO',
            'ENTREGADO'
        ];

        if ($detalleId <= 0 || !in_array($estado, $estadosPermitidos)) {
            echo json_encode([
                'success' => false,
                'message' => 'Datos inválidos.'
            ]);
            return;
        }

        $detalleModel = new PedidoDetalle();
        $ok = $detalleModel->cambiarEstado($detalleId, $estado);

        echo json_encode([
            'success' => $ok,
            'message' => $ok ? 'Estado actualizado.' : 'No se pudo actualizar.'
        ]);
    }
}