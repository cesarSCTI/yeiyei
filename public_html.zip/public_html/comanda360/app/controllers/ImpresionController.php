<?php

require_once "../app/models/Pedido.php";
require_once "../app/models/PedidoDetalle.php";
require_once "../app/models/Pago.php";

class ImpresionController extends Controller
{
    public function comanda($pedidoId = 0)
    {
        $this->imprimir($pedidoId, 'impresion/comanda', true);
    }

    public function precuenta($pedidoId = 0)
    {
        $this->imprimir($pedidoId, 'impresion/precuenta');
    }

    public function ticket($pedidoId = 0)
    {
        $this->imprimir($pedidoId, 'impresion/ticket');
    }

    private function imprimir($pedidoId, $vista, $soloCocina = false)
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','MESERO','CAJA','COCINA']);

        $pedidoId = intval($pedidoId);

        if ($pedidoId <= 0) {
            die("Pedido inválido");
        }

        $pedidoModel = new Pedido();
        $detalleModel = new PedidoDetalle();
        $pagoModel = new Pago();

        $pedidoModel->actualizarTotal($pedidoId);

        $pedido = $pedidoModel->obtenerPorId($pedidoId);
        $detalle = $soloCocina
            ? $detalleModel->listarParaComandaCocina($pedidoId)
            : $detalleModel->listarPorPedido($pedidoId);

        if (!$pedido) {
            die("Pedido no encontrado");
        }

        $this->view($vista, [
            'pedido' => $pedido,
            'detalle' => $detalle,
            'pago' => $vista === 'impresion/ticket'
                ? $pagoModel->obtenerPorPedido($pedidoId)
                : null
        ]);
    }
}