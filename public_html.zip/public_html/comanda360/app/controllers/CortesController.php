<?php

require_once "../app/models/CorteCaja.php";

class CortesController extends Controller
{
    public function index()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','CAJA']);

        $this->view('cortes/index');
    }

    public function resumen()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','CAJA']);

        header('Content-Type: application/json; charset=utf-8');
        $fecha = $_GET['fecha'] ?? date('Y-m-d');

        $corteModel = new CorteCaja();

        $resumen = $corteModel->resumenDia($fecha);
        $egresos = $corteModel->totalEgresosDia($fecha);
        $existe = $corteModel->existeCorteFecha($fecha);

        $totalFinal = floatval($resumen['total_ingresos']) - floatval($egresos);

        echo json_encode([
            'success' => true,
            'fecha' => $fecha,
            'resumen' => [
                'efectivo' => floatval($resumen['efectivo']),
                'tarjeta' => floatval($resumen['tarjeta']),
                'transferencia' => floatval($resumen['transferencia']),
                'total_ingresos' => floatval($resumen['total_ingresos']),
                'total_egresos' => floatval($egresos),
                'total_final' => floatval($totalFinal)
            ],
            'corte_realizado' => $existe ? true : false
        ]);
    }

    public function guardar()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','CAJA']);

        header('Content-Type: application/json; charset=utf-8');
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Método no permitido.']);
            return;
        }

        $fecha = $_POST['fecha'] ?? date('Y-m-d');
        $observaciones = trim($_POST['observaciones'] ?? '');

        $corteModel = new CorteCaja();

        if ($corteModel->existeCorteFecha($fecha)) {
            echo json_encode([
                'success' => false,
                'message' => 'Ya existe un corte registrado para esta fecha.'
            ]);
            return;
        }

        $resumen = $corteModel->resumenDia($fecha);
        $egresos = $corteModel->totalEgresosDia($fecha);

        $efectivo = floatval($resumen['efectivo']);
        $tarjeta = floatval($resumen['tarjeta']);
        $transferencia = floatval($resumen['transferencia']);
        $totalIngresos = floatval($resumen['total_ingresos']);
        $totalEgresos = floatval($egresos);
        $totalFinal = $totalIngresos - $totalEgresos;

        $ok = $corteModel->guardar(
            $_SESSION['usuario']['id'],
            $fecha,
            $efectivo,
            $tarjeta,
            $transferencia,
            $totalIngresos,
            $totalEgresos,
            $totalFinal,
            $observaciones !== '' ? $observaciones : null
        );

        echo json_encode([
            'success' => $ok,
            'message' => $ok ? 'Corte guardado correctamente.' : 'No se pudo guardar el corte.'
        ]);
    }

    public function historial()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','CAJA']);

        header('Content-Type: application/json; charset=utf-8');
        $corteModel = new CorteCaja();

        echo json_encode([
            'success' => true,
            'data' => $corteModel->historial()
        ]);
    }
}