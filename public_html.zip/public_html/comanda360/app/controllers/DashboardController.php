<?php

require_once "../app/models/Dashboard.php";

class DashboardController extends Controller
{
    public function index()
    {
        AuthHelper::requireLogin();

        $this->view('dashboard/index');
    }

    public function resumen()
    {
        AuthHelper::requireLogin();

        header('Content-Type: application/json; charset=utf-8');
        $dashboard = new Dashboard();

        $data = $dashboard->resumen();

        $ventas = floatval($data['ventas_dia']);
        $egresos = floatval($data['egresos_dia']);

        $data['total_final_dia'] = $ventas - $egresos;    

        echo json_encode([
            'success'=>true,
            'data'=>$data
        ]);
    }    
}