<?php

require_once "../app/models/CuentaCobrada.php";

class CuentasCobradasController extends Controller
{
    private function autorizar()
    {
        AuthHelper::requireRole(['ADMINISTRADOR', 'SUPERVISOR']);
    }

    public function index()
    {
        $this->autorizar();
        $this->view('cuentas_cobradas/index');
    }

    public function listar()
    {
        $this->autorizar();
        header('Content-Type: application/json; charset=utf-8');

        $fecha = trim($_GET['fecha'] ?? date('Y-m-d'));

        if (!$this->fechaValida($fecha)) {
            echo json_encode(['success' => false, 'message' => 'Fecha inválida.']);
            return;
        }

        $model = new CuentaCobrada();

        echo json_encode([
            'success' => true,
            'fecha' => $fecha,
            'data' => $model->listarPorFecha($fecha)
        ], JSON_UNESCAPED_UNICODE);
    }

    public function detalle($pagoId = 0)
    {
        $this->autorizar();
        header('Content-Type: application/json; charset=utf-8');

        $pagoId = (int)$pagoId;

        if ($pagoId <= 0) {
            echo json_encode(['success' => false, 'message' => 'Pago inválido.']);
            return;
        }

        $model = new CuentaCobrada();
        $detalle = $model->obtenerDetalle($pagoId);

        if (!$detalle) {
            echo json_encode(['success' => false, 'message' => 'Pago no encontrado.']);
            return;
        }

        echo json_encode([
            'success' => true,
            'data' => $detalle
        ], JSON_UNESCAPED_UNICODE);
    }

    public function cambiarMetodo()
    {
        $this->autorizar();
        header('Content-Type: application/json; charset=utf-8');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Método no permitido.']);
            return;
        }

        $pagoId = (int)($_POST['pago_id'] ?? 0);
        $metodo = strtoupper(trim($_POST['metodo_pago'] ?? ''));
        $efectivo = (float)($_POST['efectivo'] ?? 0);
        $tarjeta = (float)($_POST['tarjeta'] ?? 0);
        $transferencia = (float)($_POST['transferencia'] ?? 0);
        $motivo = trim($_POST['motivo'] ?? '');

        $permitidos = ['EFECTIVO', 'TARJETA', 'TRANSFERENCIA', 'MIXTO'];

        if ($pagoId <= 0 || !in_array($metodo, $permitidos, true)) {
            echo json_encode(['success' => false, 'message' => 'Datos de pago inválidos.']);
            return;
        }

        if ($motivo === '') {
            echo json_encode(['success' => false, 'message' => 'Captura el motivo del cambio.']);
            return;
        }

        $model = new CuentaCobrada();
        $resultado = $model->cambiarMetodoPago(
            $pagoId,
            (int)$_SESSION['usuario']['id'],
            $metodo,
            $efectivo,
            $tarjeta,
            $transferencia,
            $motivo
        );

        echo json_encode([
            'success' => (bool)$resultado['success'],
            'message' => $resultado['success']
                ? 'Método de pago actualizado correctamente. El corte de caja fue recalculado.'
                : ($resultado['message'] ?? 'No se pudo actualizar el pago.'),
            'data' => $resultado['success'] ? $resultado : null
        ], JSON_UNESCAPED_UNICODE);
    }

    private function fechaValida($fecha)
    {
        $obj = DateTime::createFromFormat('Y-m-d', $fecha);
        return $obj && $obj->format('Y-m-d') === $fecha;
    }
}
