<?php

require_once "../app/models/Inventario.php";

class InventarioController extends Controller
{
    public function index()
    {
        AuthHelper::requireRole(['ADMINISTRADOR']);

        $this->view('inventario/index');
    }

    public function productos()
    {
        AuthHelper::requireRole(['ADMINISTRADOR']);

        header('Content-Type: application/json; charset=utf-8');

        $model = new Inventario();

        echo json_encode([
            'success' => true,
            'data' => $model->listarProductos()
        ]);
    }

    public function guardarConfig()
    {
        AuthHelper::requireRole(['ADMINISTRADOR']);

        header('Content-Type: application/json; charset=utf-8');

        $productoId = intval($_POST['producto_id'] ?? 0);
        $controlaStock = intval($_POST['controla_stock'] ?? 0);
        $stockMinimo = floatval($_POST['stock_minimo'] ?? 0);

        if ($productoId <= 0) {
            echo json_encode(['success' => false, 'message' => 'Producto inválido.']);
            return;
        }

        $model = new Inventario();

        $ok = $model->actualizarConfig($productoId, $controlaStock, $stockMinimo);

        echo json_encode([
            'success' => $ok,
            'message' => $ok ? 'Configuración actualizada.' : 'No se pudo actualizar.'
        ]);
    }

    public function movimiento()
    {
        AuthHelper::requireRole(['ADMINISTRADOR']);

        header('Content-Type: application/json; charset=utf-8');

        $productoId = intval($_POST['producto_id'] ?? 0);
        $tipo = trim($_POST['tipo'] ?? '');
        $cantidad = floatval($_POST['cantidad'] ?? 0);
        $motivo = trim($_POST['motivo'] ?? '');

        if ($productoId <= 0 || !in_array($tipo, ['ENTRADA', 'SALIDA', 'AJUSTE']) || $cantidad < 0 || $motivo === '') {
            echo json_encode(['success' => false, 'message' => 'Datos inválidos.']);
            return;
        }

        if ($tipo !== 'AJUSTE' && $cantidad <= 0) {
            echo json_encode(['success' => false, 'message' => 'La cantidad debe ser mayor a cero.']);
            return;
        }

        $model = new Inventario();

        $ok = $model->movimiento(
            $productoId,
            $_SESSION['usuario']['id'],
            $tipo,
            $cantidad,
            $motivo
        );

        echo json_encode([
            'success' => $ok,
            'message' => $ok ? 'Movimiento registrado.' : 'No se pudo registrar. Revisa stock disponible.'
        ]);
    }

    public function historial()
    {
        AuthHelper::requireRole(['ADMINISTRADOR']);

        header('Content-Type: application/json; charset=utf-8');

        $productoId = intval($_GET['producto_id'] ?? 0);

        $model = new Inventario();

        echo json_encode([
            'success' => true,
            'data' => $model->historial($productoId)
        ]);
    }
}