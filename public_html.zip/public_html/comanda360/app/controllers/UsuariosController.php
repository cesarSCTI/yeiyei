<?php

require_once "../app/models/UsuarioAdmin.php";

class UsuariosController extends Controller
{
    public function index()
    {
        AuthHelper::requireRole(['ADMINISTRADOR']);
        $this->view('usuarios/index');
    }

    public function listar()
    {
        AuthHelper::requireRole(['ADMINISTRADOR']);
        header('Content-Type: application/json; charset=utf-8');

        $model = new UsuarioAdmin();
        echo json_encode(['success' => true, 'data' => $model->listar()]);
    }

    public function roles()
    {
        AuthHelper::requireRole(['ADMINISTRADOR']);
        header('Content-Type: application/json; charset=utf-8');

        $model = new UsuarioAdmin();
        echo json_encode(['success' => true, 'data' => $model->roles()]);
    }

    public function guardar()
    {
        AuthHelper::requireRole(['ADMINISTRADOR']);
        header('Content-Type: application/json; charset=utf-8');

        $id = intval($_POST['id'] ?? 0);
        $rolId = intval($_POST['rol_id'] ?? 0);
        $nombre = trim($_POST['nombre'] ?? '');
        $usuario = trim($_POST['usuario'] ?? '');
        $telefono = preg_replace('/\D/', '', $_POST['telefono'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $diasRaw = $_POST['dias_descanso'] ?? '[]';
        $diasDescanso = json_decode($diasRaw, true);

        if (!is_array($diasDescanso)) {
            $diasDescanso = [];
        }

        $diasDescanso = array_values(array_unique(array_filter(
            array_map('intval', $diasDescanso),
            static fn($dia) => $dia >= 0 && $dia <= 6
        )));

        if ($rolId <= 0 || $nombre === '' || $usuario === '') {
            echo json_encode(['success' => false, 'message' => 'Datos incompletos.']);
            return;
        }

        $model = new UsuarioAdmin();

        if ($id > 0) {
            $ok = $model->actualizar($id, $rolId, $nombre, $usuario, $telefono, $diasDescanso);
        } else {
            if ($password === '') {
                echo json_encode(['success' => false, 'message' => 'Captura una contraseña.']);
                return;
            }

            $ok = $model->crear($rolId, $nombre, $usuario, $password, $telefono, $diasDescanso);
        }

        echo json_encode([
            'success' => $ok,
            'message' => $ok ? 'Usuario guardado correctamente.' : 'No se pudo guardar el usuario.'
        ]);
    }

    public function password()
    {
        AuthHelper::requireRole(['ADMINISTRADOR']);
        header('Content-Type: application/json; charset=utf-8');

        $id = intval($_POST['id'] ?? 0);
        $password = trim($_POST['password'] ?? '');

        if ($id <= 0 || $password === '') {
            echo json_encode(['success' => false, 'message' => 'Datos inválidos.']);
            return;
        }

        $model = new UsuarioAdmin();
        $ok = $model->cambiarPassword($id, $password);

        echo json_encode([
            'success' => $ok,
            'message' => $ok ? 'Contraseña actualizada.' : 'No se pudo actualizar.'
        ]);
    }

    public function estado()
    {
        AuthHelper::requireRole(['ADMINISTRADOR']);
        header('Content-Type: application/json; charset=utf-8');

        $id = intval($_POST['id'] ?? 0);
        $activo = intval($_POST['activo'] ?? 0);

        if ($id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Usuario inválido.']);
            return;
        }

        if ($id === intval($_SESSION['usuario']['id'])) {
            echo json_encode(['success' => false, 'message' => 'No puedes desactivar tu propio usuario.']);
            return;
        }

        $model = new UsuarioAdmin();
        $ok = $model->cambiarEstado($id, $activo);

        echo json_encode([
            'success' => $ok,
            'message' => $ok ? 'Estado actualizado.' : 'No se pudo actualizar.'
        ]);
    }
}
