<?php

require_once "../app/models/Pedido.php";
require_once "../app/models/PedidoDetalle.php";
require_once "../app/models/Mesa.php";
require_once "../app/models/Pago.php";
require_once "../app/models/Inventario.php";

class CajaController extends Controller
{
    public function index()
    {
        AuthHelper::requireLogin();

        $this->view('caja/index');
    }

    public function listar()
    {
        AuthHelper::requireLogin();

        header('Content-Type: application/json; charset=utf-8');

        $pedidoModel = new Pedido();
        $detalleModel = new PedidoDetalle();

        $pedidos = $pedidoModel->listarParaCaja();
        $pedidoIds = array_column($pedidos, 'id');
        $detalles = $detalleModel->listarParaPedidos($pedidoIds);

        foreach ($pedidos as &$pedido) {
            $pedidoId = (int)$pedido['id'];
            $pedido['detalle'] = $detalles[$pedidoId] ?? [];
        }
        unset($pedido);

        echo json_encode([
            'success' => true,
            'data' => $pedidos
        ], JSON_UNESCAPED_UNICODE);
    }

    public function ver($pedidoId = 0)
    {
        AuthHelper::requireLogin();

        header('Content-Type: application/json; charset=utf-8');
        $pedidoId = intval($pedidoId);

        if ($pedidoId <= 0) {
            echo json_encode(['success' => false, 'message' => 'Pedido inválido.']);
            return;
        }

        $pedidoModel = new Pedido();
        $detalleModel = new PedidoDetalle();

        $pedidoModel->actualizarTotal($pedidoId);

        echo json_encode([
            'success' => true,
            'pedido' => $pedidoModel->obtenerPorId($pedidoId),
            'detalle' => $detalleModel->listarPorPedido($pedidoId)
        ]);
    }

    public function cobrar()
    {
        AuthHelper::requireLogin();

        header('Content-Type: application/json; charset=utf-8');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Método no permitido.']);
            return;
        }

        $pedidoId = intval($_POST['pedido_id'] ?? 0);
        $metodo = strtoupper(trim($_POST['metodo_pago'] ?? ''));

        $efectivo = max(floatval($_POST['efectivo'] ?? 0), 0);
        $tarjeta = max(floatval($_POST['tarjeta'] ?? 0), 0);
        $transferencia = max(floatval($_POST['transferencia'] ?? 0), 0);

        $descuentoTipo = strtoupper(trim($_POST['descuento_tipo'] ?? 'NINGUNO'));
        $descuentoValor = max(floatval($_POST['descuento_valor'] ?? 0), 0);

        $metodosPermitidos = ['EFECTIVO', 'TARJETA', 'TRANSFERENCIA', 'MIXTO'];
        $descuentosPermitidos = ['NINGUNO', 'PORCENTAJE', 'MONTO'];

        if (
            $pedidoId <= 0
            || !in_array($metodo, $metodosPermitidos, true)
            || !in_array($descuentoTipo, $descuentosPermitidos, true)
        ) {
            echo json_encode(['success' => false, 'message' => 'Datos inválidos.']);
            return;
        }

        $pedidoModel = new Pedido();
        $mesaModel = new Mesa();
        $pagoModel = new Pago();

        $pedidoModel->actualizarTotal($pedidoId);
        $pedido = $pedidoModel->obtenerPorId($pedidoId);

        if (!$pedido) {
            echo json_encode(['success' => false, 'message' => 'Pedido no encontrado.']);
            return;
        }

        if ($pedido['estado'] === 'COBRADO') {
            echo json_encode(['success' => false, 'message' => 'Este pedido ya fue cobrado.']);
            return;
        }

        $subtotalPedido = round(floatval($pedido['total']), 2);

        if ($subtotalPedido <= 0) {
            echo json_encode(['success' => false, 'message' => 'El pedido no tiene un total válido para cobrar.']);
            return;
        }

        $descuentoImporte = 0.00;

        if ($descuentoTipo === 'PORCENTAJE') {
            if ($descuentoValor > 100) {
                echo json_encode(['success' => false, 'message' => 'El descuento porcentual no puede ser mayor a 100%.']);
                return;
            }

            $descuentoImporte = round($subtotalPedido * ($descuentoValor / 100), 2);
        } elseif ($descuentoTipo === 'MONTO') {
            if ($descuentoValor > $subtotalPedido) {
                echo json_encode(['success' => false, 'message' => 'El descuento no puede ser mayor al total del pedido.']);
                return;
            }

            $descuentoImporte = round($descuentoValor, 2);
        } else {
            $descuentoTipo = 'NINGUNO';
            $descuentoValor = 0.00;
        }

        $totalPedido = round(max($subtotalPedido - $descuentoImporte, 0), 2);

        if ($totalPedido <= 0) {
            echo json_encode(['success' => false, 'message' => 'El total a cobrar debe ser mayor a cero.']);
            return;
        }

        // Normalizar importes según el método seleccionado.
        if ($metodo === 'EFECTIVO') {
            $tarjeta = 0;
            $transferencia = 0;
        } elseif ($metodo === 'TARJETA') {
            $efectivo = 0;
            $transferencia = 0;
        } elseif ($metodo === 'TRANSFERENCIA') {
            $efectivo = 0;
            $tarjeta = 0;
        }

        $totalRecibido = round($efectivo + $tarjeta + $transferencia, 2);

        if ($totalRecibido < $totalPedido) {
            echo json_encode(['success' => false, 'message' => 'El pago es menor al total del pedido.']);
            return;
        }

        // Solo el efectivo puede generar cambio. Tarjeta, transferencia y mixto
        // deben coincidir exactamente con el total del pedido.
        if ($metodo !== 'EFECTIVO' && abs($totalRecibido - $totalPedido) > 0.009) {
            echo json_encode([
                'success' => false,
                'message' => 'El importe pagado debe coincidir exactamente con el total del pedido.'
            ]);
            return;
        }

        $cambio = $metodo === 'EFECTIVO'
            ? round(max($efectivo - $totalPedido, 0), 2)
            : 0.00;

        $efectivoNeto = round(max($efectivo - $cambio, 0), 2);
        $totalAplicado = round($efectivoNeto + $tarjeta + $transferencia, 2);

        if (abs($totalAplicado - $totalPedido) > 0.009) {
            echo json_encode([
                'success' => false,
                'message' => 'Los importes del pago no coinciden con el total del pedido.'
            ]);
            return;
        }

        $ok = $pagoModel->registrar(
            $pedidoId,
            $_SESSION['usuario']['id'],
            $metodo,
            $subtotalPedido,
            $descuentoTipo,
            $descuentoValor,
            $descuentoImporte,
            $totalPedido,
            $efectivo,
            $tarjeta,
            $transferencia,
            $cambio
        );

        if ($ok) {
            $inventarioModel = new Inventario();

            $inventarioModel->descontarPorPedido(
                $pedidoId,
                $_SESSION['usuario']['id']
            );

            $pedidoModel->cambiarEstado($pedidoId, 'COBRADO');
            $mesaModel->cambiarEstado($pedido['mesa_id'], 'LIBRE');
        }

        echo json_encode([
            'success' => $ok,
            'message' => $ok ? 'Cobro registrado correctamente.' : 'No se pudo registrar el cobro.',
            'data' => $ok ? [
                'subtotal' => $subtotalPedido,
                'descuento_tipo' => $descuentoTipo,
                'descuento_valor' => $descuentoValor,
                'descuento_importe' => $descuentoImporte,
                'total' => $totalPedido,
                'efectivo_recibido' => $efectivo,
                'efectivo_neto' => $efectivoNeto,
                'tarjeta' => $tarjeta,
                'transferencia' => $transferencia,
                'cambio' => $cambio
            ] : null
        ]);
    }
}