<?php

require_once "../app/models/Egreso.php";

class EgresosController extends Controller
{
    public function index()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','CAJA']);

        $this->view('egresos/index');
    }

    public function listar()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','CAJA']);

        header('Content-Type: application/json; charset=utf-8');
        $fecha = $_GET['fecha'] ?? date('Y-m-d');

        $egresoModel = new Egreso();

        echo json_encode([
            'success' => true,
            'total' => $egresoModel->totalPorFecha($fecha),
            'data' => $egresoModel->listarPorFecha($fecha)
        ]);
    }

    public function guardar()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','CAJA']);

        header('Content-Type: application/json; charset=utf-8');
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Método no permitido.']);
            return;
        }

        $fecha = $_POST['fecha'] ?? date('Y-m-d');
        $concepto = trim($_POST['concepto'] ?? '');
        $monto = floatval($_POST['monto'] ?? 0);
        $descripcion = trim($_POST['descripcion'] ?? '');

        if ($concepto === '') {
            echo json_encode(['success' => false, 'message' => 'Captura el concepto del egreso.']);
            return;
        }

        if ($monto <= 0) {
            echo json_encode(['success' => false, 'message' => 'El monto debe ser mayor a cero.']);
            return;
        }

        $egresoModel = new Egreso();

        $ok = $egresoModel->registrar(
            $_SESSION['usuario']['id'],
            $concepto,
            $monto,
            $descripcion !== '' ? $descripcion : null,
            $fecha
        );

        echo json_encode([
            'success' => $ok,
            'message' => $ok ? 'Egreso registrado correctamente.' : 'No se pudo registrar el egreso.'
        ]);
    }
}