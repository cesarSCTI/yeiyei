<?php

require_once "../app/models/Usuario.php";

class AuthController extends Controller
{
    public function login()
    {
        if (isset($_SESSION['usuario'])) {
            header("Location: " . BASE_URL . "/dashboard");
            exit;
        }

        $this->view('auth/login');
    }

    public function validar()
    {
        header('Content-Type: application/json; charset=utf-8');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                'success' => false,
                'message' => 'Método no permitido.'
            ]);
            return;
        }

        $usuario = trim($_POST['usuario'] ?? '');
        $password = trim($_POST['password'] ?? '');

        if ($usuario === '' || $password === '') {
            echo json_encode([
                'success' => false,
                'message' => 'Captura usuario y contraseña.'
            ]);
            return;
        }

        $usuarioModel = new Usuario();
        $data = $usuarioModel->obtenerPorUsuario($usuario);

        if (!$data || (int)$data['activo'] !== 1) {
            echo json_encode([
                'success' => false,
                'message' => 'Usuario no encontrado o inactivo.'
            ]);
            return;
        }

        if (!password_verify($password, $data['password'])) {
            echo json_encode([
                'success' => false,
                'message' => 'Contraseña incorrecta.'
            ]);
            return;
        }

        // El administrador siempre puede ingresar, incluso en días marcados como descanso.
        if ($data['rol'] !== 'ADMINISTRADOR') {
            $diaSemana = (int) date('w'); // 0=domingo ... 6=sábado

            if ($usuarioModel->esDiaDescanso((int)$data['id'], $diaSemana)) {
                $dias = [
                    0 => 'domingo',
                    1 => 'lunes',
                    2 => 'martes',
                    3 => 'miércoles',
                    4 => 'jueves',
                    5 => 'viernes',
                    6 => 'sábado'
                ];

                echo json_encode([
                    'success' => false,
                    'message' => 'Hoy es tu día de descanso (' . $dias[$diaSemana] . '). No tienes permitido ingresar al sistema.'
                ]);
                return;
            }
        }

        $_SESSION['usuario'] = [
            'id' => $data['id'],
            'nombre' => $data['nombre'],
            'usuario' => $data['usuario'],
            'rol_id' => $data['rol_id'],
            'rol' => $data['rol']
        ];

        echo json_encode([
            'success' => true,
            'message' => 'Acceso correcto.',
            'redirect' => BASE_URL . '/dashboard'
        ]);
    }

    public function logout()
    {
        session_destroy();

        header("Location: " . BASE_URL . "/auth/login");
        exit;
    }
}
