<?php

require_once "../app/models/Cancelacion.php";

class CancelacionesController extends Controller
{
    public function index()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR']);

        $this->view('cancelaciones/index');
    }

    public function listar()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR']);

        header('Content-Type: application/json; charset=utf-8');
        $model = new Cancelacion();

        echo json_encode([
            'success' => true,
            'data' => $model->listar()
        ]);
    }

    public function solicitar()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','MESERO']);

        header('Content-Type: application/json; charset=utf-8');
        $pedidoId = intval($_POST['pedido_id'] ?? 0);
        $detalleId = intval($_POST['detalle_id'] ?? 0);
        $motivo = trim($_POST['motivo'] ?? '');

        if ($pedidoId <= 0 || $detalleId <= 0 || $motivo === '') {
            echo json_encode(['success' => false, 'message' => 'Datos incompletos.']);
            return;
        }

        $model = new Cancelacion();

        $cancelacionId = $model->solicitar(
            $pedidoId,
            $detalleId,
            $_SESSION['usuario']['id'],
            $motivo
        );

        if (!$cancelacionId) {
            echo json_encode(['success' => false, 'message' => 'No se pudo registrar la solicitud.']);
            return;
        }

        $info = $model->obtenerDetalleSolicitud($cancelacionId);

        $telefono = preg_replace('/\D/', '', $info['telefono_admin'] ?? '');

        $mensaje = "COMANDA360\n\n";
        $mensaje .= "Solicitud de cancelación\n\n";
        $mensaje .= "Mesa: " . $info['mesa'] . "\n";
        $mensaje .= "Pedido: #" . $info['pedido_id'] . "\n";
        $mensaje .= "Producto: " . $info['cantidad'] . " x " . $info['producto'] . "\n";
        $mensaje .= "Importe: $" . number_format($info['subtotal'], 2) . "\n";
        $mensaje .= "Empleado: " . $info['empleado'] . "\n\n";
        $mensaje .= "Motivo:\n" . $info['motivo'] . "\n\n";
        $mensaje .= "Autorizar/Rechazar desde:\n";
        $mensaje .= BASE_URL . "/cancelaciones";

        $whatsappUrl = '';

        if ($telefono !== '') {
            $whatsappUrl = "https://wa.me/" . $telefono . "?text=" . urlencode($mensaje);
            $model->marcarWhatsappEnviado($cancelacionId);
        }

        echo json_encode([
            'success' => true,
            'message' => 'Solicitud registrada.',
            'whatsapp_url' => $whatsappUrl
        ]);
    }

    public function aprobar()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR']);

        header('Content-Type: application/json; charset=utf-8');
        $id = intval($_POST['id'] ?? 0);
        $respuesta = trim($_POST['respuesta'] ?? '');

        if ($id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Solicitud inválida.']);
            return;
        }

        $model = new Cancelacion();

        $ok = $model->aprobar(
            $id,
            $_SESSION['usuario']['id'],
            $respuesta !== '' ? $respuesta : 'Cancelación aprobada.'
        );

        echo json_encode([
            'success' => $ok,
            'message' => $ok ? 'Cancelación aprobada.' : 'No se pudo aprobar.'
        ]);
    }

    public function rechazar()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR']);

        header('Content-Type: application/json; charset=utf-8');
        $id = intval($_POST['id'] ?? 0);
        $respuesta = trim($_POST['respuesta'] ?? '');

        if ($id <= 0 || $respuesta === '') {
            echo json_encode(['success' => false, 'message' => 'Captura el motivo del rechazo.']);
            return;
        }

        $model = new Cancelacion();

        $ok = $model->rechazar(
            $id,
            $_SESSION['usuario']['id'],
            $respuesta
        );

        echo json_encode([
            'success' => $ok,
            'message' => $ok ? 'Cancelación rechazada.' : 'No se pudo rechazar.'
        ]);
    }
}