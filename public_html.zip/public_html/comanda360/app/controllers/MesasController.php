<?php

require_once "../app/models/Mesa.php";
require_once "../app/models/Pedido.php";

class MesasController extends Controller
{
    public function index()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','MESERO']);

        $this->view('mesas/index');
    }

    public function listar()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','MESERO']);

        header('Content-Type: application/json; charset=utf-8');

        // Corrige automáticamente pedidos vacíos antiguos de la versión previa.
        $pedidoModel = new Pedido();
        $pedidoModel->liberarPedidosVaciosAntiguos();

        $mesaModel = new Mesa();
        $mesas = $mesaModel->listarActivas();

        echo json_encode([
            'success' => true,
            'data' => $mesas
        ]);
    }

    public function cambiarEstado()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','MESERO']);

        header('Content-Type: application/json; charset=utf-8');
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                'success' => false,
                'message' => 'Método no permitido.'
            ]);
            return;
        }

        $mesaId = intval($_POST['mesa_id'] ?? 0);
        $estado = trim($_POST['estado'] ?? '');

        $estadosPermitidos = [
            'LIBRE',
            'OCUPADA',
            'CUENTA_SOLICITADA',
            'COBRADA'
        ];

        if ($mesaId <= 0 || !in_array($estado, $estadosPermitidos)) {
            echo json_encode([
                'success' => false,
                'message' => 'Datos inválidos.'
            ]);
            return;
        }

        $mesaModel = new Mesa();
        $ok = $mesaModel->cambiarEstado($mesaId, $estado);

        echo json_encode([
            'success' => $ok,
            'message' => $ok ? 'Estado actualizado.' : 'No se pudo actualizar.'
        ]);
    }
}
