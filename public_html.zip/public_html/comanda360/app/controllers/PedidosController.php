<?php

require_once "../app/models/Mesa.php";
require_once "../app/models/Pedido.php";
require_once "../app/models/PedidoDetalle.php";
require_once "../app/models/Producto.php";

class PedidosController extends Controller
{
    public function ver($mesaId = 0)
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','MESERO']);

        $mesaId = intval($mesaId);

        if ($mesaId <= 0) {
            die("Mesa inválida");
        }

        $mesaModel = new Mesa();
        $pedidoModel = new Pedido();

        $mesa = $mesaModel->obtenerPorId($mesaId);

        if (!$mesa || (int)$mesa['activo'] !== 1) {
            die("Mesa no encontrada o inactiva");
        }

        // Importante: ya no se crea un pedido al entrar a la pantalla.
        // El pedido se crea hasta que se agrega el primer producto.
        $pedido = $pedidoModel->obtenerActivoPorMesa($mesaId);

        // Corrige pedidos vacíos heredados de la versión anterior.
        if ($pedido && $pedidoModel->contarDetallesActivos((int)$pedido['id']) === 0) {
            $pedidoModel->cambiarEstado((int)$pedido['id'], 'CANCELADO');
            $mesaModel->cambiarEstado($mesaId, 'LIBRE');
            $pedido = false;
            $mesa['estado'] = 'LIBRE';
        }

        $this->view('pedidos/ver', [
            'mesa' => $mesa,
            'pedido' => $pedido
        ]);
    }

    public function productos()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','MESERO']);

        header('Content-Type: application/json; charset=utf-8');
        $productoModel = new Producto();

        echo json_encode([
            'success' => true,
            'data' => $productoModel->listarDisponibles()
        ]);
    }

    public function detalle($pedidoId = 0)
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','MESERO']);

        header('Content-Type: application/json; charset=utf-8');
        $pedidoId = intval($pedidoId);

        if ($pedidoId <= 0) {
            echo json_encode([
                'success' => true,
                'data' => [],
                'pedido_id' => 0
            ]);
            return;
        }

        $detalleModel = new PedidoDetalle();
        $pedidoModel = new Pedido();
        $pedido = $pedidoModel->obtenerPorId($pedidoId);

        if (!$pedido || in_array($pedido['estado'], ['COBRADO', 'CANCELADO'], true)) {
            echo json_encode([
                'success' => true,
                'data' => [],
                'pedido_id' => 0,
                'pedido_cerrado' => true,
                'message' => 'El pedido fue cerrado y la mesa quedó libre.'
            ]);
            return;
        }

        $pedidoModel->actualizarTotal($pedidoId);

        echo json_encode([
            'success' => true,
            'data' => $detalleModel->listarPorPedido($pedidoId),
            'pedido_id' => $pedidoId
        ]);
    }

    public function agregarProducto()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','MESERO']);

        header('Content-Type: application/json; charset=utf-8');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                'success' => false,
                'message' => 'Método no permitido.'
            ]);
            return;
        }

        $pedidoId = intval($_POST['pedido_id'] ?? 0);
        $mesaId = intval($_POST['mesa_id'] ?? 0);
        $productoId = intval($_POST['producto_id'] ?? 0);
        $cantidad = intval($_POST['cantidad'] ?? 1);
        $notas = trim($_POST['notas'] ?? '');
        $descuentoTipo = strtoupper(trim($_POST['descuento_tipo'] ?? 'NINGUNO'));
        $descuentoValor = floatval($_POST['descuento_valor'] ?? 0);

        if ($mesaId <= 0 || $productoId <= 0 || $cantidad <= 0) {
            echo json_encode([
                'success' => false,
                'message' => 'Datos inválidos.'
            ]);
            return;
        }

        $tiposPermitidos = ['NINGUNO', 'PORCENTAJE', 'MONTO'];

        if (!in_array($descuentoTipo, $tiposPermitidos, true)) {
            echo json_encode([
                'success' => false,
                'message' => 'Tipo de descuento inválido.'
            ]);
            return;
        }

        if ($descuentoValor < 0) {
            echo json_encode([
                'success' => false,
                'message' => 'El descuento no puede ser negativo.'
            ]);
            return;
        }

        if ($descuentoTipo === 'PORCENTAJE' && $descuentoValor > 100) {
            echo json_encode([
                'success' => false,
                'message' => 'El descuento porcentual no puede ser mayor a 100%.'
            ]);
            return;
        }

        $productoModel = new Producto();
        $producto = $productoModel->obtenerPorId($productoId);

        if (!$producto) {
            echo json_encode([
                'success' => false,
                'message' => 'Producto no encontrado.'
            ]);
            return;
        }

        if ((int)$producto['controla_stock'] === 1) {
            $stockActual = floatval($producto['stock_actual']);

            if ($cantidad > $stockActual) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Stock insuficiente. Disponible: ' . number_format($stockActual, 2)
                ]);
                return;
            }
        }

        $precio = floatval($producto['precio']);

        if ($precio <= 0) {
            echo json_encode([
                'success' => false,
                'message' => 'El producto no tiene precio válido.'
            ]);
            return;
        }

        $subtotalOriginal = round($cantidad * $precio, 2);

        if ($descuentoTipo === 'MONTO' && $descuentoValor > $subtotalOriginal) {
            echo json_encode([
                'success' => false,
                'message' => 'El descuento fijo no puede ser mayor al subtotal del producto.'
            ]);
            return;
        }

        if ($descuentoTipo === 'NINGUNO') {
            $descuentoValor = 0;
        }

        $pedidoModel = new Pedido();

        // Si el cliente ya tiene pedido activo, el modelo lo reutiliza.
        // Si aún no existe, se crea aquí junto con el primer producto.
        $resultado = $pedidoModel->agregarProductoEnMesa(
            $mesaId,
            $_SESSION['usuario']['id'],
            $productoId,
            $cantidad,
            $precio,
            $notas !== '' ? $notas : null,
            $descuentoTipo,
            $descuentoValor
        );

        if (!$resultado) {
            echo json_encode([
                'success' => false,
                'message' => 'No se pudo agregar el producto ni abrir la mesa.'
            ]);
            return;
        }

        echo json_encode([
            'success' => true,
            'message' => $pedidoId > 0
                ? 'Producto agregado.'
                : 'Pedido creado y producto agregado.',
            'pedido_id' => (int)$resultado['pedido_id']
        ]);
    }

    public function mesasDisponibles($pedidoId = 0)
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','MESERO']);

        header('Content-Type: application/json; charset=utf-8');
        $pedidoId = intval($pedidoId);

        if ($pedidoId <= 0) {
            echo json_encode([
                'success' => false,
                'message' => 'Pedido inválido.'
            ]);
            return;
        }

        $pedidoModel = new Pedido();
        $pedido = $pedidoModel->obtenerPorId($pedidoId);

        if (!$pedido || in_array($pedido['estado'], ['COBRADO', 'CANCELADO'], true)) {
            echo json_encode([
                'success' => false,
                'message' => 'El pedido ya no está activo.'
            ]);
            return;
        }

        echo json_encode([
            'success' => true,
            'mesa_origen_id' => (int)$pedido['mesa_id'],
            'mesa_origen' => $pedido['mesa'],
            'data' => $pedidoModel->listarMesasDisponiblesParaMover((int)$pedido['mesa_id'])
        ], JSON_UNESCAPED_UNICODE);
    }

    public function moverMesa()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','MESERO']);

        header('Content-Type: application/json; charset=utf-8');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode([
                'success' => false,
                'message' => 'Método no permitido.'
            ]);
            return;
        }

        $pedidoId = intval($_POST['pedido_id'] ?? 0);
        $mesaDestinoId = intval($_POST['mesa_destino_id'] ?? 0);

        if ($pedidoId <= 0 || $mesaDestinoId <= 0) {
            echo json_encode([
                'success' => false,
                'message' => 'Selecciona una mesa destino válida.'
            ]);
            return;
        }

        $pedidoModel = new Pedido();
        $resultado = $pedidoModel->moverAMesa(
            $pedidoId,
            $mesaDestinoId,
            (int)$_SESSION['usuario']['id']
        );

        if (isset($resultado['error'])) {
            echo json_encode([
                'success' => false,
                'message' => $resultado['error']
            ]);
            return;
        }

        echo json_encode([
            'success' => true,
            'message' => 'Pedido movido correctamente a ' . $resultado['mesa_destino'] . '.',
            'data' => $resultado,
            'redirect' => BASE_URL . '/pedidos/ver/' . $resultado['mesa_destino_id']
        ], JSON_UNESCAPED_UNICODE);
    }

    public function mesasParaMoverProductos($pedidoId = 0)
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','MESERO']);

        header('Content-Type: application/json; charset=utf-8');
        $pedidoId = intval($pedidoId);

        if ($pedidoId <= 0) {
            echo json_encode(['success' => false, 'message' => 'Pedido inválido.']);
            return;
        }

        $pedidoModel = new Pedido();
        $pedido = $pedidoModel->obtenerPorId($pedidoId);

        if (!$pedido || in_array($pedido['estado'], ['COBRADO', 'CANCELADO'], true)) {
            echo json_encode(['success' => false, 'message' => 'El pedido ya no está activo.']);
            return;
        }

        echo json_encode([
            'success' => true,
            'mesa_origen_id' => (int)$pedido['mesa_id'],
            'mesa_origen' => $pedido['mesa'],
            'data' => $pedidoModel->listarMesasParaMoverProductos((int)$pedido['mesa_id'])
        ], JSON_UNESCAPED_UNICODE);
    }

    public function moverProductos()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','MESERO']);

        header('Content-Type: application/json; charset=utf-8');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Método no permitido.']);
            return;
        }

        $pedidoId = intval($_POST['pedido_id'] ?? 0);
        $mesaDestinoId = intval($_POST['mesa_destino_id'] ?? 0);
        $movimientosJson = $_POST['movimientos'] ?? '[]';
        $movimientos = json_decode($movimientosJson, true);

        if ($pedidoId <= 0 || $mesaDestinoId <= 0 || !is_array($movimientos) || empty($movimientos)) {
            echo json_encode(['success' => false, 'message' => 'Selecciona al menos un producto y una mesa destino.']);
            return;
        }

        $normalizados = [];
        foreach ($movimientos as $movimiento) {
            $detalleId = intval($movimiento['detalle_id'] ?? 0);
            $cantidad = intval($movimiento['cantidad'] ?? 0);

            if ($detalleId > 0 && $cantidad > 0) {
                $normalizados[$detalleId] = ($normalizados[$detalleId] ?? 0) + $cantidad;
            }
        }

        if (empty($normalizados)) {
            echo json_encode(['success' => false, 'message' => 'Las cantidades seleccionadas no son válidas.']);
            return;
        }

        $pedidoModel = new Pedido();
        $resultado = $pedidoModel->moverProductosAMesa(
            $pedidoId,
            $mesaDestinoId,
            $normalizados,
            (int)$_SESSION['usuario']['id']
        );

        if (isset($resultado['error'])) {
            echo json_encode(['success' => false, 'message' => $resultado['error']]);
            return;
        }

        echo json_encode([
            'success' => true,
            'message' => 'Productos movidos correctamente a ' . $resultado['mesa_destino'] . '.',
            'data' => $resultado
        ], JSON_UNESCAPED_UNICODE);
    }

    public function enviarCocina()
    {
        AuthHelper::requireRole(['ADMINISTRADOR','SUPERVISOR','MESERO']);

        header('Content-Type: application/json; charset=utf-8');
        $pedidoId = intval($_POST['pedido_id'] ?? 0);

        if ($pedidoId <= 0) {
            echo json_encode([
                'success' => false,
                'message' => 'Agrega al menos un producto antes de enviar a cocina.'
            ]);
            return;
        }

        $pedidoModel = new Pedido();
        $pedido = $pedidoModel->obtenerPorId($pedidoId);

        if (!$pedido || $pedidoModel->contarDetalles($pedidoId) <= 0) {
            echo json_encode([
                'success' => false,
                'message' => 'El pedido no contiene productos.'
            ]);
            return;
        }

        $ok = $pedidoModel->cambiarEstado($pedidoId, 'ENVIADO_COCINA');

        echo json_encode([
            'success' => $ok,
            'message' => $ok ? 'Pedido enviado a cocina.' : 'No se pudo enviar.'
        ]);
    }
}
