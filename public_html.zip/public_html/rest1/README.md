# Sazón Touch - Demo Frontend

Proyecto demostrativo para restaurante, optimizado para tablet, celular y pantalla táctil.

## Acceso

- Administrador: admin / 1234
- Cajero: caja / 1234
- Mesero: mesero / 1234
- Cocina: cocina / 1234

## Cómo abrirlo

Opción rápida:
1. Descomprime el archivo ZIP.
2. Abre `index.html` con Chrome, Edge o Firefox.

Opción recomendada:
1. Abre la carpeta con Visual Studio Code.
2. Instala la extensión Live Server.
3. Haz clic derecho en `index.html`.
4. Selecciona `Open with Live Server`.

## Incluye

- Login por rol
- Dashboard
- Mesas
- Toma de pedido
- Cocina
- Caja
- Productos
- Reportes
- Persistencia local con LocalStorage
- Diseño responsive y touch-friendly

No incluye backend, PHP ni MySQL.
