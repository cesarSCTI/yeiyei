
window.DEMO_DATA = {
  users: [
    { id: 1, name: "Administrador", username: "admin", password: "1234", role: "Administrador" },
    { id: 2, name: "María Caja", username: "caja", password: "1234", role: "Cajero" },
    { id: 3, name: "Juan Mesero", username: "mesero", password: "1234", role: "Mesero" },
    { id: 4, name: "Cocina", username: "cocina", password: "1234", role: "Cocina" }
  ],
  categories: ["Desayunos","Antojitos","Comida","Especialidad","Bebidas","Postres"],
  products: [
    {id:1,name:"Huevos con Jamón",price:95,category:"Desayunos",icon:"fa-egg"},
    {id:2,name:"Huevos con Chorizo",price:95,category:"Desayunos",icon:"fa-egg"},
    {id:3,name:"Huevos Rancheros",price:95,category:"Desayunos",icon:"fa-egg"},
    {id:4,name:"Huevos a la Mexicana",price:95,category:"Desayunos",icon:"fa-pepper-hot"},
    {id:5,name:"Omelette al Gusto",price:110,category:"Desayunos",icon:"fa-utensils"},
    {id:6,name:"Chilaquiles Sencillos",price:90,category:"Desayunos",icon:"fa-bowl-food"},
    {id:7,name:"Chilaquiles con Huevo",price:110,category:"Desayunos",icon:"fa-bowl-food"},
    {id:8,name:"Molletes",price:70,category:"Desayunos",icon:"fa-bread-slice"},
    {id:9,name:"Quesabirria",price:45,category:"Antojitos",icon:"fa-cheese"},
    {id:10,name:"Quesadilla Sencilla",price:25,category:"Antojitos",icon:"fa-cheese"},
    {id:11,name:"Quesadilla de Asada",price:45,category:"Antojitos",icon:"fa-cheese"},
    {id:12,name:"Taco de Birria",price:35,category:"Antojitos",icon:"fa-utensils"},
    {id:13,name:"Taco de Asada",price:35,category:"Antojitos",icon:"fa-utensils"},
    {id:14,name:"Taquitos Dorados",price:25,category:"Antojitos",icon:"fa-utensils"},
    {id:15,name:"Carne Asada",price:130,category:"Comida",icon:"fa-drumstick-bite"},
    {id:16,name:"Milanesa de Pollo",price:130,category:"Comida",icon:"fa-drumstick-bite"},
    {id:17,name:"Filete de Pescado",price:130,category:"Comida",icon:"fa-fish"},
    {id:18,name:"Mole Poblano",price:130,category:"Comida",icon:"fa-bowl-food"},
    {id:19,name:"Caldo de Res",price:130,category:"Comida",icon:"fa-bowl-food"},
    {id:20,name:"Caldo de Camarón",price:150,category:"Comida",icon:"fa-shrimp"},
    {id:21,name:"Birria de Res",price:140,category:"Especialidad",icon:"fa-bowl-food"},
    {id:22,name:"Carne en su Jugo",price:140,category:"Especialidad",icon:"fa-bowl-food"},
    {id:23,name:"Café de Olla",price:35,category:"Bebidas",icon:"fa-mug-hot"},
    {id:24,name:"Nescafé",price:35,category:"Bebidas",icon:"fa-mug-hot"},
    {id:25,name:"Jugo de Naranja",price:45,category:"Bebidas",icon:"fa-glass-water"},
    {id:26,name:"Agua Fresca",price:26,category:"Bebidas",icon:"fa-glass-water"},
    {id:27,name:"Refresco",price:30,category:"Bebidas",icon:"fa-bottle-water"},
    {id:28,name:"Licuado",price:45,category:"Bebidas",icon:"fa-blender"},
    {id:29,name:"Arroz con Leche",price:30,category:"Postres",icon:"fa-ice-cream"},
    {id:30,name:"Flan",price:45,category:"Postres",icon:"fa-cake-candles"},
    {id:31,name:"Gelatina",price:25,category:"Postres",icon:"fa-cake-candles"}
  ],
  tables: Array.from({length: 12}, (_,i)=>({
    id:i+1,
    name:`Mesa ${i+1}`,
    status: [2,5,9].includes(i+1) ? "ocupada" : [4,8].includes(i+1) ? "preparando" : [11].includes(i+1) ? "cuenta" : "libre"
  }))
};
