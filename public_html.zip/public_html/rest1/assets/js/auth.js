
window.Auth = {
  login(username,password){
    const user = DEMO_DATA.users.find(u=>u.username===username && u.password===password);
    if(!user) return null;
    App.state.user = user;
    App.persist();
    return user;
  },
  logout(){
    App.state.user = null;
    App.persist();
    App.renderLogin();
  }
};
