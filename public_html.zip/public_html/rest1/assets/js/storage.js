
window.Store = {
  key: "sazon_touch_demo_v1",
  load(){
    const saved = localStorage.getItem(this.key);
    if(saved) return JSON.parse(saved);
    const initial = {
      user: null,
      tables: DEMO_DATA.tables,
      products: DEMO_DATA.products,
      orders: [
        {
          id:101, tableId:2, tableName:"Mesa 2", waiter:"Juan Mesero",
          status:"nuevo", createdAt:new Date().toISOString(),
          items:[{id:21,name:"Birria de Res",price:140,qty:2},{id:23,name:"Café de Olla",price:35,qty:1}],
          total:315
        },
        {
          id:102, tableId:4, tableName:"Mesa 4", waiter:"Juan Mesero",
          status:"preparando", createdAt:new Date(Date.now()-1000*60*12).toISOString(),
          items:[{id:3,name:"Huevos Rancheros",price:95,qty:1},{id:25,name:"Jugo de Naranja",price:45,qty:1}],
          total:140
        }
      ],
      sales: 4280
    };
    this.save(initial);
    return initial;
  },
  save(data){ localStorage.setItem(this.key, JSON.stringify(data)); },
  reset(){ localStorage.removeItem(this.key); location.reload(); }
};
