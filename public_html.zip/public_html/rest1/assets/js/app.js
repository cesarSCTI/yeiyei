
window.App = {
  state: null,
  currentView: "dashboard",
  selectedTable: null,
  cart: [],
  category: "Desayunos",

  init(){
    this.state = Store.load();
    if(this.state.user) this.renderShell();
    else this.renderLogin();
  },

  persist(){ Store.save(this.state); },

  money(value){ return new Intl.NumberFormat("es-MX",{style:"currency",currency:"MXN",maximumFractionDigits:0}).format(value); },

  renderLogin(){
    document.getElementById("app").innerHTML = `
      <main class="login-page">
        <section class="login-card">
          <div class="brand-badge"><i class="fa-solid fa-utensils"></i></div>
          <div class="text-center mb-4">
            <h1>Sazón Touch</h1>
            <p class="text-secondary mb-0">Demo para restaurante</p>
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold" for="username">Usuario</label>
            <input id="username" class="form-control touch-input" value="admin" autocomplete="username">
          </div>
          <div class="mb-3">
            <label class="form-label fw-semibold" for="password">Contraseña</label>
            <input id="password" type="password" class="form-control touch-input" value="1234" autocomplete="current-password">
          </div>
          <button id="btnLogin" class="btn btn-primary btn-touch w-100">
            <i class="fa-solid fa-right-to-bracket me-2"></i>Ingresar
          </button>

          <div class="demo-users mt-4">
            <strong>Usuarios de demostración</strong>
            <div class="mt-2">admin / 1234 · caja / 1234</div>
            <div>mesero / 1234 · cocina / 1234</div>
          </div>
        </section>
      </main>`;

    const login = ()=>{
      const user = Auth.login(
        document.getElementById("username").value.trim(),
        document.getElementById("password").value
      );
      if(!user){
        Swal.fire({icon:"error",title:"Acceso incorrecto",text:"Revisa el usuario y la contraseña."});
        return;
      }
      this.renderShell();
    };
    document.getElementById("btnLogin").addEventListener("click",login);
    document.getElementById("password").addEventListener("keydown",e=>{ if(e.key==="Enter") login(); });
  },

  navItems(){
    const role = this.state.user.role;
    const all = [
      ["dashboard","fa-house","Inicio",["Administrador","Cajero","Mesero","Cocina"]],
      ["mesas","fa-chair","Mesas",["Administrador","Cajero","Mesero"]],
      ["pedido","fa-clipboard-list","Pedido",["Administrador","Mesero"]],
      ["cocina","fa-fire-burner","Cocina",["Administrador","Cocina"]],
      ["caja","fa-cash-register","Caja",["Administrador","Cajero"]],
      ["productos","fa-burger","Productos",["Administrador"]],
      ["reportes","fa-chart-column","Reportes",["Administrador"]]
    ];
    return all.filter(x=>x[3].includes(role));
  },

  renderShell(){
    const items = this.navItems();
    document.getElementById("app").innerHTML = `
      <div class="app-shell">
        <aside class="sidebar">
          <div class="sidebar-brand">
            <div class="logo"><i class="fa-solid fa-utensils"></i></div>
            <div><strong>Sazón Touch</strong><small>Restaurante demo</small></div>
          </div>
          <nav class="nav nav-pills flex-column nav-touch">
            ${items.map(i=>`<button class="nav-link ${i[0]===this.currentView?"active":""}" data-view="${i[0]}"><i class="fa-solid ${i[1]}"></i>${i[2]}</button>`).join("")}
          </nav>
          <button id="resetDemo" class="btn btn-outline-light w-100 mt-4"><i class="fa-solid fa-rotate-left me-2"></i>Reiniciar demo</button>
        </aside>

        <section class="main-area">
          <header class="topbar">
            <div>
              <button class="btn btn-light d-lg-none me-2" data-bs-toggle="offcanvas" data-bs-target="#mobileMenu"><i class="fa-solid fa-bars"></i></button>
              <span class="fw-bold">${this.state.user.name}</span>
              <span class="badge text-bg-light ms-2">${this.state.user.role}</span>
            </div>
            <button id="logout" class="btn btn-outline-danger"><i class="fa-solid fa-arrow-right-from-bracket me-1"></i><span class="d-none d-sm-inline">Salir</span></button>
          </header>

          <main id="view" class="content"></main>
        </section>
      </div>

      <div class="offcanvas offcanvas-start" tabindex="-1" id="mobileMenu">
        <div class="offcanvas-header">
          <h5 class="offcanvas-title">Sazón Touch</h5>
          <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
        </div>
        <div class="offcanvas-body">
          <nav class="nav flex-column">
            ${items.map(i=>`<button class="btn btn-light text-start mb-2 p-3 mobile-menu-link" data-view="${i[0]}" data-bs-dismiss="offcanvas"><i class="fa-solid ${i[1]} me-2"></i>${i[2]}</button>`).join("")}
          </nav>
        </div>
      </div>

      <nav class="mobile-nav">
        ${items.slice(0,5).map(i=>`<button data-view="${i[0]}" class="${i[0]===this.currentView?"active":""}"><i class="fa-solid ${i[1]}"></i>${i[2]}</button>`).join("")}
      </nav>`;

    document.querySelectorAll("[data-view]").forEach(btn=>{
      btn.addEventListener("click",()=>this.go(btn.dataset.view));
    });
    document.getElementById("logout").addEventListener("click",()=>Auth.logout());
    document.getElementById("resetDemo").addEventListener("click",()=>{
      Swal.fire({icon:"question",title:"¿Reiniciar la demo?",showCancelButton:true,confirmButtonText:"Sí, reiniciar",cancelButtonText:"Cancelar"})
        .then(r=>{if(r.isConfirmed) Store.reset();});
    });

    if(!items.some(i=>i[0]===this.currentView)) this.currentView=items[0][0];
    this.renderView();
  },

  go(view){
    this.currentView=view;
    document.querySelectorAll("[data-view]").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
    this.renderView();
  },

  renderView(){
    const views = {
      dashboard:()=>this.dashboard(),
      mesas:()=>this.mesas(),
      pedido:()=>this.pedido(),
      cocina:()=>this.cocina(),
      caja:()=>this.caja(),
      productos:()=>this.productos(),
      reportes:()=>this.reportes()
    };
    (views[this.currentView]||views.dashboard)();
  },

  header(title,subtitle){
    return `<div class="mb-4"><h1 class="page-title">${title}</h1><p class="page-subtitle">${subtitle}</p></div>`;
  },

  dashboard(){
    const orders = this.state.orders;
    const occupied = this.state.tables.filter(t=>t.status!=="libre").length;
    const pending = orders.filter(o=>o.status!=="pagado").length;
    const view = document.getElementById("view");
    view.innerHTML = `
      ${this.header("Panel principal","Operación rápida para tablet, celular y pantalla táctil.")}
      <div class="row g-3 mb-4">
        ${this.metric("Ventas de hoy",this.money(this.state.sales),"fa-sack-dollar","bg-soft-success")}
        ${this.metric("Mesas ocupadas",occupied,"fa-chair","bg-soft-primary")}
        ${this.metric("Pedidos activos",pending,"fa-receipt","bg-soft-warning")}
        ${this.metric("Ticket promedio",this.money(214),"fa-chart-line","bg-soft-info")}
      </div>

      <div class="row g-3 mb-4">
        ${this.action("mesas","fa-chair","Administrar mesas","Consulta mesas libres y ocupadas.")}
        ${this.action("pedido","fa-clipboard-list","Tomar pedido","Agrega productos con botones táctiles.")}
        ${this.action("cocina","fa-fire-burner","Pantalla de cocina","Cambia pedidos a preparando o listo.")}
        ${this.action("caja","fa-cash-register","Cobrar mesa","Simula efectivo, tarjeta o transferencia.")}
      </div>

      <section class="card-soft table-card">
        <div class="p-3 border-bottom"><strong>Actividad reciente</strong></div>
        <div class="table-responsive">
          <table class="table align-middle mb-0">
            <thead><tr><th>Pedido</th><th>Mesa</th><th>Total</th><th>Estado</th></tr></thead>
            <tbody>
              ${orders.map(o=>`<tr><td>#${o.id}</td><td>${o.tableName}</td><td>${this.money(o.total)}</td><td>${this.statusBadge(o.status)}</td></tr>`).join("")}
            </tbody>
          </table>
        </div>
      </section>`;
    view.querySelectorAll("[data-action]").forEach(b=>b.addEventListener("click",()=>this.go(b.dataset.action)));
  },

  metric(label,value,icon,bg){
    return `<div class="col-6 col-xl-3"><div class="card-soft metric-card h-100">
      <div class="d-flex justify-content-between gap-3"><div><div class="metric-label">${label}</div><div class="metric-value mt-2">${value}</div></div><div class="metric-icon ${bg}"><i class="fa-solid ${icon}"></i></div></div>
    </div></div>`;
  },

  action(view,icon,title,text){
    return `<div class="col-6 col-xl-3"><button class="action-card" data-action="${view}"><i class="fa-solid ${icon}"></i><h3>${title}</h3><p>${text}</p></button></div>`;
  },

  statusBadge(status){
    const map={
      nuevo:["danger","Nuevo"],
      preparando:["warning","Preparando"],
      listo:["success","Listo"],
      pagado:["secondary","Pagado"]
    };
    const x=map[status]||["secondary",status];
    return `<span class="badge text-bg-${x[0]} badge-status">${x[1]}</span>`;
  },

  mesas(){
    const label={libre:"Disponible",ocupada:"Ocupada",preparando:"Preparando",cuenta:"Cuenta solicitada"};
    document.getElementById("view").innerHTML = `
      ${this.header("Mesas","Toca una mesa para abrir o continuar el pedido.")}
      <div class="d-flex flex-wrap gap-2 mb-3">
        <span class="badge text-bg-success p-2">Disponible</span>
        <span class="badge text-bg-danger p-2">Ocupada</span>
        <span class="badge text-bg-warning p-2">Preparando</span>
        <span class="badge text-bg-info p-2">Cuenta</span>
      </div>
      <div class="mesas-grid">
        ${this.state.tables.map(t=>`
          <button class="mesa-card mesa-${t.status}" data-table="${t.id}">
            <div class="d-flex justify-content-between">
              <i class="fa-solid fa-chair fs-3"></i>
              <span class="badge bg-light text-dark">${t.id}</span>
            </div>
            <h3 class="mt-3 mb-1">${t.name}</h3>
            <small>${label[t.status]}</small>
          </button>`).join("")}
      </div>`;
    document.querySelectorAll("[data-table]").forEach(btn=>btn.addEventListener("click",()=>{
      this.selectedTable = Number(btn.dataset.table);
      this.cart = [];
      this.go("pedido");
    }));
  },

  pedido(){
    const table = this.state.tables.find(t=>t.id===this.selectedTable) || this.state.tables.find(t=>t.status==="libre") || this.state.tables[0];
    this.selectedTable = table.id;
    const products=this.state.products.filter(p=>p.category===this.category);

    document.getElementById("view").innerHTML = `
      ${this.header("Nuevo pedido",`${table.name} · Mesero: ${this.state.user.name}`)}
      <div class="order-layout">
        <section>
          <div class="category-strip mb-3">
            ${DEMO_DATA.categories.map(c=>`<button class="btn btn-outline-secondary category-btn ${c===this.category?"active":""}" data-category="${c}">${c}</button>`).join("")}
          </div>
          <div class="products-grid">
            ${products.map(p=>`
              <button class="product-card" data-product="${p.id}">
                <div class="product-icon"><i class="fa-solid ${p.icon}"></i></div>
                <h4>${p.name}</h4>
                <div class="product-price">${this.money(p.price)}</div>
              </button>`).join("")}
          </div>
        </section>

        <aside class="card-soft cart-panel">
          <div class="d-flex align-items-center justify-content-between mb-2">
            <h2 class="h5 fw-bold mb-0"><i class="fa-solid fa-receipt me-2"></i>Pedido</h2>
            <span class="badge text-bg-light">${table.name}</span>
          </div>
          <div id="cartList" class="cart-list"></div>
          <div class="border-top pt-3 mt-3">
            <div class="d-flex justify-content-between total-line"><span>Total</span><span id="cartTotal">$0</span></div>
            <button id="sendKitchen" class="btn btn-primary btn-touch w-100 mt-3"><i class="fa-solid fa-paper-plane me-2"></i>Enviar a cocina</button>
          </div>
        </aside>
      </div>`;

    document.querySelectorAll("[data-category]").forEach(b=>b.addEventListener("click",()=>{this.category=b.dataset.category;this.pedido();}));
    document.querySelectorAll("[data-product]").forEach(b=>b.addEventListener("click",()=>this.addToCart(Number(b.dataset.product))));
    document.getElementById("sendKitchen").addEventListener("click",()=>this.sendKitchen());
    this.renderCart();
  },

  addToCart(id){
    const p=this.state.products.find(x=>x.id===id);
    const existing=this.cart.find(x=>x.id===id);
    if(existing) existing.qty++;
    else this.cart.push({...p,qty:1});
    this.renderCart();
  },

  renderCart(){
    const list=document.getElementById("cartList");
    if(!list) return;
    if(!this.cart.length){
      list.innerHTML=`<div class="text-center text-secondary py-5"><i class="fa-solid fa-basket-shopping fs-2 mb-3 d-block"></i>Toca un producto para agregarlo.</div>`;
    }else{
      list.innerHTML=this.cart.map(i=>`
        <div class="cart-item">
          <div class="d-flex justify-content-between gap-2">
            <div><strong>${i.name}</strong><div class="text-secondary small">${this.money(i.price)} c/u</div></div>
            <strong>${this.money(i.price*i.qty)}</strong>
          </div>
          <div class="qty-box mt-2">
            <button class="qty-btn" data-minus="${i.id}">−</button>
            <strong>${i.qty}</strong>
            <button class="qty-btn" data-plus="${i.id}">+</button>
          </div>
        </div>`).join("");
    }
    document.getElementById("cartTotal").textContent=this.money(this.cart.reduce((a,b)=>a+b.price*b.qty,0));
    document.querySelectorAll("[data-plus]").forEach(b=>b.addEventListener("click",()=>{this.cart.find(x=>x.id===Number(b.dataset.plus)).qty++;this.renderCart();}));
    document.querySelectorAll("[data-minus]").forEach(b=>b.addEventListener("click",()=>{
      const item=this.cart.find(x=>x.id===Number(b.dataset.minus)); item.qty--;
      if(item.qty<=0) this.cart=this.cart.filter(x=>x.id!==item.id);
      this.renderCart();
    }));
  },

  sendKitchen(){
    if(!this.cart.length){
      Swal.fire({icon:"warning",title:"Pedido vacío",text:"Agrega al menos un producto."}); return;
    }
    const table=this.state.tables.find(t=>t.id===this.selectedTable);
    const total=this.cart.reduce((a,b)=>a+b.price*b.qty,0);
    this.state.orders.unshift({
      id:Date.now().toString().slice(-6),
      tableId:table.id,tableName:table.name,waiter:this.state.user.name,
      status:"nuevo",createdAt:new Date().toISOString(),items:this.cart.map(x=>({...x})),total
    });
    table.status="ocupada";
    this.cart=[];
    this.persist();
    Swal.fire({icon:"success",title:"Pedido enviado",text:`La comanda de ${table.name} fue enviada a cocina.`,timer:1800,showConfirmButton:false});
    this.go("cocina");
  },

  cocina(){
    const orders=this.state.orders.filter(o=>o.status!=="pagado");
    document.getElementById("view").innerHTML=`
      ${this.header("Cocina","Actualiza cada pedido con botones grandes.")}
      <div class="kitchen-grid">
        ${orders.length?orders.map(o=>`
          <article class="card-soft kitchen-card ${o.status}">
            <div class="d-flex justify-content-between align-items-start">
              <div><h2 class="h5 fw-bold mb-1">Pedido #${o.id}</h2><div class="text-secondary">${o.tableName} · ${o.waiter}</div></div>
              ${this.statusBadge(o.status)}
            </div>
            <div class="kitchen-items my-3">
              ${o.items.map(i=>`<div class="d-flex justify-content-between py-1"><span>${i.qty} × ${i.name}</span></div>`).join("")}
            </div>
            <div class="touch-btn-row">
              <button class="btn btn-warning btn-touch" data-order-status="${o.id}|preparando">Preparando</button>
              <button class="btn btn-success btn-touch" data-order-status="${o.id}|listo">Listo</button>
            </div>
          </article>`).join(""):`<div class="card-soft p-5 text-center text-secondary">No hay pedidos activos.</div>`}
      </div>`;
    document.querySelectorAll("[data-order-status]").forEach(b=>b.addEventListener("click",()=>{
      const [id,status]=b.dataset.orderStatus.split("|");
      const order=this.state.orders.find(o=>String(o.id)===id);
      order.status=status;
      const table=this.state.tables.find(t=>t.id===order.tableId);
      if(table) table.status=status==="preparando"?"preparando":"cuenta";
      this.persist(); this.cocina();
    }));
  },

  caja(){
    const ready=this.state.orders.filter(o=>o.status==="listo");
    document.getElementById("view").innerHTML=`
      ${this.header("Caja","Selecciona un pedido listo y simula el cobro.")}
      <div class="row g-3">
        <div class="col-lg-5">
          <section class="card-soft p-3">
            <h2 class="h5 fw-bold">Pedidos listos</h2>
            <div class="list-group list-group-flush">
              ${ready.length?ready.map(o=>`
                <button class="list-group-item list-group-item-action rounded-3 mb-2 p-3" data-pay-order="${o.id}">
                  <div class="d-flex justify-content-between"><strong>${o.tableName}</strong><strong>${this.money(o.total)}</strong></div>
                  <small class="text-secondary">Pedido #${o.id}</small>
                </button>`).join(""):`<div class="text-secondary py-4 text-center">Todavía no hay pedidos listos.</div>`}
            </div>
          </section>
        </div>
        <div class="col-lg-7">
          <section id="paymentPanel" class="card-soft p-4 text-center text-secondary">
            <i class="fa-solid fa-cash-register fs-1 mb-3 d-block"></i>
            Selecciona un pedido para cobrar.
          </section>
        </div>
      </div>`;
    document.querySelectorAll("[data-pay-order]").forEach(b=>b.addEventListener("click",()=>this.showPayment(String(b.dataset.payOrder))));
  },

  showPayment(id){
    const o=this.state.orders.find(x=>String(x.id)===id);
    document.getElementById("paymentPanel").innerHTML=`
      <div class="text-start">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <div><h2 class="h4 fw-bold mb-0">${o.tableName}</h2><small class="text-secondary">Pedido #${o.id}</small></div>
          <div class="h3 fw-bold mb-0">${this.money(o.total)}</div>
        </div>
        <div class="kitchen-items mb-4">${o.items.map(i=>`<div class="d-flex justify-content-between py-1"><span>${i.qty} × ${i.name}</span><strong>${this.money(i.qty*i.price)}</strong></div>`).join("")}</div>
        <div class="payment-grid">
          <button class="payment-btn" data-method="Efectivo"><i class="fa-solid fa-money-bill-wave"></i>Efectivo</button>
          <button class="payment-btn" data-method="Tarjeta"><i class="fa-solid fa-credit-card"></i>Tarjeta</button>
          <button class="payment-btn" data-method="Transferencia"><i class="fa-solid fa-building-columns"></i>Transferencia</button>
          <button class="payment-btn" data-method="Mixto"><i class="fa-solid fa-wallet"></i>Mixto</button>
        </div>
      </div>`;
    document.querySelectorAll("[data-method]").forEach(b=>b.addEventListener("click",()=>this.payOrder(o,b.dataset.method)));
  },

  payOrder(order,method){
    order.status="pagado";
    const table=this.state.tables.find(t=>t.id===order.tableId);
    if(table) table.status="libre";
    this.state.sales+=order.total;
    this.persist();
    Swal.fire({icon:"success",title:"Pago registrado",html:`${order.tableName}<br><strong>${this.money(order.total)}</strong><br>${method}`,confirmButtonText:"Aceptar"});
    this.caja();
  },

  productos(){
    document.getElementById("view").innerHTML=`
      ${this.header("Productos","Catálogo editable para demostración.")}
      <div class="d-flex justify-content-end mb-3"><button id="addProduct" class="btn btn-primary btn-touch px-4"><i class="fa-solid fa-plus me-2"></i>Agregar producto</button></div>
      <section class="card-soft table-card">
        <div class="table-responsive">
          <table class="table align-middle mb-0">
            <thead><tr><th>Producto</th><th>Categoría</th><th>Precio</th><th></th></tr></thead>
            <tbody>
              ${this.state.products.map(p=>`<tr><td><strong>${p.name}</strong></td><td>${p.category}</td><td>${this.money(p.price)}</td><td class="text-end"><button class="btn btn-light" data-delete-product="${p.id}"><i class="fa-solid fa-trash text-danger"></i></button></td></tr>`).join("")}
            </tbody>
          </table>
        </div>
      </section>`;
    document.getElementById("addProduct").addEventListener("click",()=>this.addProduct());
    document.querySelectorAll("[data-delete-product]").forEach(b=>b.addEventListener("click",()=>{
      this.state.products=this.state.products.filter(p=>p.id!==Number(b.dataset.deleteProduct));this.persist();this.productos();
    }));
  },

  async addProduct(){
    const result=await Swal.fire({
      title:"Agregar producto",
      html:`<input id="pName" class="swal2-input" placeholder="Nombre"><input id="pPrice" type="number" class="swal2-input" placeholder="Precio"><select id="pCategory" class="swal2-select">${DEMO_DATA.categories.map(c=>`<option>${c}</option>`).join("")}</select>`,
      showCancelButton:true,confirmButtonText:"Guardar",cancelButtonText:"Cancelar",
      preConfirm:()=>{
        const name=document.getElementById("pName").value.trim();
        const price=Number(document.getElementById("pPrice").value);
        const category=document.getElementById("pCategory").value;
        if(!name||price<=0){Swal.showValidationMessage("Completa nombre y precio.");return false;}
        return {name,price,category};
      }
    });
    if(result.isConfirmed){
      this.state.products.push({id:Date.now(),icon:"fa-utensils",...result.value});
      this.persist();this.productos();
    }
  },

  reportes(){
    const paid=this.state.orders.filter(o=>o.status==="pagado");
    document.getElementById("view").innerHTML=`
      ${this.header("Reportes","Resumen visual de la operación simulada.")}
      <div class="row g-3 mb-4">
        ${this.metric("Venta acumulada",this.money(this.state.sales),"fa-sack-dollar","bg-soft-success")}
        ${this.metric("Pedidos cobrados",paid.length,"fa-check","bg-soft-primary")}
        ${this.metric("Productos activos",this.state.products.length,"fa-burger","bg-soft-warning")}
        ${this.metric("Mesas disponibles",this.state.tables.filter(t=>t.status==="libre").length,"fa-chair","bg-soft-info")}
      </div>
      <section class="card-soft p-4">
        <h2 class="h5 fw-bold">Productos destacados</h2>
        <div class="row g-3 mt-1">
          ${["Birria de Res","Huevos Rancheros","Café de Olla","Quesabirria"].map((x,i)=>`
            <div class="col-12 col-md-6"><div class="d-flex justify-content-between mb-1"><span>${i+1}. ${x}</span><strong>${[38,29,25,18][i]} ventas</strong></div><div class="progress" style="height:10px"><div class="progress-bar" style="width:${[100,76,66,47][i]}%"></div></div></div>`).join("")}
        </div>
      </section>`;
  }
};

document.addEventListener("DOMContentLoaded",()=>App.init());
